<?php
// ══════════════════════════════════════════════════════════
//  ACNC Mission Donation System — Configuration
//  Edit ONLY the DB section below, then upload.
//  Admin users are managed inside the Admin Panel.
// ══════════════════════════════════════════════════════════

// ── Database ───────────────────────────────────────────
define('DB_HOST',    'localhost');
define('DB_NAME',    'your_db_name');      // ← your MySQL database name
define('DB_USER',    'your_db_user');      // ← your MySQL username
define('DB_PASS',    'your_db_password');  // ← your MySQL password
define('DB_CHARSET', 'utf8mb4');

// ── Site ───────────────────────────────────────────────
define('SITE_NAME',      'ACNC Mission Donation Portal');
define('SITE_URL',       'https://yourdomain.com'); // No trailing slash
define('CONTACT_EMAIL',  'donations@bbcmhk.org');

// ── Security settings ──────────────────────────────────
define('SESSION_TIMEOUT',    1800);  // 30 min idle timeout
define('MAX_LOGIN_ATTEMPTS', 5);     // lockout after N failures
define('LOCKOUT_MINUTES',    15);    // lockout duration
define('MIN_PASSWORD_LEN',   10);    // minimum password length

// ── Roles ──────────────────────────────────────────────
define('ROLE_SUPER',   'super_admin'); // full access + user management
define('ROLE_ADMIN',   'admin');       // donations, missionaries, rates, content
define('ROLE_EDITOR',  'editor');      // view + write donations & exchange rates only
define('ROLE_VIEWER',  'viewer');      // read-only donations view

// ══════════════════════════════════════════════════════════
//  DO NOT EDIT BELOW THIS LINE
// ══════════════════════════════════════════════════════════

// ── Security headers (called once at top of every page) ─
function send_security_headers() {
    header("X-Frame-Options: DENY");
    header("X-Content-Type-Options: nosniff");
    header("X-XSS-Protection: 1; mode=block");
    header("Referrer-Policy: strict-origin-when-cross-origin");
    header("Permissions-Policy: camera=(), microphone=(), geolocation=()");
    header("Content-Security-Policy: default-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; script-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self'");
    if (!empty($_SERVER['HTTPS'])) {
        header("Strict-Transport-Security: max-age=31536000; includeSubDomains");
    }
}

// ── PHP hardening ──────────────────────────────────────
error_reporting(0);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Strict');
ini_set('session.use_strict_mode', 1);
ini_set('session.gc_maxlifetime', SESSION_TIMEOUT);
if (!empty($_SERVER['HTTPS'])) {
    ini_set('session.cookie_secure', 1);
}

// ── Database ───────────────────────────────────────────
function getDB() {
    static $pdo = null;
    if ($pdo !== null) return $pdo;
    $dsn = 'mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset='.DB_CHARSET;
    try {
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]);
    } catch (PDOException $e) {
        http_response_code(500);
        die('Service temporarily unavailable.');
    }
    return $pdo;
}

// ── CSRF ───────────────────────────────────────────────
function csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}
function csrf_verify($token) {
    return !empty($_SESSION['csrf_token']) &&
           is_string($token) &&
           hash_equals($_SESSION['csrf_token'], $token);
}

// ── Auth ───────────────────────────────────────────────
function is_logged_in() {
    if (empty($_SESSION['acnc_uid']) || empty($_SESSION['login_time'])) return false;
    if ((time() - $_SESSION['login_time']) >= SESSION_TIMEOUT) {
        session_unset(); session_destroy(); return false;
    }
    // Session fingerprint check (prevents session hijacking)
    $fp = md5($_SERVER['HTTP_USER_AGENT'] . $_SERVER['REMOTE_ADDR']);
    if (empty($_SESSION['fp']) || $_SESSION['fp'] !== $fp) {
        session_unset(); session_destroy(); return false;
    }
    return true;
}
function require_login($min_role = null) {
    if (!is_logged_in()) {
        header('Location: ../login.php'); exit;
    }
    $_SESSION['login_time'] = time(); // sliding window
    if ($min_role !== null && !has_role($min_role)) {
        http_response_code(403);
        die('<h2 style="font-family:sans-serif;padding:2rem">Access denied. Insufficient permissions.</h2>');
    }
}
function current_role()  { return $_SESSION['acnc_role'] ?? ''; }
function current_user()  { return $_SESSION['acnc_username'] ?? ''; }
function current_uid()   { return $_SESSION['acnc_uid'] ?? null; }
function has_role($role) {
    $hierarchy = [ROLE_SUPER => 4, ROLE_ADMIN => 3, ROLE_EDITOR => 2, ROLE_VIEWER => 1];
    $mine = $hierarchy[current_role()] ?? 0;
    $need = $hierarchy[$role] ?? 99;
    return $mine >= $need;
}
function require_super()  { require_login(ROLE_SUPER); }
function require_admin()  { require_login(ROLE_ADMIN); }
function require_editor() { require_login(ROLE_EDITOR); }

// ── Login attempt tracking ─────────────────────────────
function check_login_lockout($username) {
    $db = getDB();
    $stmt = $db->prepare("SELECT COUNT(*) FROM login_attempts
        WHERE username = ? AND attempted_at > DATE_SUB(NOW(), INTERVAL ? MINUTE) AND success = 0");
    $stmt->execute([$username, LOCKOUT_MINUTES]);
    return (int)$stmt->fetchColumn() >= MAX_LOGIN_ATTEMPTS;
}
function log_login_attempt($username, $success, $ip) {
    $db = getDB();
    $db->prepare("INSERT INTO login_attempts (username, success, ip_address, attempted_at) VALUES (?,?,?,NOW())")
       ->execute([$username, (int)$success, $ip]);
    // Clean old records (older than 24h)
    $db->exec("DELETE FROM login_attempts WHERE attempted_at < DATE_SUB(NOW(), INTERVAL 24 HOUR)");
}
function get_remaining_lockout($username) {
    $db = getDB();
    $stmt = $db->prepare("SELECT MAX(attempted_at) FROM login_attempts
        WHERE username = ? AND attempted_at > DATE_SUB(NOW(), INTERVAL ? MINUTE) AND success = 0");
    $stmt->execute([$username, LOCKOUT_MINUTES]);
    $last = $stmt->fetchColumn();
    if (!$last) return 0;
    $remaining = LOCKOUT_MINUTES * 60 - (time() - strtotime($last));
    return max(0, $remaining);
}

// ── Audit log ─────────────────────────────────────────
function audit($action, $detail = '') {
    try {
        $db = getDB();
        $db->prepare("INSERT INTO audit_log (user_id, username, action, detail, ip_address, created_at)
            VALUES (?,?,?,?,?,NOW())")
           ->execute([current_uid(), current_user(), $action, $detail, $_SERVER['REMOTE_ADDR'] ?? '']);
    } catch (Exception $e) { /* non-fatal */ }
}

// ── Password strength ─────────────────────────────────
function validate_password($pw) {
    $errors = [];
    if (strlen($pw) < MIN_PASSWORD_LEN)
        $errors[] = 'At least '.MIN_PASSWORD_LEN.' characters.';
    if (!preg_match('/[A-Z]/', $pw))
        $errors[] = 'At least one uppercase letter.';
    if (!preg_match('/[a-z]/', $pw))
        $errors[] = 'At least one lowercase letter.';
    if (!preg_match('/[0-9]/', $pw))
        $errors[] = 'At least one number.';
    if (!preg_match('/[^A-Za-z0-9]/', $pw))
        $errors[] = 'At least one special character (!@#$%...).';
    return $errors;
}

function h($str) { return htmlspecialchars((string)$str, ENT_QUOTES, 'UTF-8'); }
