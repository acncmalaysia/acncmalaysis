-- ══════════════════════════════════════════════════════════
--  ACNC Mission Donation System — Full Database Setup
--  Run this ONCE in phpMyAdmin → SQL tab → paste → Go
-- ══════════════════════════════════════════════════════════

SET NAMES utf8mb4;
SET time_zone = '+00:00';
SET FOREIGN_KEY_CHECKS = 0;

-- ── Admin users ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `admin_users` (
  `id`              INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `username`        VARCHAR(50)   NOT NULL UNIQUE,
  `email`           VARCHAR(255)  NOT NULL UNIQUE,
  `password_hash`   VARCHAR(255)  NOT NULL,
  `role`            ENUM('super_admin','admin','editor','viewer') NOT NULL DEFAULT 'viewer',
  `full_name`       VARCHAR(150)  DEFAULT NULL,
  `active`          TINYINT(1)    NOT NULL DEFAULT 1,
  `last_login`      DATETIME      DEFAULT NULL,
  `last_login_ip`   VARCHAR(45)   DEFAULT NULL,
  `force_pw_change` TINYINT(1)    NOT NULL DEFAULT 0,
  `created_at`      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by`      INT UNSIGNED  DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_username` (`username`),
  KEY `idx_active`   (`active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Login attempt log (brute-force protection) ────────────
CREATE TABLE IF NOT EXISTS `login_attempts` (
  `id`           INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `username`     VARCHAR(50)  NOT NULL,
  `success`      TINYINT(1)   NOT NULL DEFAULT 0,
  `ip_address`   VARCHAR(45)  DEFAULT NULL,
  `attempted_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_time` (`username`, `attempted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Audit log ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `audit_log` (
  `id`         INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `user_id`    INT UNSIGNED  DEFAULT NULL,
  `username`   VARCHAR(50)   DEFAULT NULL,
  `action`     VARCHAR(100)  NOT NULL,
  `detail`     TEXT          DEFAULT NULL,
  `ip_address` VARCHAR(45)   DEFAULT NULL,
  `created_at` DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user`   (`user_id`),
  KEY `idx_action` (`action`),
  KEY `idx_time`   (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Donations ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `donations` (
  `id`              INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `ref`             VARCHAR(20)   NOT NULL UNIQUE,
  `created_at`      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `first_name`      VARCHAR(100)  NOT NULL,
  `last_name`       VARCHAR(100)  NOT NULL,
  `email`           VARCHAR(255)  NOT NULL,
  `phone`           VARCHAR(50)   DEFAULT NULL,
  `country`         VARCHAR(100)  DEFAULT NULL,
  `amount`          DECIMAL(12,2) NOT NULL,
  `currency`        VARCHAR(10)   NOT NULL DEFAULT 'MYR',
  `myr_equivalent`  DECIMAL(12,2) NOT NULL,
  `cover_fee`       TINYINT(1)    NOT NULL DEFAULT 0,
  `fee_amount`      DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `total_myr`       DECIMAL(12,2) NOT NULL,
  `missionary`      VARCHAR(255)  DEFAULT NULL,
  `fund`            VARCHAR(100)  DEFAULT 'General',
  `monthly`         TINYINT(1)    NOT NULL DEFAULT 0,
  `remarks`         TEXT          DEFAULT NULL,
  `ip_address`      VARCHAR(45)   DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_email`      (`email`),
  KEY `idx_missionary` (`missionary`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Missionaries ──────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `missionaries` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name`       VARCHAR(255) NOT NULL,
  `field`      VARCHAR(255) NOT NULL,
  `org`        VARCHAR(255) DEFAULT NULL,
  `email`      VARCHAR(255) DEFAULT NULL,
  `notes`      TEXT         DEFAULT NULL,
  `active`     TINYINT(1)   NOT NULL DEFAULT 1,
  `created_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Exchange rates ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `exchange_rates` (
  `currency`    VARCHAR(10)   NOT NULL,
  `rate_to_myr` DECIMAL(16,6) NOT NULL,
  `updated_at`  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`currency`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

-- ── Seed: default super admin ─────────────────────────────
-- Password: Admin@12345  (CHANGE THIS after first login!)
INSERT IGNORE INTO `admin_users`
  (`username`, `email`, `password_hash`, `role`, `full_name`, `force_pw_change`)
VALUES (
  'admin',
  'admin@yourdomain.com',
  '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uMe5NnmKO',
  'super_admin',
  'System Administrator',
  1
);

-- ── Seed: missionaries ────────────────────────────────────
INSERT IGNORE INTO `missionaries` (`name`, `field`, `org`, `email`, `notes`) VALUES
('Rev. Samuel Lim',  'Thailand', 'OMF International', 'samuel@omf.org', 'Church planting in Chiang Mai'),
('Sister Grace Tan', 'Cambodia', 'ACNC',              'grace@acnc.org', 'Education & children ministry');

-- ── Seed: exchange rates ──────────────────────────────────
INSERT INTO `exchange_rates` (`currency`, `rate_to_myr`) VALUES
('MYR',1.000000),('USD',4.700000),('SGD',3.470000),('AUD',3.000000),
('GBP',5.950000),('EUR',5.100000),('HKD',0.600000),('TWD',0.148000),
('JPY',0.031000),('KRW',0.003500),('IDR',0.000290),('PHP',0.082000),
('THB',0.130000),('INR',0.056000)
ON DUPLICATE KEY UPDATE `rate_to_myr` = VALUES(`rate_to_myr`);

-- ── If upgrading an existing install, run this to add the editor role ──
-- ALTER TABLE `admin_users` MODIFY `role` ENUM('super_admin','admin','editor','viewer') NOT NULL DEFAULT 'viewer';

-- ── Currency settings (which currencies show on donate page) ──────────────────
CREATE TABLE IF NOT EXISTS `currency_settings` (
  `code`       VARCHAR(10)   NOT NULL,
  `name`       VARCHAR(100)  NOT NULL,
  `flag`       VARCHAR(10)   NOT NULL DEFAULT '',
  `symbol`     VARCHAR(10)   NOT NULL DEFAULT '',
  `active`     TINYINT(1)    NOT NULL DEFAULT 1,
  `sort_order` INT           NOT NULL DEFAULT 99,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `currency_settings` (`code`,`name`,`flag`,`symbol`,`active`,`sort_order`) VALUES
('MYR','Malaysian Ringgit','🇲🇾','RM',1,1),
('USD','US Dollar','🇺🇸','$',1,2),
('SGD','Singapore Dollar','🇸🇬','S$',1,3),
('AUD','Australian Dollar','🇦🇺','A$',1,4),
('GBP','British Pound','🇬🇧','£',1,5),
('EUR','Euro','🇪🇺','€',1,6),
('HKD','Hong Kong Dollar','🇭🇰','HK$',1,7),
('TWD','Taiwan Dollar','🇹🇼','NT$',1,8),
('JPY','Japanese Yen','🇯🇵','¥',1,9),
('KRW','Korean Won','🇰🇷','₩',1,10),
('IDR','Indonesian Rupiah','🇮🇩','Rp',1,11),
('PHP','Philippine Peso','🇵🇭','₱',1,12),
('THB','Thai Baht','🇹🇭','฿',1,13),
('INR','Indian Rupee','🇮🇳','₹',1,14),
('CNY','Chinese Yuan','🇨🇳','¥',0,15),
('NZD','New Zealand Dollar','🇳🇿','NZ$',0,16),
('JPY','Japanese Yen','🇯🇵','¥',1,9),
('CAD','Canadian Dollar','🇨🇦','C$',0,17),
('CHF','Swiss Franc','🇨🇭','Fr',0,18),
('BND','Brunei Dollar','🇧🇳','B$',0,19),
('VND','Vietnamese Dong','🇻🇳','₫',0,20),
('THB','Thai Baht','🇹🇭','฿',1,13)
ON DUPLICATE KEY UPDATE `name`=VALUES(`name`);

-- ── Donation countries (dropdown on donate page) ──────────────────────────────
CREATE TABLE IF NOT EXISTS `donation_countries` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name`       VARCHAR(100) NOT NULL,
  `code`       VARCHAR(5)   NOT NULL DEFAULT '',
  `flag`       VARCHAR(10)  NOT NULL DEFAULT '',
  `active`     TINYINT(1)   NOT NULL DEFAULT 1,
  `sort_order` INT          NOT NULL DEFAULT 99,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `donation_countries` (`name`,`code`,`flag`,`active`,`sort_order`) VALUES
('Malaysia','MY','🇲🇾',1,1),
('Singapore','SG','🇸🇬',1,2),
('Hong Kong','HK','🇭🇰',1,3),
('Australia','AU','🇦🇺',1,4),
('United States','US','🇺🇸',1,5),
('United Kingdom','UK','🇬🇧',1,6),
('Canada','CA','🇨🇦',1,7),
('New Zealand','NZ','🇳🇿',1,8),
('Taiwan','TW','🇹🇼',1,9),
('China','CN','🇨🇳',1,10),
('Japan','JP','🇯🇵',1,11),
('South Korea','KR','🇰🇷',1,12),
('Indonesia','ID','🇮🇩',1,13),
('Philippines','PH','🇵🇭',1,14),
('Thailand','TH','🇹🇭',1,15),
('Vietnam','VN','🇻🇳',1,16),
('Myanmar','MM','🇲🇲',1,17),
('Cambodia','KH','🇰🇭',1,18),
('India','IN','🇮🇳',1,19),
('Germany','DE','🇩🇪',1,20),
('France','FR','🇫🇷',1,21),
('Netherlands','NL','🇳🇱',1,22),
('Switzerland','CH','🇨🇭',1,23),
('Brunei','BN','🇧🇳',1,24),
('Other','--','🌐',1,99);
