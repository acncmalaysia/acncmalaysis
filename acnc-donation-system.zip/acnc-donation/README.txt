═══════════════════════════════════════════════════════
  ACNC MISSION DONATION SYSTEM — Setup Guide
  Version 3.0 | All Christian Nations Connect
═══════════════════════════════════════════════════════

FILES IN THIS PACKAGE
──────────────────────────────────────────
  index.php          → Public donation form (what donors see)
  login.php          → Admin login (separate URL, hidden from donors)
  submit.php         → Donation form processor (secure backend)
  config.php         → ★ EDIT THIS FIRST — DB credentials & settings
  setup.sql          → Run once in phpMyAdmin to create all tables
  setup_check.php    → Diagnostic page — check server compatibility
  .htaccess          → Security rules for Apache server
  data/              → Stores site content JSON (auto-created)

  admin/
    dashboard.php    → Full admin panel (donations, analytics, rates, backup)
    users.php        → User management (super_admin only)
    change_password.php → Password change page
    export.php       → CSV & JSON backup downloads
    logout.php       → Secure logout handler


STEP 1 — GET WEB HOSTING
──────────────────────────────────────────
Requirements:
  ✅ PHP 7.4 or higher (PHP 8.x recommended)
  ✅ MySQL 5.7 or higher
  ✅ Apache with mod_rewrite
  ✅ SSL/HTTPS certificate (free via Let's Encrypt)

Recommended hosts:
  • Hostinger   hostinger.com   ~$3–5/month
  • Namecheap   namecheap.com   ~$3–5/month
  • SiteGround  siteground.com  ~$5–10/month


STEP 2 — CREATE MYSQL DATABASE
──────────────────────────────────────────
In your hosting control panel (cPanel):
  1. Go to MySQL Databases
  2. Create database:  acnc_donation
  3. Create user:      acnc_user
  4. Set a strong password for the user
  5. Add user to database — grant ALL PRIVILEGES
  6. Note: database name, username, password, host


STEP 3 — EDIT config.php
──────────────────────────────────────────
Open config.php and fill in your values:

  define('DB_HOST',  'localhost');
  define('DB_NAME',  'acnc_donation');   ← your database name
  define('DB_USER',  'acnc_user');       ← your username
  define('DB_PASS',  'YourPassword!');   ← your password

  define('SITE_URL', 'https://yourdomain.com');

★ Do NOT change anything else — admin users are
  managed inside the Admin Panel after setup.


STEP 4 — UPLOAD FILES
──────────────────────────────────────────
Use FileZilla (free) or your host's File Manager:

  Upload to public_html/ maintaining this structure:
    public_html/
    ├── .htaccess
    ├── index.php
    ├── login.php
    ├── submit.php
    ├── config.php
    ├── setup.sql
    ├── setup_check.php
    ├── data/           (empty folder)
    └── admin/
        ├── .htaccess
        ├── dashboard.php
        ├── users.php
        ├── change_password.php
        ├── export.php
        └── logout.php


STEP 5 — RUN DATABASE SETUP
──────────────────────────────────────────
  1. Log into your hosting panel
  2. Open phpMyAdmin
  3. Click your database name (left sidebar)
  4. Click the SQL tab
  5. Open setup.sql, copy ALL the text
  6. Paste into phpMyAdmin SQL box
  7. Click Go
  8. ✓ "X queries executed successfully"

  If upgrading from a previous version, also run:
  ALTER TABLE admin_users MODIFY role
    ENUM('super_admin','admin','editor','viewer')
    NOT NULL DEFAULT 'viewer';


STEP 6 — VERIFY EVERYTHING WORKS
──────────────────────────────────────────
  1. Visit: https://yourdomain.com/setup_check.php
     → All checks should show ✅

  2. Visit: https://yourdomain.com/
     → Public donation form appears

  3. Visit: https://yourdomain.com/login.php
     Username: admin
     Password: Admin@12345
     → You will be FORCED to change password immediately

  4. After verifying, DELETE from your server:
     ✕ setup_check.php
     ✕ setup.sql


ACCESSING FROM YOUR DEVICES
──────────────────────────────────────────
  Public donation page:  https://yourdomain.com/
  Admin login:           https://yourdomain.com/login.php

  Works on:
  ✅ Mac (Safari, Chrome, Firefox)
  ✅ Windows PC (Chrome, Edge, Firefox)
  ✅ Android tablet (Chrome)
  ✅ iPhone / Android phone (Safari, Chrome)

  No app to install — just open in any browser!


ADMIN ROLES EXPLAINED
──────────────────────────────────────────
  🔴 Super Admin — Everything + user management
  🟠 Admin       — Donations, partners, rates, content, backup
  🟢 Editor      — View & write donations + exchange rates only
  🔵 Viewer      — Read-only: view donations only

  Manage users at: https://yourdomain.com/admin/users.php
  (Super Admin only)


ADMIN DASHBOARD TABS
──────────────────────────────────────────
  🏠 Overview    — Stats, charts, recent donations
  📊 Donations   — Full searchable/filterable table
                   Filter by: name, date, currency, missionary,
                   fund type, date range
                   🧾 View & print receipts per donation
  📈 Analytics   — Monthly trend charts, top missionaries,
                   currency & fund breakdowns
  👥 Partners    — Add/hide/delete missionary partners
  💱 Rates       — Set exchange rates for 14 currencies
  💾 Backup      — Download CSV or full JSON backup


DONATION RECEIPTS
──────────────────────────────────────────
  Every donation has a 🧾 View button in the Donations tab.
  The receipt shows:
    • Reference number (ACNC-XXXXX)
    • Donor name, email, phone, country
    • Donation amount + MYR equivalent
    • Missionary partner & fund
    • Date & time
    • Whether monthly recurring
  Click 🖨 Print or 📋 Copy Details from the receipt.


BACKING UP YOUR DATA
──────────────────────────────────────────
  Admin Panel → 💾 Backup tab:

  ⬇ Download CSV   → Excel/Numbers/Google Sheets
  ⬇ Download JSON  → Full backup of all data

  Save to:
  ✅ Google Drive
  ✅ iCloud Drive
  ✅ OneDrive
  ✅ Your computer

  Recommended: backup weekly.


SECURITY FEATURES
──────────────────────────────────────────
  • bcrypt password hashing (cost 12)
  • 5-attempt brute force lockout (15 min)
  • Session fingerprinting (anti-hijack)
  • 30-minute idle session timeout
  • CSRF tokens on every form
  • Rate limiting on donation submissions
  • Full audit log (every admin action + IP)
  • Login history (all attempts logged)
  • Security HTTP headers
  • .htaccess protection on all folders
  • SQL injection protection (PDO prepared statements)
  • XSS protection (output escaping everywhere)


TROUBLESHOOTING
──────────────────────────────────────────
  "Database connection failed"
  → Check DB_HOST, DB_NAME, DB_USER, DB_PASS in config.php

  "Admin login doesn't work"
  → Username and password are case-sensitive
  → Default: admin / Admin@12345

  "Blank white page"
  → Run setup_check.php to diagnose
  → Enable PHP 7.4+ in your hosting panel

  "Permission denied" on data/ folder
  → Set permissions to 755 via your file manager

═══════════════════════════════════════════════════════
  Need help? Contact: donations@bbcmhk.org
═══════════════════════════════════════════════════════
