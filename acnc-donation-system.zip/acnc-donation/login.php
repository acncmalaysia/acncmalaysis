<?php
session_start();
require_once 'config.php';
send_security_headers();

if (is_logged_in()) { header('Location: admin/dashboard.php'); exit; }

$error = ''; $warn = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify($_POST['csrf_token'] ?? '')) {
        $error = 'Security token error. Please refresh and try again.';
    } else {
        $username = strtolower(trim($_POST['username'] ?? ''));
        $password = $_POST['password'] ?? '';
        $ip = filter_var(explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? '')[0], FILTER_VALIDATE_IP) ?: '0.0.0.0';

        // Lockout check
        if (check_login_lockout($username)) {
            $remaining = ceil(get_remaining_lockout($username) / 60);
            $error = "Account temporarily locked after too many failed attempts. Try again in {$remaining} minute(s).";
        } else {
            $db = getDB();
            $stmt = $db->prepare("SELECT * FROM admin_users WHERE username = ? AND active = 1 LIMIT 1");
            $stmt->execute([$username]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password_hash'])) {
                // Success
                log_login_attempt($username, true, $ip);
                session_regenerate_id(true);
                $_SESSION['acnc_uid']      = $user['id'];
                $_SESSION['acnc_username'] = $user['username'];
                $_SESSION['acnc_role']     = $user['role'];
                $_SESSION['acnc_name']     = $user['full_name'] ?: $user['username'];
                $_SESSION['login_time']    = time();
                $_SESSION['csrf_token']    = bin2hex(random_bytes(32));
                $_SESSION['fp']            = md5($_SERVER['HTTP_USER_AGENT'] . $_SERVER['REMOTE_ADDR']);

                // Update last login
                $db->prepare("UPDATE admin_users SET last_login=NOW(), last_login_ip=? WHERE id=?")
                   ->execute([$ip, $user['id']]);

                audit('LOGIN', "User logged in from $ip");

                // Force password change?
                if ($user['force_pw_change']) {
                    header('Location: admin/change_password.php?forced=1'); exit;
                }
                header('Location: admin/dashboard.php'); exit;

            } else {
                // Failure
                log_login_attempt($username, false, $ip);
                sleep(1); // slow brute force
                $db2 = getDB();
                $st2 = $db2->prepare("SELECT COUNT(*) FROM login_attempts WHERE username=? AND attempted_at > DATE_SUB(NOW(), INTERVAL ? MINUTE) AND success=0");
                $st2->execute([$username, LOCKOUT_MINUTES]);
                $fails = (int)$st2->fetchColumn();
                $left  = MAX_LOGIN_ATTEMPTS - $fails;
                if ($left > 0) {
                    $error = "Invalid username or password. {$left} attempt(s) remaining before lockout.";
                } else {
                    $error = "Account locked for ".LOCKOUT_MINUTES." minutes due to too many failed attempts.";
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Login — <?= h(SITE_NAME) ?></title>
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@600;700&family=DM+Sans:wght@400;500;600&display=swap" rel="stylesheet">
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'DM Sans',sans-serif;background:linear-gradient(140deg,#0d1b3e,#0F3460,#1a3a6e);min-height:100vh;display:flex;align-items:center;justify-content:center;padding:1rem}
.card{background:#fff;border-radius:20px;padding:2.5rem 2rem;width:100%;max-width:400px;box-shadow:0 24px 64px rgba(0,0,0,.35)}
.brand{text-align:center;margin-bottom:2rem}
.brand .cross{font-size:2.5rem;color:#C9A84C;line-height:1}
.brand h1{font-family:'Cormorant Garamond',serif;font-size:1.7rem;font-weight:700;color:#1A1A2E;margin-top:.4rem}
.brand p{font-size:.78rem;color:#7A7A8C;margin-top:.2rem}
.fg{margin-bottom:1rem}
.fg label{display:block;font-size:.72rem;font-weight:700;color:#7A7A8C;text-transform:uppercase;letter-spacing:.4px;margin-bottom:.32rem}
.fg input{width:100%;border:1.5px solid #e4e4e4;border-radius:9px;padding:.68rem .9rem;font-family:'DM Sans',sans-serif;font-size:.9rem;outline:none;transition:border .2s}
.fg input:focus{border-color:#C9A84C;box-shadow:0 0 0 3px rgba(201,168,76,.12)}
.pw-wrap{position:relative}
.pw-wrap input{padding-right:2.8rem}
.pw-toggle{position:absolute;right:.75rem;top:50%;transform:translateY(-50%);background:none;border:none;cursor:pointer;color:#7A7A8C;font-size:.85rem;padding:.2rem}
.btn-login{width:100%;background:linear-gradient(135deg,#0F3460,#1A1A2E);color:#fff;border:none;border-radius:10px;padding:.9rem;font-family:'Cormorant Garamond',serif;font-size:1.2rem;font-weight:600;cursor:pointer;transition:all .3s;margin-top:.5rem}
.btn-login:hover{background:linear-gradient(135deg,#C9A84C,#E8C97A);color:#1A1A2E}
.alert{border-radius:8px;padding:.7rem 1rem;font-size:.83rem;margin-bottom:1rem;display:flex;align-items:flex-start;gap:.5rem;line-height:1.45}
.alert-err{background:#FFE4E6;border:1px solid rgba(193,18,31,.2);color:#C1121F}
.alert-warn{background:#FFF8E1;border:1px solid rgba(255,193,7,.3);color:#856404}
.back{display:block;text-align:center;margin-top:1.2rem;font-size:.78rem;color:#7A7A8C;text-decoration:none}
.back:hover{color:#C9A84C}
.shield{display:flex;align-items:center;justify-content:center;gap:.4rem;margin-top:1.2rem;font-size:.7rem;color:#bbb}
</style>
</head>
<body>
<div class="card">
  <div class="brand">
    <div class="cross">✛</div>
    <h1>Admin Login</h1>
    <p><?= h(SITE_NAME) ?></p>
  </div>

  <?php if ($error): ?>
  <div class="alert alert-err">⚠️ <?= h($error) ?></div>
  <?php endif; ?>

  <form method="POST" autocomplete="off" novalidate>
    <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
    <div class="fg">
      <label>Username</label>
      <input type="text" name="username" placeholder="Enter username" autocomplete="username" required autofocus>
    </div>
    <div class="fg">
      <label>Password</label>
      <div class="pw-wrap">
        <input type="password" name="password" id="pw" placeholder="••••••••••" autocomplete="current-password" required>
        <button type="button" class="pw-toggle" onclick="togglePw()">👁</button>
      </div>
    </div>
    <button type="submit" class="btn-login">Sign In →</button>
  </form>

  <a href="index.php" class="back">← Back to donation portal</a>
  <div class="shield">🔒 Secured connection · All activity is logged</div>
</div>
<script>
function togglePw(){const i=document.getElementById('pw');i.type=i.type==='password'?'text':'password';}
</script>
</body>
</html>
