<?php
session_start();
require_once 'config.php';
require_once 'lang.php';
send_security_headers();

header('Content-Type: application/json');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success'=>false,'error'=>'Method not allowed.']); exit;
}

// CSRF
if (!csrf_verify($_POST['csrf_token'] ?? '')) {
    http_response_code(403);
    echo json_encode(['success'=>false,'error'=>'Security token mismatch. Please refresh the page and try again.']); exit;
}

// Rate limit: 5 per IP per 10 min
$ip = filter_var(explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? '')[0], FILTER_VALIDATE_IP) ?: '0.0.0.0';
$db = getDB();
$rl = $db->prepare("SELECT COUNT(*) FROM donations WHERE ip_address=? AND created_at > DATE_SUB(NOW(),INTERVAL 10 MINUTE)");
$rl->execute([$ip]);
if ((int)$rl->fetchColumn() >= 5) {
    http_response_code(429);
    echo json_encode(['success'=>false,'error'=>'Too many submissions from your connection. Please wait a few minutes.']); exit;
}

// Language for email
$lang = 'en';
if (!empty($_POST['lang']) && in_array($_POST['lang'], ['en','zh','ms'])) {
    $lang = $_POST['lang'];
} elseif (!empty($_COOKIE['acnc_lang']) && in_array($_COOKIE['acnc_lang'], ['en','zh','ms'])) {
    $lang = $_COOKIE['acnc_lang'];
}
$tl = get_lang_strings($lang);

// Sanitise
function clean($v){ return trim(strip_tags((string)$v)); }

$first     = clean($_POST['first_name'] ?? '');
$last      = clean($_POST['last_name']  ?? '');
$email     = filter_var(clean($_POST['email'] ?? ''), FILTER_VALIDATE_EMAIL);
$phone     = clean($_POST['phone']      ?? '');
$country   = clean($_POST['country']    ?? '');
$amount    = (float)(clean($_POST['amount'] ?? '0'));
$currency  = strtoupper(preg_replace('/[^A-Z]/','', clean($_POST['currency'] ?? 'MYR')));
$missionary= mb_substr(clean($_POST['missionary'] ?? ''), 0, 255);
$fund      = clean($_POST['fund'] ?? 'General');
$monthly   = !empty($_POST['monthly'])  ? 1 : 0;
$cover_fee = !empty($_POST['cover_fee'])? 1 : 0;
$remarks   = mb_substr(clean($_POST['remarks'] ?? ''), 0, 500);

// Validate
$errors = [];
if (!$first)                        $errors[] = 'First name is required.';
if (!$last)                         $errors[] = 'Last name is required.';
if (!$email)                        $errors[] = 'A valid email address is required.';
if (!$missionary)                   $errors[] = 'Please select a Missionary Partner.';
if ($amount <= 0 || $amount > 999999) $errors[] = 'Please enter a valid donation amount.';

$allowed_currencies = ['MYR','USD','SGD','AUD','GBP','EUR','HKD','TWD','JPY','KRW','IDR','PHP','THB','INR'];
if (!in_array($currency, $allowed_currencies)) $currency = 'MYR';

$allowed_funds = ['General','Evangelism','Church Plant','Humanitarian','Education','Building'];
if (!in_array($fund, $allowed_funds)) $fund = 'General';

if ($errors) {
    echo json_encode(['success'=>false,'error'=>implode(' ', $errors)]); exit;
}

// Exchange rate
$rateRow = $db->prepare("SELECT rate_to_myr FROM exchange_rates WHERE currency=?");
$rateRow->execute([$currency]);
$rate = (float)($rateRow->fetchColumn() ?: 1);

$myr_equiv = round($amount * $rate, 2);
$fee_amt   = $cover_fee ? round(($myr_equiv * 0.025) + 0.30, 2) : 0.00;
$total_myr = round($myr_equiv + $fee_amt, 2);

// Generate reference
$count = (int)$db->query("SELECT COUNT(*) FROM donations")->fetchColumn();
$ref   = 'ACNC-' . str_pad($count + 1, 5, '0', STR_PAD_LEFT);

// Save to DB
$db->prepare("
    INSERT INTO donations
      (ref,first_name,last_name,email,phone,country,
       amount,currency,myr_equivalent,cover_fee,fee_amount,total_myr,
       missionary,fund,monthly,remarks,ip_address,created_at)
    VALUES
      (:ref,:first,:last,:email,:phone,:country,
       :amount,:currency,:myr,:cover_fee,:fee,:total,
       :missionary,:fund,:monthly,:remarks,:ip,NOW())")
->execute([
    ':ref'        => $ref,
    ':first'      => $first,
    ':last'       => $last,
    ':email'      => $email,
    ':phone'      => $phone,
    ':country'    => $country,
    ':amount'     => $amount,
    ':currency'   => $currency,
    ':myr'        => $myr_equiv,
    ':cover_fee'  => $cover_fee,
    ':fee'        => $fee_amt,
    ':total'      => $total_myr,
    ':missionary' => $missionary,
    ':fund'       => $fund,
    ':monthly'    => $monthly,
    ':remarks'    => $remarks,
    ':ip'         => $ip,
]);

// ── Send confirmation email to donor ─────────────────────
$sym_map = ['MYR'=>'RM','USD'=>'$','SGD'=>'S$','AUD'=>'A$','GBP'=>'£','EUR'=>'€',
            'HKD'=>'HK$','TWD'=>'NT$','JPY'=>'¥','KRW'=>'₩','IDR'=>'Rp','PHP'=>'₱','THB'=>'฿','INR'=>'₹'];
$sym = $sym_map[$currency] ?? $currency.' ';
$dateStr = date('d F Y, H:i');
$myrLine = ($currency !== 'MYR') ? "\n   MYR Equivalent : RM ".number_format($total_myr,2) : '';
$recurLine = $monthly ? "\n   Donation Type   : Monthly Recurring (every month)" : "\n   Donation Type   : One-time gift";

// ── Build localised email ─────────────────────────────────
$fee_line     = $cover_fee ? "\n   " . $tl['summary_fee']   . "  : RM " . number_format($fee_amt,2) : "";
$phone_line   = $phone   ? "\n   " . $tl['phone_label']     . "       : {$phone}"   : "";
$country_line = $country ? "\n   " . $tl['country_label']   . "      : {$country}" : "";
$remarks_line = $remarks  ? "\n   " . $tl['remarks_label']  . "      : {$remarks}" : "";

// Greeting & thank-you based on language
$greetings = [
    'en' => "Dear {$first} {$last},\n\nThank you for your generous donation to ACNC Mission.\nYour gift advances God's Kingdom among unreached peoples.",
    'zh' => "親愛的 {$first} {$last}，\n\n感謝您對宣教工作的慷慨奉獻。\n您的奉獻正參與福音進入深山，觸及未得之民的生命。",
    'ms' => "Yang dihormati {$first} {$last},\n\nTerima kasih atas derma anda yang murah hati kepada Misi ACNC.\nDerma anda membantu menyebarkan Injil kepada bangsa yang belum mendengarnya.",
];
$blessings = [
    'en' => "✛ God bless you for your faithful giving.\n\nACNC — All Christian Nations Connect",
    'zh' => "✛ 感謝您忠心的奉獻，願神賜福給您。\n\nACNC — 萬國基督徒連結",
    'ms' => "✛ Tuhan memberkati anda atas pemberian yang setia.\n\nACNC — All Christian Nations Connect",
];
$section_receipt = ['en'=>'OFFICIAL DONATION RECEIPT','zh'=>'正式奉獻收據','ms'=>'RESIT DERMA RASMI'];
$section_donor   = ['en'=>'DONOR DETAILS',           'zh'=>'奉獻者資料',    'ms'=>'MAKLUMAT PENDERMA'];
$section_donation= ['en'=>'DONATION DETAILS',         'zh'=>'奉獻詳情',      'ms'=>'BUTIRAN DERMA'];
$footer_note     = [
    'en' => "Please keep this email as your official donation record.\nFor tax receipts or queries: donations@bbcmhk.org",
    'zh' => "請保留此電郵作為您的正式奉獻憑證。\n如需稅務收據或查詢，請聯絡：donations@bbcmhk.org",
    'ms' => "Sila simpan e-mel ini sebagai rekod derma rasmi anda.\nUntuk resit cukai atau pertanyaan: donations@bbcmhk.org",
];
$auto_note = [
    'en' => "This is an automated confirmation. Please do not reply.",
    'zh' => "此為自動確認郵件，請勿回覆。",
    'ms' => "Ini adalah pengesahan automatik. Sila jangan balas.",
];

$subject = "✛ " . $tl['modal_title'] . " — {$ref} | ACNC Mission";
$body = $greetings[$lang] . "\n\n"
    . "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
    . "  ✛  " . $section_receipt[$lang] . "\n"
    . "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
    . "  " . $section_donor[$lang] . "\n"
    . "   " . $tl['fname_label']   . "  : {$first} {$last}\n"
    . "   " . $tl['email_label']   . "   : {$email}"
    . $phone_line . $country_line . "\n\n"
    . "  " . $section_donation[$lang] . "\n"
    . "   " . $tl['summary_amount'] . "     : {$sym}{$amount} {$currency}{$myrLine}"
    . $fee_line . "\n"
    . "   " . $tl['summary_total']  . "    : RM {$total_myr}\n"
    . "   " . $tl['miss_title']     . " : {$missionary}\n"
    . "   " . $tl['fund_label']     . "   : {$fund}"
    . $recurLine . $remarks_line . "\n\n"
    . "   " . "Ref" . "              : {$ref}\n"
    . "   " . "Date"             . "             : {$dateStr}\n\n"
    . "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
    . $footer_note[$lang] . "\n\n"
    . $blessings[$lang] . "\n\n"
    . "──────────────────────────────────────────\n"
    . $auto_note[$lang] . "\n"
    . "Reference: {$ref}\n"
    . "──────────────────────────────────────────\n";

$headers  = "From: ACNC Mission <noreply@".parse_url(SITE_URL,PHP_URL_HOST).">\r\n";
$headers .= "Reply-To: ".CONTACT_EMAIL."\r\n";
$headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
$headers .= "X-Mailer: ACNC-DonationSystem/3.0\r\n";

@mail($email, $subject, $body, $headers);

// ── Notify admin ──────────────────────────────────────────
$adminSubject = "New Donation {$ref} — {$first} {$last} · {$sym}{$amount} {$currency}";
$adminBody = <<<AMAIL
New donation received on {$dateStr}.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  NEW DONATION — {$ref}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  DONOR
   Name       : {$first} {$last}
   Email      : {$email}
   Phone      : {$phone}
   Country    : {$country}

  DONATION
   Amount     : {$sym}{$amount} {$currency}
   MYR Total  : RM {$total_myr}
   Missionary : {$missionary}
   Fund       : {$fund}
   Type       : {$recurLine}
   Cover Fee  : {$coverFeeLabel}

  SYSTEM
   Reference  : {$ref}
   IP Address : {$ip}
   Timestamp  : {$dateStr}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Login to admin panel to view full record.
AMAIL;
$coverFeeLabel = $cover_fee ? "Yes (RM {$fee_amt})" : "No";
@mail(CONTACT_EMAIL, $adminSubject, $adminBody, $headers);

// Rotate CSRF
$_SESSION['csrf_token'] = bin2hex(random_bytes(32));

$CURRSYM = ['MYR'=>'RM','USD'=>'$','SGD'=>'S$','AUD'=>'A$','GBP'=>'£','EUR'=>'€',
            'HKD'=>'HK$','TWD'=>'NT$','JPY'=>'¥','KRW'=>'₩','IDR'=>'Rp','PHP'=>'₱','THB'=>'฿','INR'=>'₹'];

echo json_encode([
    'success'     => true,
    'ref'         => $ref,
    'total_myr'   => number_format($total_myr, 2),
    'name'        => $first.' '.$last,
    'missionary'  => $missionary,
    'currency'    => $currency,
    'sym'         => $sym,
    'amount'      => number_format($amount, 2),
    'fund'        => $fund,
    'monthly'     => (bool)$monthly,
    'date'        => date('d F Y'),
    'email'       => $email,
]);
