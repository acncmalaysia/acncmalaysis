<?php
session_start();
require_once 'config.php';
require_once 'lang.php';
send_security_headers();
$db = getDB();

// Language selection — cookie persists choice
$allowed_langs = ['en', 'zh', 'ms'];
if (isset($_GET['lang']) && in_array($_GET['lang'], $allowed_langs)) {
    setcookie('acnc_lang', $_GET['lang'], time() + 60*60*24*365, '/', '', !empty($_SERVER['HTTPS']), true);
    $_COOKIE['acnc_lang'] = $_GET['lang'];
}
$lang = $_COOKIE['acnc_lang'] ?? 'en';
if (!in_array($lang, $allowed_langs)) $lang = 'en';
$t = get_lang_strings($lang);

$missionaries = $db->query("SELECT name, field FROM missionaries WHERE active=1 ORDER BY name")->fetchAll();
$rates_rows   = $db->query("SELECT currency, rate_to_myr FROM exchange_rates")->fetchAll();
$rates = [];
foreach ($rates_rows as $r) { $rates[$r['currency']] = (float)$r['rate_to_myr']; }

// Load active currencies from DB (fallback to defaults if table missing)
try {
    $cur_rows = $db->query("SELECT code,name,flag,symbol FROM currency_settings WHERE active=1 ORDER BY sort_order ASC, code ASC")->fetchAll();
} catch (Exception $e) {
    $cur_rows = [
        ['code'=>'MYR','name'=>'Malaysian Ringgit','flag'=>'🇲🇾','symbol'=>'RM'],
        ['code'=>'USD','name'=>'US Dollar','flag'=>'🇺🇸','symbol'=>'$'],
        ['code'=>'SGD','name'=>'Singapore Dollar','flag'=>'🇸🇬','symbol'=>'S$'],
        ['code'=>'AUD','name'=>'Australian Dollar','flag'=>'🇦🇺','symbol'=>'A$'],
        ['code'=>'GBP','name'=>'British Pound','flag'=>'🇬🇧','symbol'=>'£'],
        ['code'=>'EUR','name'=>'Euro','flag'=>'🇪🇺','symbol'=>'€'],
        ['code'=>'HKD','name'=>'Hong Kong Dollar','flag'=>'🇭🇰','symbol'=>'HK$'],
        ['code'=>'TWD','name'=>'Taiwan Dollar','flag'=>'🇹🇼','symbol'=>'NT$'],
        ['code'=>'JPY','name'=>'Japanese Yen','flag'=>'🇯🇵','symbol'=>'¥'],
        ['code'=>'KRW','name'=>'Korean Won','flag'=>'🇰🇷','symbol'=>'₩'],
        ['code'=>'IDR','name'=>'Indonesian Rupiah','flag'=>'🇮🇩','symbol'=>'Rp'],
        ['code'=>'PHP','name'=>'Philippine Peso','flag'=>'🇵🇭','symbol'=>'₱'],
        ['code'=>'THB','name'=>'Thai Baht','flag'=>'🇹🇭','symbol'=>'฿'],
        ['code'=>'INR','name'=>'Indian Rupee','flag'=>'🇮🇳','symbol'=>'₹'],
    ];
}

// Load active countries from DB (fallback to defaults if table missing)
try {
    $country_rows = $db->query("SELECT name,flag FROM donation_countries WHERE active=1 ORDER BY sort_order ASC, name ASC")->fetchAll();
} catch (Exception $e) {
    $country_rows = [
        ['name'=>'Malaysia','flag'=>'🇲🇾'],['name'=>'Singapore','flag'=>'🇸🇬'],
        ['name'=>'Hong Kong','flag'=>'🇭🇰'],['name'=>'Australia','flag'=>'🇦🇺'],
        ['name'=>'United States','flag'=>'🇺🇸'],['name'=>'United Kingdom','flag'=>'🇬🇧'],
        ['name'=>'Taiwan','flag'=>'🇹🇼'],['name'=>'China','flag'=>'🇨🇳'],
        ['name'=>'Japan','flag'=>'🇯🇵'],['name'=>'South Korea','flag'=>'🇰🇷'],
        ['name'=>'Indonesia','flag'=>'🇮🇩'],['name'=>'Philippines','flag'=>'🇵🇭'],
        ['name'=>'Thailand','flag'=>'🇹🇭'],['name'=>'Vietnam','flag'=>'🇻🇳'],
        ['name'=>'India','flag'=>'🇮🇳'],['name'=>'Other','flag'=>'🌐'],
    ];
}
$csrf = csrf_token();

define('MONTHLY_GOAL', 5000);
$this_month_total = (float)$db->query("SELECT COALESCE(SUM(total_myr),0) FROM donations WHERE created_at >= DATE_FORMAT(NOW(),'%Y-%m-01')")->fetchColumn();
$goal_pct = min(100, round(($this_month_total / MONTHLY_GOAL) * 100));

$current_url = (empty($_SERVER['HTTPS']) ? 'http' : 'https') . '://' . $_SERVER['HTTP_HOST'] . strtok($_SERVER['REQUEST_URI'], '?');
?>
<!DOCTYPE html>
<html lang="<?= h($t['html_lang']) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="<?= h(SITE_NAME) ?> — <?= h($t['hero_sub']) ?>">
<title><?= h(SITE_NAME) ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@400;600;700&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
:root{
  --gold:#C9A84C;--gold-light:#E8C97A;--gold-pale:#F5EDD3;--gold-pale2:#FDF6E3;
  --dark:#1A1A2E;--dark3:#0F3460;--cream:#FAF8F3;--white:#fff;
  --text:#1E1E2E;--muted:#7A7A8C;--light:#F0EEE8;
  --success:#1B7A4A;--success-bg:#D6F0E3;--danger:#C1121F;--danger-bg:#FFE4E6;
  --border:rgba(201,168,76,0.22);--shadow:0 2px 16px rgba(0,0,0,.07);--shadow-lg:0 8px 32px rgba(0,0,0,.12)
}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'DM Sans',sans-serif;background:var(--cream);color:var(--text);min-height:100vh}

/* ── NAV ── */
nav{background:var(--dark);display:flex;align-items:center;justify-content:space-between;padding:0 1.4rem;height:58px;position:sticky;top:0;z-index:100;border-bottom:2px solid var(--gold)}
.nav-logo{display:flex;align-items:center;gap:.5rem;font-family:'Cormorant Garamond',serif;color:var(--gold);font-size:1.25rem;font-weight:700;letter-spacing:.5px;text-decoration:none}
.nav-right{display:flex;gap:.2rem;align-items:center}
.nav-btn{display:flex;align-items:center;gap:.35rem;background:none;border:none;color:rgba(255,255,255,.65);font-family:'DM Sans',sans-serif;font-size:.78rem;cursor:pointer;padding:.38rem .7rem;border-radius:7px;transition:all .2s;font-weight:500;white-space:nowrap}
.nav-btn:hover,.nav-btn.active{background:var(--gold);color:var(--dark);font-weight:600}

/* Language switcher */
.lang-switcher{display:flex;align-items:center;gap:.2rem;margin-left:.5rem;border-left:1px solid rgba(255,255,255,.12);padding-left:.6rem}
.lang-btn{background:none;border:1px solid transparent;color:rgba(255,255,255,.45);font-family:'DM Sans',sans-serif;font-size:.7rem;font-weight:600;cursor:pointer;padding:.22rem .5rem;border-radius:5px;transition:all .2s;white-space:nowrap;text-decoration:none}
.lang-btn:hover{color:rgba(255,255,255,.85);border-color:rgba(255,255,255,.2)}
.lang-btn.active{background:var(--gold);color:var(--dark);border-color:var(--gold)}

/* Mobile hamburger */
.hamburger{display:none;flex-direction:column;gap:4px;background:none;border:none;cursor:pointer;padding:.4rem;border-radius:6px}
.hamburger span{width:20px;height:2px;background:rgba(255,255,255,.65);border-radius:2px;transition:all .3s;display:block}
.hamburger.open span:nth-child(1){transform:rotate(45deg) translate(4px,4px)}
.hamburger.open span:nth-child(2){opacity:0}
.hamburger.open span:nth-child(3){transform:rotate(-45deg) translate(4px,-4px)}
.mobile-menu{display:none;flex-direction:column;background:var(--dark);border-top:1px solid rgba(255,255,255,.08);padding:.5rem 1rem .7rem}
.mobile-menu.open{display:flex}
.mobile-menu .nav-btn{justify-content:flex-start;padding:.55rem .7rem;border-radius:8px}
.mobile-lang{display:flex;gap:.35rem;padding:.5rem .7rem;border-top:1px solid rgba(255,255,255,.06);margin-top:.3rem}
@media(max-width:580px){.nav-right{display:none}.hamburger{display:flex}}

.admin-dot{width:8px;height:8px;border-radius:50%;background:rgba(255,255,255,.1);cursor:pointer;margin-left:.4rem;transition:all .2s}
.admin-dot:hover{background:rgba(201,168,76,.45)}

/* ── PAGES ── */
.page{display:none}.page.active{display:block}

/* ── HERO ── */
.hero{background:linear-gradient(140deg,#0d1b3e 0%,var(--dark3) 55%,#1a3a6e 100%);color:#fff;text-align:center;padding:3rem 1rem 2.5rem;position:relative;overflow:hidden}
.hero::after{content:'✝';position:absolute;top:-10px;right:30px;font-size:9rem;opacity:.04;color:var(--gold);pointer-events:none;font-family:serif;line-height:1}
.hero-badge{display:inline-flex;align-items:center;gap:.4rem;background:rgba(201,168,76,.18);border:1px solid rgba(201,168,76,.35);border-radius:20px;padding:.28rem .85rem;font-size:.72rem;color:var(--gold-light);font-weight:600;letter-spacing:.5px;margin-bottom:.85rem;text-transform:uppercase}
.hero h1{font-family:'Cormorant Garamond',serif;font-size:2.3rem;font-weight:700;color:var(--gold-light);margin-bottom:.45rem;line-height:1.15}
.hero p{font-size:.88rem;color:rgba(255,255,255,.62);max-width:460px;margin:0 auto 1.2rem}
.goal-bar-wrap{max-width:380px;margin:0 auto;text-align:left}
.goal-header{display:flex;justify-content:space-between;font-size:.72rem;color:rgba(255,255,255,.6);margin-bottom:.35rem;font-weight:500}
.goal-header strong{color:var(--gold-light);font-weight:700}
.goal-track{height:8px;background:rgba(255,255,255,.12);border-radius:20px;overflow:hidden}
.goal-fill{height:100%;background:linear-gradient(90deg,var(--gold),var(--gold-light));border-radius:20px;transition:width 1.2s cubic-bezier(.4,0,.2,1);min-width:0;width:0}

/* ── CONTAINER ── */
.container{max-width:760px;margin:0 auto;padding:1.6rem 1rem 3rem}

/* ── CARD ── */
.card{background:var(--white);border-radius:16px;padding:1.5rem;box-shadow:var(--shadow);border:1px solid rgba(0,0,0,.04);margin-bottom:1.1rem}
.card-header{display:flex;align-items:center;gap:.7rem;margin-bottom:1rem;padding-bottom:.75rem;border-bottom:1px solid var(--light)}
.card-icon{width:34px;height:34px;border-radius:9px;background:var(--gold-pale);display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:1rem}
.card-header h3{font-family:'Cormorant Garamond',serif;font-size:1.15rem;font-weight:600;color:var(--dark)}
.card-sub{font-size:.73rem;color:var(--muted);margin-top:.1rem}

/* ── CURRENCY PILLS ── */
.cur-section-label{font-size:.7rem;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:.5px;margin-bottom:.5rem}
.currency-pills{display:flex;flex-wrap:wrap;gap:.35rem;margin-bottom:.6rem}
.cur-pill{display:inline-flex;align-items:center;gap:.25rem;border:1.5px solid #e4e4e4;border-radius:20px;padding:.26rem .6rem;background:#f7f7f7;cursor:pointer;transition:all .16s;font-size:.7rem;font-weight:600;color:var(--muted);white-space:nowrap;user-select:none}
.cur-pill:hover{border-color:var(--gold);background:var(--gold-pale2);color:#7a5500}
.cur-pill.selected{border-color:var(--gold);background:var(--gold);color:var(--dark);font-weight:700;box-shadow:0 2px 8px rgba(201,168,76,.3)}
.converted-pill{display:inline-flex;align-items:center;gap:.3rem;background:var(--gold-pale);border:1px solid var(--border);border-radius:8px;padding:.38rem .75rem;font-size:.8rem;font-weight:600;color:#7a5500;margin-top:.6rem}

/* ── AMOUNT ── */
.amount-display{display:flex;align-items:center;gap:.5rem;border:2px solid var(--dark);border-radius:12px;padding:.85rem 1.3rem;margin:.7rem 0 1rem;background:var(--white);transition:border .2s,box-shadow .2s}
.amount-display:focus-within{border-color:var(--gold);box-shadow:0 0 0 4px rgba(201,168,76,.12)}
.amount-display .cur-sym{font-size:1.25rem;color:var(--muted);align-self:flex-start;margin-top:.4rem;font-family:'Cormorant Garamond',serif}
.amount-display input{border:none;outline:none;font-size:2.5rem;font-weight:700;font-family:'Cormorant Garamond',serif;width:100%;text-align:right;color:var(--dark);background:transparent}

/* ── PRESETS ── */
.presets{display:grid;grid-template-columns:repeat(3,1fr);gap:.55rem;margin-bottom:1rem}
.preset-btn{border:1.5px solid #e2e2e2;border-radius:11px;padding:.9rem .4rem;background:#f7f7f7;cursor:pointer;transition:all .18s;display:flex;flex-direction:column;align-items:center;justify-content:center;user-select:none}
.preset-btn:hover{border-color:var(--gold);background:var(--gold-pale2);transform:translateY(-1px)}
.preset-btn.selected{border-color:var(--gold);background:var(--gold);color:#fff;box-shadow:0 4px 12px rgba(201,168,76,.3)}
.preset-btn .pa{font-size:1.3rem;font-family:'Cormorant Garamond',serif;font-weight:700;line-height:1;text-align:center;white-space:pre-line}

/* ── FORM ── */
.form-group{margin-bottom:.9rem;position:relative}
.form-group label{display:flex;align-items:center;gap:.3rem;font-size:.72rem;font-weight:600;color:var(--muted);margin-bottom:.3rem;text-transform:uppercase;letter-spacing:.4px}
.form-group input,.form-group select,.form-group textarea{width:100%;border:1.5px solid #e4e4e4;border-radius:9px;padding:.62rem .85rem;font-family:'DM Sans',sans-serif;font-size:.9rem;color:var(--text);outline:none;transition:border .2s,box-shadow .2s;background:#fff}
.form-group input:focus,.form-group select:focus,.form-group textarea:focus{border-color:var(--gold);box-shadow:0 0 0 3px rgba(201,168,76,.11)}
.form-group input.valid,.form-group select.valid{border-color:var(--success);box-shadow:0 0 0 3px rgba(27,122,74,.09)}
.form-group input.invalid,.form-group select.invalid{border-color:var(--danger);box-shadow:0 0 0 3px rgba(193,18,31,.08)}
.field-hint{font-size:.7rem;color:var(--muted);margin-top:.22rem}
.field-error{font-size:.7rem;color:var(--danger);margin-top:.22rem;display:none}
.form-group.has-error .field-error{display:block}
.form-group.has-error input,.form-group.has-error select{border-color:var(--danger)}
.val-icon{position:absolute;right:.75rem;top:2.25rem;font-size:.9rem;pointer-events:none;line-height:1}
.form-group select~.val-icon{right:2.2rem}
.char-count{font-size:.68rem;color:var(--muted);position:absolute;right:0;top:0;font-weight:500}
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:.7rem}
@media(max-width:480px){.form-row{grid-template-columns:1fr}}

/* ── CHECK CARDS ── */
.check-card{display:flex;align-items:flex-start;gap:.9rem;border:1.5px solid #ebebeb;border-radius:12px;padding:.95rem 1.05rem;cursor:pointer;margin-bottom:.7rem;transition:all .2s;background:#fafafa;user-select:none}
.check-card:hover,.check-card.checked{border-color:var(--gold);background:var(--gold-pale2)}
.check-icon{width:36px;height:36px;border-radius:9px;background:var(--light);display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:1rem;transition:background .2s}
.check-card.checked .check-icon{background:var(--gold)}
.check-title{font-size:.86rem;font-weight:600;color:var(--dark);margin-bottom:.12rem}
.check-sub{font-size:.77rem;color:var(--muted);line-height:1.4}
.check-amt{color:var(--gold);font-weight:700}

/* ── SUMMARY ── */
.donation-summary{background:var(--gold-pale2);border:1.5px solid var(--border);border-radius:14px;padding:1.1rem 1.3rem;margin-bottom:.9rem}
.summary-title{font-family:'Cormorant Garamond',serif;font-size:1rem;font-weight:700;color:var(--dark);margin-bottom:.7rem;padding-bottom:.5rem;border-bottom:1px solid var(--border)}
.summary-row{display:flex;justify-content:space-between;font-size:.84rem;margin-bottom:.32rem}
.summary-row .lbl{color:var(--muted);font-weight:500}
.summary-row .val{font-weight:600;color:var(--dark)}
.summary-total{display:flex;justify-content:space-between;font-size:.88rem;padding-top:.5rem;border-top:1px solid var(--border);margin-top:.4rem}
.summary-total .lbl{color:var(--dark);font-weight:700}
.summary-total .val{font-weight:700;color:var(--success);font-family:'Cormorant Garamond',serif;font-size:1.1rem}

/* ── SUBMIT ── */
.submit-btn{width:100%;background:linear-gradient(135deg,var(--dark3),var(--dark));color:#fff;border:none;border-radius:12px;padding:1rem;font-family:'Cormorant Garamond',serif;font-size:1.2rem;font-weight:600;cursor:pointer;transition:all .3s;display:flex;align-items:center;justify-content:center;gap:.5rem;margin-top:.3rem}
.submit-btn:hover:not(:disabled){background:linear-gradient(135deg,var(--gold),var(--gold-light));color:var(--dark);transform:translateY(-2px);box-shadow:0 8px 24px rgba(201,168,76,.38)}
.submit-btn:disabled{opacity:.6;cursor:not-allowed;transform:none}
.spinner{width:18px;height:18px;border:2.5px solid rgba(255,255,255,.3);border-top-color:#fff;border-radius:50%;animation:spin .7s linear infinite;display:none}
.submit-btn.loading .spinner{display:block}
.submit-btn.loading .btn-text{opacity:.7}
@keyframes spin{to{transform:rotate(360deg)}}
.error-box{background:var(--danger-bg);border:1px solid rgba(193,18,31,.2);border-radius:10px;padding:.7rem 1rem;font-size:.84rem;color:var(--danger);margin-bottom:.9rem;display:none;animation:slideIn .3s ease}
@keyframes slideIn{from{opacity:0;transform:translateY(-6px)}to{opacity:1;transform:translateY(0)}}
.privacy-note{display:flex;align-items:center;gap:.45rem;font-size:.76rem;color:var(--muted);margin-bottom:.9rem}

/* ── HOW TO GIVE ── */
.htg-hero{background:linear-gradient(140deg,#0d1b3e,var(--dark3),#1a3a6e);padding:2.6rem 1rem 2rem;text-align:center}
.country-tag{display:inline-flex;align-items:center;gap:.4rem;background:var(--dark);color:#fff;font-size:.7rem;font-weight:800;letter-spacing:1px;text-transform:uppercase;padding:.28rem .8rem;border-radius:4px;margin-bottom:.9rem}
.country-block{background:#fff;border-radius:16px;padding:1.4rem 1.5rem;box-shadow:var(--shadow);margin-bottom:1rem;border:1px solid rgba(0,0,0,.04)}
.country-block h3{font-family:'Cormorant Garamond',serif;font-size:1.18rem;font-weight:700;color:var(--dark);margin-bottom:.9rem;border-bottom:1px solid var(--light);padding-bottom:.55rem}
.bank-row{display:flex;gap:.5rem;margin-bottom:.4rem;font-size:.86rem;line-height:1.45}
.bank-lbl{color:var(--muted);font-weight:600;min-width:76px;flex-shrink:0}
.bank-val{color:var(--text);font-weight:500}
.bank-note{margin-top:.9rem;padding:.7rem .9rem;background:var(--gold-pale2);border-left:3px solid var(--gold);border-radius:0 8px 8px 0;font-size:.79rem;color:#5a4a00;line-height:1.55}
.two-col-layout{display:grid;grid-template-columns:1fr auto;gap:1.4rem;align-items:start}
.two-col-half{display:grid;grid-template-columns:1fr 1fr;gap:1rem}
@media(max-width:560px){.two-col-layout{grid-template-columns:1fr}.two-col-half{grid-template-columns:1fr}}
.qr-stack{display:flex;flex-direction:column;gap:.7rem;align-items:center}
.qr-item{text-align:center}
.qr-box{width:80px;height:80px;border-radius:10px;border:1.5px solid var(--border);background:var(--gold-pale2);display:flex;align-items:center;justify-content:center;overflow:hidden}
.qr-box img{width:100%;height:100%;object-fit:cover;border-radius:8px}
.qr-placeholder{font-size:.55rem;color:var(--muted);text-align:center;padding:.3rem;line-height:1.3}
.qr-lbl{font-size:.62rem;font-weight:700;color:var(--muted);text-transform:uppercase;margin-top:.3rem;line-height:1.2}
.section-divider{display:flex;align-items:center;gap:.7rem;margin-bottom:1.1rem;margin-top:.2rem}
.sdline{flex:1;height:1px;background:var(--light)}
.sd-text{font-family:'Cormorant Garamond',serif;font-size:1.25rem;font-weight:700;color:var(--dark);white-space:nowrap}
.steps-list{counter-reset:step;list-style:none;margin-top:.5rem}
.steps-list li{counter-increment:step;display:flex;gap:.65rem;align-items:flex-start;margin-bottom:.45rem;font-size:.86rem}
.steps-list li::before{content:counter(step);min-width:21px;height:21px;border-radius:50%;background:var(--dark3);color:#fff;font-size:.68rem;font-weight:700;display:flex;align-items:center;justify-content:center;flex-shrink:0;margin-top:1px}

/* ── SUCCESS MODAL ── */
.overlay{display:none;position:fixed;inset:0;background:rgba(10,10,30,.6);z-index:999;align-items:center;justify-content:center;padding:1rem;backdrop-filter:blur(4px)}
.overlay.open{display:flex}
.modal{background:#fff;border-radius:20px;max-width:480px;width:100%;box-shadow:0 24px 64px rgba(0,0,0,.3);overflow:hidden;max-height:90vh;overflow-y:auto}
.modal-header{background:linear-gradient(140deg,var(--dark),var(--dark3));padding:1.8rem 2rem 1.4rem;text-align:center;position:relative}
.modal-header::after{content:'✝';position:absolute;right:1.2rem;top:.3rem;font-size:5rem;opacity:.06;color:var(--gold-light);font-family:serif;line-height:1;pointer-events:none}
.modal-icon-ring{width:64px;height:64px;border-radius:50%;background:rgba(201,168,76,.18);border:3px solid var(--gold);display:flex;align-items:center;justify-content:center;margin:0 auto .8rem;font-size:1.9rem}
.modal-title{font-family:'Cormorant Garamond',serif;font-size:1.65rem;font-weight:700;color:var(--gold-light);margin-bottom:.3rem}
.modal-subtitle{font-size:.8rem;color:rgba(255,255,255,.55)}
.modal-body{padding:1.5rem 1.8rem}
.modal-ref{background:var(--gold-pale);border:1px solid var(--border);border-radius:10px;padding:.6rem 1.1rem;margin:.6rem 0 1rem;font-weight:700;color:var(--dark3);font-family:'Cormorant Garamond',serif;font-size:1.15rem;text-align:center;letter-spacing:.5px}
.modal-detail-row{display:flex;justify-content:space-between;font-size:.84rem;margin-bottom:.35rem;gap:.8rem}
.modal-detail-row .lbl{color:var(--muted);font-weight:500}
.modal-detail-row .val{font-weight:600;color:var(--text);text-align:right}
.modal-email-note{background:var(--success-bg);border:1px solid rgba(27,122,74,.2);border-radius:8px;padding:.55rem .8rem;font-size:.76rem;color:var(--success);margin-top:.9rem;display:flex;align-items:center;gap:.4rem;line-height:1.45}
.modal-actions{display:flex;gap:.6rem;margin-top:1rem}
.modal-btn{flex:1;background:var(--gold-pale);color:#7a5500;border:1px solid rgba(201,168,76,.4);border-radius:10px;padding:.72rem;font-family:'Cormorant Garamond',serif;font-size:.95rem;font-weight:700;cursor:pointer;transition:all .2s;text-align:center}
.modal-btn:hover{background:var(--gold);color:var(--dark)}
.modal-btn.primary{flex:2;background:var(--gold);color:var(--dark);border-color:var(--gold)}
.modal-btn.primary:hover{background:var(--gold-light)}

/* ── SCROLL TO TOP ── */
.scroll-top{position:fixed;bottom:1.4rem;right:1.4rem;width:42px;height:42px;border-radius:50%;background:var(--dark3);color:#fff;border:none;cursor:pointer;font-size:1.1rem;display:flex;align-items:center;justify-content:center;box-shadow:var(--shadow-lg);opacity:0;transform:translateY(12px);transition:opacity .3s,transform .3s;z-index:200;pointer-events:none}
.scroll-top.visible{opacity:1;transform:translateY(0);pointer-events:auto}
.scroll-top:hover{background:var(--gold);transform:translateY(-2px)}

/* ── TOAST ── */
.toast{position:fixed;bottom:1.4rem;left:50%;transform:translateX(-50%) translateY(80px);background:var(--dark);color:#fff;padding:.65rem 1.2rem;border-radius:11px;font-size:.82rem;z-index:9999;opacity:0;transition:all .35s;border-left:4px solid var(--gold);box-shadow:var(--shadow-lg);white-space:nowrap}
.toast.show{transform:translateX(-50%) translateY(0);opacity:1}
</style>
</head>
<body>

<!-- NAV -->
<nav>
  <a class="nav-logo" href="index.php">✛ ACNC</a>
  <div class="nav-right">
    <button class="nav-btn active" id="navDonate" onclick="showPage('donate',this)"><?= h($t['nav_donate']) ?></button>
    <button class="nav-btn" id="navHtg" onclick="showPage('howtogive',this)"><?= h($t['nav_howtogive']) ?></button>
    <div class="lang-switcher">
      <a href="?lang=en" class="lang-btn <?= $lang==='en'?'active':'' ?>">EN</a>
      <a href="?lang=zh" class="lang-btn <?= $lang==='zh'?'active':'' ?>">中文</a>
      <a href="?lang=ms" class="lang-btn <?= $lang==='ms'?'active':'' ?>">BM</a>
    </div>
    <div class="admin-dot" title="Staff login" onclick="location.href='login.php'"></div>
  </div>
  <button class="hamburger" id="hamburger" onclick="toggleMobileMenu()" aria-label="Menu">
    <span></span><span></span><span></span>
  </button>
</nav>
<div class="mobile-menu" id="mobileMenu">
  <button class="nav-btn" onclick="showPage('donate',document.getElementById('navDonate'))"><?= h($t['nav_donate']) ?></button>
  <button class="nav-btn" onclick="showPage('howtogive',document.getElementById('navHtg'))"><?= h($t['nav_howtogive']) ?></button>
  <div class="mobile-lang">
    <a href="?lang=en" class="lang-btn <?= $lang==='en'?'active':'' ?>">English</a>
    <a href="?lang=zh" class="lang-btn <?= $lang==='zh'?'active':'' ?>">中文</a>
    <a href="?lang=ms" class="lang-btn <?= $lang==='ms'?'active':'' ?>">Bahasa Malaysia</a>
  </div>
</div>

<!-- ══ DONATE PAGE ══ -->
<div id="page-donate" class="page active">
  <div class="hero">
    <div class="hero-badge"><?= h($t['hero_badge']) ?></div>
    <h1><?= h($t['hero_title']) ?></h1>
    <p><?= h($t['hero_sub']) ?></p>
    <div class="goal-bar-wrap">
      <div class="goal-header">
        <span><?= h($t['goal_label']) ?></span>
        <strong>RM <span id="goalCurrent">0</span> / RM <?= number_format(MONTHLY_GOAL,0) ?></strong>
      </div>
      <div class="goal-track"><div class="goal-fill" id="goalFill"></div></div>
      <div style="font-size:.68rem;color:rgba(255,255,255,.4);margin-top:.3rem;text-align:right"><span id="goalPct">0</span><?= h($t['goal_pct']) ?></div>
    </div>
  </div>
  <div class="container">
    <div id="errorBox" class="error-box"></div>

    <!-- Amount -->
    <div class="card">
      <div class="card-header"><div class="card-icon">💰</div><div><h3><?= h($t['amount_title']) ?></h3><div class="card-sub"><?= h($t['amount_sub']) ?></div></div></div>
      <div class="cur-section-label"><?= h($t['currency_label']) ?></div>
      <div class="currency-pills" id="currencyPills"></div>
      <div class="converted-pill" id="convertedAmt" style="display:none">🔄 <span id="convertedText"></span></div>
      <div class="amount-display">
        <span class="cur-sym" id="donSymbol">RM</span>
        <input type="number" id="amountInput" value="100" min="1" max="999999" oninput="onAmountInput()" aria-label="<?= h($t['amount_title']) ?>">
      </div>
      <div class="presets" id="presetsContainer"></div>
    </div>

    <!-- Options -->
    <div class="card">
      <div class="card-header"><div class="card-icon">✅</div><div><h3><?= h($t['options_title']) ?></h3></div></div>
      <div class="check-card" id="feeCard" onclick="toggleCheck('chkFee','feeCard')">
        <input type="checkbox" id="chkFee" style="display:none">
        <div class="check-icon">💳</div>
        <div><div class="check-title"><?= h($t['fee_title']) ?></div><div class="check-sub"><?= h($t['fee_sub']) ?> <span class="check-amt" id="feeAmt">MYR 2.80</span></div></div>
      </div>
      <div class="check-card" id="monthlyCard" onclick="toggleCheck('chkMonthly','monthlyCard')">
        <input type="checkbox" id="chkMonthly" style="display:none">
        <div class="check-icon">📅</div>
        <div><div class="check-title"><?= h($t['monthly_title']) ?></div><div class="check-sub"><?= h($t['monthly_sub']) ?></div></div>
      </div>
    </div>

    <!-- Missionary -->
    <div class="card">
      <div class="card-header"><div class="card-icon">👥</div><div><h3><?= h($t['miss_title']) ?> <span style="color:var(--danger)">*</span></h3></div></div>
      <div class="form-group" id="fg-donMissionary">
        <select id="donMissionary" onchange="validateField('donMissionary')" aria-required="true">
          <option value=""><?= h($t['miss_select']) ?></option>
          <?php foreach($missionaries as $m): ?>
          <option value="<?= h($m['name']) ?>"><?= h($m['name']) ?> · <?= h($m['field']) ?></option>
          <?php endforeach; ?>
        </select>
        <span class="val-icon" id="vi-donMissionary"></span>
        <div class="field-error"><?= h($t['miss_required']) ?></div>
      </div>
      <div class="form-group">
        <label><?= h($t['fund_label']) ?></label>
        <select id="donFund" aria-label="<?= h($t['fund_label']) ?>">
          <optgroup label="<?= h($t['fund_group']) ?>">
            <option value="General" selected><?= h($t['fund_general']) ?></option>
            <option value="Evangelism"><?= h($t['fund_evangelism']) ?></option>
            <option value="Church Plant"><?= h($t['fund_church']) ?></option>
            <option value="Humanitarian"><?= h($t['fund_humanitarian']) ?></option>
            <option value="Education"><?= h($t['fund_education']) ?></option>
            <option value="Building"><?= h($t['fund_building']) ?></option>
          </optgroup>
        </select>
      </div>
    </div>

    <!-- Personal Info -->
    <div class="card">
      <div class="card-header"><div class="card-icon">👤</div><div><h3><?= h($t['personal_title']) ?></h3><div class="card-sub"><?= h($t['personal_sub']) ?></div></div></div>
      <div class="privacy-note"><?= h($t['privacy_note']) ?></div>
      <div class="form-row">
        <div class="form-group" id="fg-donFirst">
          <label><?= h($t['fname_label']) ?> *</label>
          <input type="text" id="donFirst" placeholder="John" autocomplete="given-name" oninput="validateField('donFirst')" onblur="validateField('donFirst')" aria-required="true">
          <span class="val-icon" id="vi-donFirst"></span>
          <div class="field-error"><?= h($t['error_fname']) ?></div>
        </div>
        <div class="form-group" id="fg-donLast">
          <label><?= h($t['lname_label']) ?> *</label>
          <input type="text" id="donLast" placeholder="Smith" autocomplete="family-name" oninput="validateField('donLast')" onblur="validateField('donLast')" aria-required="true">
          <span class="val-icon" id="vi-donLast"></span>
          <div class="field-error"><?= h($t['error_lname']) ?></div>
        </div>
      </div>
      <div class="form-group" id="fg-donEmail">
        <label><?= h($t['email_label']) ?> *</label>
        <input type="email" id="donEmail" placeholder="john@example.com" autocomplete="email" oninput="validateField('donEmail')" onblur="validateField('donEmail')" aria-required="true">
        <span class="val-icon" id="vi-donEmail"></span>
        <div class="field-hint"><?= h($t['email_hint']) ?></div>
        <div class="field-error"><?= h($t['error_email']) ?></div>
      </div>
      <div class="form-row">
        <div class="form-group"><label><?= h($t['phone_label']) ?></label><input type="tel" id="donPhone" placeholder="+60 12-345 6789" autocomplete="tel"><div class="field-hint"><?= h($t['phone_hint']) ?></div></div>
        <div class="form-group">
          <label><?= h($t['country_label']) ?></label>
          <select id="donCountry" name="country" autocomplete="country-name">
            <option value=""><?= $lang==='zh'?'– 請選擇 –':($lang==='ms'?'– Sila Pilih –':'– Select country –') ?></option>
            <?php foreach($country_rows as $co): ?>
            <option value="<?= h($co['name']) ?>"><?= h($co['flag']) ?> <?= h($co['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>
      <div class="form-group" style="position:relative">
        <label><?= h($t['remarks_label']) ?></label>
        <span class="char-count" id="remarkCount">0/500</span>
        <textarea id="donRemarks" rows="2" maxlength="500" placeholder="<?= h($t['remarks_hint']) ?>" oninput="document.getElementById('remarkCount').textContent=this.value.length+'/500'" style="resize:vertical"></textarea>
      </div>
    </div>

    <!-- Summary -->
    <div class="donation-summary">
      <div class="summary-title"><?= h($t['summary_title']) ?></div>
      <div class="summary-row"><span class="lbl"><?= h($t['summary_amount']) ?></span><span id="sumAmount" class="val">RM 100.00</span></div>
      <div id="sumFeeRow" class="summary-row" style="display:none"><span class="lbl"><?= h($t['summary_fee']) ?></span><span id="sumFee" class="val">RM 2.80</span></div>
      <div class="summary-total"><span class="lbl"><?= h($t['summary_total']) ?></span><span id="sumTotal" class="val">RM 100.00</span></div>
    </div>

    <button class="submit-btn" id="submitBtn" onclick="submitDonation()">
      <div class="spinner"></div>
      <span class="btn-text"><?= h($t['submit_btn']) ?></span>
    </button>
    <p style="text-align:center;font-size:.72rem;color:var(--muted);margin-top:.9rem;line-height:1.6"><?= h($t['submit_security']) ?><br><?= h($t['submit_email']) ?></p>
  </div>
</div>

<!-- ══ HOW TO GIVE PAGE ══ -->
<div id="page-howtogive" class="page">
  <div class="htg-hero">
    <div style="display:inline-flex;align-items:center;gap:.8rem;margin-bottom:.8rem">
      <div style="font-size:2.8rem;color:var(--gold-light);line-height:1">✛</div>
      <div style="text-align:left">
        <div style="font-family:'Cormorant Garamond',serif;font-size:1.85rem;font-weight:700;color:var(--gold-light);line-height:1">ACNC</div>
        <div style="font-size:.6rem;color:rgba(255,255,255,.42);letter-spacing:.8px;text-transform:uppercase">All Christian Nations Connect</div>
      </div>
    </div>
    <h2 style="font-family:'Cormorant Garamond',serif;font-size:1.9rem;font-weight:700;color:#fff;margin-bottom:.35rem"><?= h($t['htg_title']) ?></h2>
    <p style="font-size:.86rem;color:rgba(255,255,255,.58);max-width:460px;margin:0 auto"><?= h($t['htg_sub']) ?></p>
  </div>
  <div class="container">
    <div class="section-divider" style="margin-top:.3rem">
      <div style="height:2px;width:28px;background:var(--gold);border-radius:2px;flex-shrink:0"></div>
      <span class="sd-text"><?= h($t['bank_transfer']) ?></span>
      <div class="sdline"></div>
    </div>
    <!-- HK -->
    <div class="country-block">
      <div class="country-tag">🇭🇰 Hong Kong</div>
      <div class="two-col-layout">
        <div>
          <h3>🏦 透過 BBCMHK</h3>
          <div class="bank-row"><span class="bank-lbl">存入銀行</span><span class="bank-val">香港上海匯豐銀行</span></div>
          <div class="bank-row"><span class="bank-lbl">戶口</span><span class="bank-val" style="font-weight:700;font-family:'Cormorant Garamond',serif;font-size:1rem">521–152165–838</span></div>
          <div class="bank-row"><span class="bank-lbl">帳戶</span><span class="bank-val">薪火匯事工（香港）有限公司<br><span style="font-size:.76rem;color:var(--muted)">Burning Bush Connect Ministries (HK) Limited</span></span></div>
          <div class="bank-note">奉獻後請將轉帳收據截圖電郵至 <strong>donations@bbcmhk.org</strong>，註明 <strong>UUPG</strong>。</div>
        </div>
        <div class="qr-stack">
          <div class="qr-item"><div class="qr-box"><div class="qr-placeholder">FPS QR</div></div><div class="qr-lbl">FPS</div></div>
          <div class="qr-item"><div class="qr-box"><div class="qr-placeholder">PayMe</div></div><div class="qr-lbl">PayMe</div></div>
          <div class="qr-item"><div class="qr-box"><div class="qr-placeholder">PayPal</div></div><div class="qr-lbl">PayPal</div></div>
        </div>
      </div>
    </div>
    <!-- AU -->
    <div class="country-block">
      <div class="country-tag">🇦🇺 Australia</div>
      <div class="two-col-layout">
        <div>
          <h3>🏦 透過 BBIM</h3>
          <div class="bank-row"><span class="bank-lbl">存入銀行</span><span class="bank-val">Commonwealth Bank of Australia</span></div>
          <div class="bank-row"><span class="bank-lbl">帳戶</span><span class="bank-val">Burning Bush IM</span></div>
          <div class="bank-row"><span class="bank-lbl">戶口</span><span class="bank-val" style="font-weight:700;font-family:'Cormorant Garamond',serif;font-size:1rem">10661782</span></div>
          <div class="bank-row"><span class="bank-lbl">BSB</span><span class="bank-val" style="font-weight:700">063–587</span></div>
          <div class="bank-row"><span class="bank-lbl">SWIFT</span><span class="bank-val" style="font-weight:700;letter-spacing:1px">CTBAAU2S</span></div>
          <div class="bank-note">電郵至 <strong>info@bbim.org.au</strong>，註明 <strong>UUPG</strong>。</div>
        </div>
        <div class="qr-stack"><div class="qr-item"><div class="qr-box"><div class="qr-placeholder">PayPal</div></div><div class="qr-lbl">PayPal</div></div></div>
      </div>
    </div>
    <!-- USA + MY -->
    <div class="two-col-half">
      <div class="country-block" style="margin-bottom:0">
        <div class="country-tag">🇺🇸 USA</div>
        <h3>🌐 透過 MFCI 網站</h3>
        <ol class="steps-list">
          <li>前往 <a href="https://mfci.cc/" target="_blank" rel="noopener" style="color:var(--dark3);font-weight:600">mfci.cc</a></li>
          <li>點選網站選單</li>
          <li>選擇「奉獻支持」→「美國與其他地區奉獻」</li>
          <li>於奉獻項目欄填寫：<strong>BBCM</strong></li>
        </ol>
      </div>
      <div class="country-block" style="margin-bottom:0">
        <div class="country-tag">🇲🇾 Malaysia</div>
        <h3>🏦 Maybank</h3>
        <div class="bank-row"><span class="bank-lbl">戶口</span><span class="bank-val" style="font-weight:700;font-family:'Cormorant Garamond',serif;font-size:1rem">112129163408</span></div>
        <div class="bank-row"><span class="bank-lbl">帳號</span><span class="bank-val">PUAH SEONG NGO</span></div>
        <div class="bank-row"><span class="bank-lbl">請註明</span><span class="bank-val">UUPG / Amanda.Lee</span></div>
        <div class="bank-note">電郵至 <strong style="word-break:break-all;font-size:.76rem">amanda.leeyityong@gmail.com</strong></div>
      </div>
    </div>
    <div style="margin-top:1.3rem;padding:.9rem 1.1rem;background:var(--gold-pale);border-radius:12px;border:1px solid var(--border);font-size:.8rem;color:#5a4a00;line-height:1.6">
      <?= h($t['need_help']) ?> <strong>donations@bbcmhk.org</strong> · <?= h($t['all_gifts']) ?>
    </div>
  </div>
</div>

<!-- SUCCESS MODAL -->
<div class="overlay" id="successModal">
  <div class="modal">
    <div class="modal-header">
      <div class="modal-icon-ring">❤️</div>
      <div class="modal-title" id="modalTitle"><?= h($t['modal_title']) ?></div>
      <div class="modal-subtitle"><?= h($t['modal_sub']) ?></div>
    </div>
    <div class="modal-body">
      <div class="modal-ref" id="modalRef">ACNC-00001</div>
      <div id="modalDetails"></div>
      <div class="modal-email-note" id="modalEmailNote">📧 <?= h($t['modal_email_sent']) ?></div>
      <div class="modal-actions">
        <button class="modal-btn" onclick="copyRef()" id="copyRefBtn"><?= h($t['modal_copy']) ?></button>
        <button class="modal-btn primary" onclick="closeModal()"><?= h($t['modal_done']) ?></button>
      </div>
    </div>
  </div>
</div>

<button class="scroll-top" id="scrollTopBtn" onclick="window.scrollTo({top:0,behavior:'smooth'})" title="↑"></button>
<div class="toast" id="toast"></div>

<script>
// ── Language strings passed to JS ────────────────────────────────
const LANG = {
  errorRequired : <?= json_encode($t['error_required']) ?>,
  errorAmount   : <?= json_encode($t['error_amount']) ?>,
  errorFname    : <?= json_encode($t['error_fname']) ?>,
  errorLname    : <?= json_encode($t['error_lname']) ?>,
  errorEmail    : <?= json_encode($t['error_email']) ?>,
  missingMiss   : <?= json_encode($t['miss_required']) ?>,
  modalDonor    : <?= json_encode($t['modal_donor']) ?>,
  modalAmount   : <?= json_encode($t['modal_amount']) ?>,
  modalMyr      : <?= json_encode($t['modal_myr']) ?>,
  modalMissionary:<?= json_encode($t['modal_missionary']) ?>,
  modalFund     : <?= json_encode($t['modal_fund']) ?>,
  modalType     : <?= json_encode($t['modal_type']) ?>,
  modalDate     : <?= json_encode($t['modal_date']) ?>,
  modalMonthly  : <?= json_encode($t['modal_monthly']) ?>,
  modalOnce     : <?= json_encode($t['modal_once']) ?>,
  emailSent     : <?= json_encode($t['modal_email_sent']) ?>,
  otherAmount   : <?= json_encode($t['other_amount']) ?>,
};

// Currencies loaded from database (admin-configurable)
const CURRENCIES = <?php
    $cur_js = [];
    foreach ($cur_rows as $c) {
        $cur_js[$c['code']] = ['sym' => $c['symbol'], 'flag' => $c['flag'], 'name' => $c['name']];
    }
    echo json_encode($cur_js, JSON_UNESCAPED_UNICODE);
?>;
const RATES = <?= json_encode($rates, JSON_NUMERIC_CHECK) ?>;
const PRESETS=[50,100,200,300,500];
let selectedCurrency='MYR', selectedAmount=100;

// Build currency pills
(function(){
  const c=document.getElementById('currencyPills');
  c.innerHTML=Object.entries(CURRENCIES).map(([code,info])=>
    `<button class="cur-pill${code==='MYR'?' selected':''}" data-code="${code}" onclick="selectCurrency('${code}',this)" title="${info.name||code}">${info.flag} ${code}</button>`
  ).join('');
})();

// Build preset buttons
(function(){
  const c=document.getElementById('presetsContainer');
  const btns=PRESETS.map((v,i)=>`<button class="preset-btn${i===1?' selected':''}" onclick="selectPreset(${v},this)"><span class="pa">${v}</span></button>`);
  btns.push(`<button class="preset-btn" onclick="selectCustom(this)"><span class="pa" style="font-size:.82rem">${LANG.otherAmount}</span></button>`);
  c.innerHTML=btns.join('');
})();

function selectCurrency(code,el){selectedCurrency=code;document.querySelectorAll('.cur-pill').forEach(p=>p.classList.remove('selected'));el.classList.add('selected');document.getElementById('donSymbol').textContent=CURRENCIES[code].sym;updateConverted();updateFee();}
function updateConverted(){const pill=document.getElementById('convertedAmt');if(selectedCurrency==='MYR'){pill.style.display='none';return;}document.getElementById('convertedText').textContent='≈ MYR '+((selectedAmount*(RATES[selectedCurrency]||1))).toFixed(2);pill.style.display='inline-flex';}
function updateFee(){const myr=selectedAmount*(RATES[selectedCurrency]||1);const feeAmt=(myr*0.025)+0.30;document.getElementById('feeAmt').textContent='MYR '+feeAmt.toFixed(2);updateSummary();}
function updateSummary(){
  const sym=CURRENCIES[selectedCurrency]?.sym||selectedCurrency;
  const myr=selectedAmount*(RATES[selectedCurrency]||1);
  const isMYR=selectedCurrency==='MYR';
  const feeChecked=document.getElementById('chkFee')?.checked;
  const fee=feeChecked?(myr*0.025)+0.30:0;
  const total=myr+fee;
  const amtStr=isMYR?`RM ${selectedAmount.toFixed(2)}`:`${sym}${selectedAmount.toFixed(2)} ${selectedCurrency} (RM ${myr.toFixed(2)})`;
  const el=id=>document.getElementById(id);
  if(el('sumAmount'))el('sumAmount').textContent=amtStr;
  if(el('sumFee'))el('sumFee').textContent='RM '+fee.toFixed(2);
  if(el('sumFeeRow'))el('sumFeeRow').style.display=feeChecked?'flex':'none';
  if(el('sumTotal'))el('sumTotal').textContent='RM '+total.toFixed(2);
}
function selectPreset(v,el){selectedAmount=v;document.getElementById('amountInput').value=v;document.querySelectorAll('.preset-btn').forEach(b=>b.classList.remove('selected'));el.classList.add('selected');updateFee();updateConverted();}
function selectCustom(el){document.querySelectorAll('.preset-btn').forEach(b=>b.classList.remove('selected'));el.classList.add('selected');const inp=document.getElementById('amountInput');inp.focus();inp.select();}
function onAmountInput(){selectedAmount=parseFloat(document.getElementById('amountInput').value)||0;document.querySelectorAll('.preset-btn').forEach(b=>b.classList.remove('selected'));updateFee();updateConverted();}
function toggleCheck(cb,card){const c=document.getElementById(cb);c.checked=!c.checked;document.getElementById(card).classList.toggle('checked',c.checked);updateSummary();}

// Validation
const validators={
  donFirst:     v=>v.trim().length>=1,
  donLast:      v=>v.trim().length>=1,
  donEmail:     v=>/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.trim()),
  donMissionary:v=>v.length>0,
};
const errorMsgs={donFirst:LANG.errorFname,donLast:LANG.errorLname,donEmail:LANG.errorEmail,donMissionary:LANG.missingMiss};
function validateField(id){
  const el=document.getElementById(id);const fg=document.getElementById('fg-'+id);const vi=document.getElementById('vi-'+id);
  if(!el||!validators[id])return true;
  const ok=validators[id](el.value);
  const hasInput=el.value.length>0;
  el.classList.toggle('valid',ok);el.classList.toggle('invalid',!ok&&hasInput);
  if(fg){fg.classList.toggle('has-error',!ok&&hasInput);const fe=fg.querySelector('.field-error');if(fe)fe.textContent=errorMsgs[id]||'';}
  if(vi)vi.textContent=ok?'✅':hasInput?'⚠️':'';
  return ok;
}
function validateAll(){return['donFirst','donLast','donEmail','donMissionary'].map(id=>validateField(id)).every(Boolean);}

// Submit
async function submitDonation(){
  const errBox=document.getElementById('errorBox');errBox.style.display='none';
  if(!validateAll()){errBox.textContent=LANG.errorRequired;errBox.style.display='block';errBox.scrollIntoView({behavior:'smooth',block:'nearest'});return;}
  const amount=parseFloat(document.getElementById('amountInput').value);
  if(!amount||amount<=0){errBox.textContent=LANG.errorAmount;errBox.style.display='block';return;}
  const btn=document.getElementById('submitBtn');btn.disabled=true;btn.classList.add('loading');
  const fd=new FormData();
  fd.append('csrf_token','<?= h($csrf) ?>');
  fd.append('first_name',document.getElementById('donFirst').value.trim());
  fd.append('last_name', document.getElementById('donLast').value.trim());
  fd.append('email',     document.getElementById('donEmail').value.trim());
  fd.append('phone',     document.getElementById('donPhone').value.trim());
  fd.append('country',   document.getElementById('donCountry').value.trim());
  fd.append('amount',    amount);fd.append('currency',selectedCurrency);
  fd.append('missionary',document.getElementById('donMissionary').value);
  fd.append('fund',      document.getElementById('donFund').value);
  fd.append('remarks',   document.getElementById('donRemarks').value.trim());
  fd.append('lang',      '<?= h($lang) ?>');
  if(document.getElementById('chkFee').checked)     fd.append('cover_fee','1');
  if(document.getElementById('chkMonthly').checked) fd.append('monthly','1');
  try{
    const res=await fetch('submit.php',{method:'POST',body:fd});
    const data=await res.json();
    if(data.success){
      document.getElementById('modalRef').textContent=data.ref;
      document.getElementById('modalDetails').innerHTML=`
        <div style="border:1px solid var(--light);border-radius:10px;padding:.8rem 1rem;margin-bottom:.5rem">
          <div class="modal-detail-row"><span class="lbl">${LANG.modalDonor}</span><span class="val">${data.name}</span></div>
          <div class="modal-detail-row"><span class="lbl">${LANG.modalAmount}</span><span class="val">${data.sym}${data.amount} ${data.currency}</span></div>
          <div class="modal-detail-row"><span class="lbl">${LANG.modalMyr}</span><span class="val" style="color:var(--success);font-weight:700">RM ${data.total_myr}</span></div>
          <div class="modal-detail-row"><span class="lbl">${LANG.modalMissionary}</span><span class="val">${data.missionary}</span></div>
          <div class="modal-detail-row"><span class="lbl">${LANG.modalFund}</span><span class="val">${data.fund}</span></div>
          <div class="modal-detail-row"><span class="lbl">${LANG.modalType}</span><span class="val">${data.monthly?LANG.modalMonthly:LANG.modalOnce}</span></div>
          <div class="modal-detail-row"><span class="lbl">${LANG.modalDate}</span><span class="val">${data.date}</span></div>
        </div>`;
      document.getElementById('modalEmailNote').innerHTML=`📧 ${LANG.emailSent} <strong>${data.email}</strong>`;
      document.getElementById('successModal').classList.add('open');
      const gf=document.getElementById('goalFill');const gp=document.getElementById('goalPct');
      if(gf){const cur=parseFloat(gf.style.width)||<?= $goal_pct ?>;const next=Math.min(100,cur+3);gf.style.width=next+'%';if(gp)gp.textContent=Math.round(next);}
    }else{errBox.textContent=data.error||LANG.errorRequired;errBox.style.display='block';errBox.scrollIntoView({behavior:'smooth',block:'nearest'});}
  }catch(e){errBox.textContent='Network error. Please try again.';errBox.style.display='block';}
  btn.disabled=false;btn.classList.remove('loading');
}

function copyRef(){
  const ref=document.getElementById('modalRef')?.textContent||'';
  navigator.clipboard?.writeText(ref).then(()=>{const btn=document.getElementById('copyRefBtn');if(btn){const o=btn.textContent;btn.textContent='✓';setTimeout(()=>btn.textContent=o,2000);}});
}
function closeModal(){
  document.getElementById('successModal').classList.remove('open');
  ['donFirst','donLast','donEmail','donPhone','donCountry','donRemarks'].forEach(id=>{const el=document.getElementById(id);if(el){el.value='';el.classList.remove('valid','invalid');}const vi=document.getElementById('vi-'+id);if(vi)vi.textContent='';const fg=document.getElementById('fg-'+id);if(fg)fg.classList.remove('has-error');});
  document.getElementById('amountInput').value=100;selectedAmount=100;
  document.getElementById('chkFee').checked=false;document.getElementById('feeCard').classList.remove('checked');
  document.getElementById('chkMonthly').checked=false;document.getElementById('monthlyCard').classList.remove('checked');
  document.querySelectorAll('.preset-btn').forEach((b,i)=>b.classList.toggle('selected',i===1));
  selectedCurrency='MYR';document.querySelectorAll('.cur-pill').forEach((p,i)=>p.classList.toggle('selected',i===0));
  document.getElementById('donSymbol').textContent='RM';document.getElementById('convertedAmt').style.display='none';
  document.getElementById('errorBox').style.display='none';document.getElementById('remarkCount').textContent='0/500';updateFee();
}
document.getElementById('successModal').addEventListener('click',function(e){if(e.target===this)closeModal();});

function showPage(id,btn){
  document.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));
  document.querySelectorAll('.nav-right .nav-btn, .mobile-menu .nav-btn').forEach(b=>b.classList.remove('active'));
  document.getElementById('page-'+id).classList.add('active');
  if(btn)btn.classList.add('active');
  document.getElementById('hamburger')?.classList.remove('open');
  document.getElementById('mobileMenu')?.classList.remove('open');
  window.scrollTo({top:0,behavior:'smooth'});
}
function toggleMobileMenu(){document.getElementById('hamburger').classList.toggle('open');document.getElementById('mobileMenu').classList.toggle('open');}

function showToast(msg){const t=document.getElementById('toast');t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),3000);}

// Update country select placeholder when language changes
function updateCountryPlaceholder(){
  const sel = document.getElementById('donCountry');
  if(!sel) return;
  const first = sel.options[0];
  if(!first || first.value !== '') return;
  first.textContent = currentLang==='zh' ? '– 請選擇 –' : currentLang==='ms' ? '– Sila Pilih –' : '– Select country –';
}

// Goal bar animate on load
(function(){
  const t=<?= $goal_pct ?>,a='<?= number_format($this_month_total,0) ?>';
  setTimeout(()=>{
    const f=document.getElementById('goalFill');const p=document.getElementById('goalPct');const c=document.getElementById('goalCurrent');
    if(f)f.style.width=t+'%';if(p)p.textContent=t;if(c)c.textContent=a;
  },350);
})();

// Scroll-to-top
window.addEventListener('scroll',()=>{const b=document.getElementById('scrollTopBtn');if(b)b.classList.toggle('visible',window.scrollY>400);},{passive:true});

// Enter key submits
document.addEventListener('keydown',e=>{if(e.key==='Enter'&&document.getElementById('page-donate')?.classList.contains('active')&&!['TEXTAREA','SELECT'].includes(document.activeElement?.tagName))submitDonation();});

updateConverted();updateFee();updateSummary();updateCountryPlaceholder();
</script>
</body>
</html>
