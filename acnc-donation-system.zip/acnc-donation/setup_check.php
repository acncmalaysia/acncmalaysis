<?php
// ══════════════════════════════════════════════
//  ACNC Setup Checker — delete this after setup
// ══════════════════════════════════════════════
$checks = [];

// PHP version
$phpOK = version_compare(PHP_VERSION, '7.4.0', '>=');
$checks[] = [$phpOK, 'PHP '.PHP_VERSION, $phpOK ? 'OK (7.4+ required)' : 'FAIL — needs PHP 7.4 or higher'];

// PDO MySQL
$pdoOK = extension_loaded('pdo_mysql');
$checks[] = [$pdoOK, 'PDO MySQL extension', $pdoOK ? 'OK' : 'FAIL — contact your host to enable pdo_mysql'];

// JSON
$jsonOK = function_exists('json_encode');
$checks[] = [$jsonOK, 'JSON support', $jsonOK ? 'OK' : 'FAIL'];

// Sessions
session_start();
$_SESSION['test'] = 'ok';
$sessOK = ($_SESSION['test'] === 'ok');
$checks[] = [$sessOK, 'PHP Sessions', $sessOK ? 'OK' : 'FAIL — sessions not working'];

// config.php readable
$cfgOK = file_exists(__DIR__.'/config.php');
$checks[] = [$cfgOK, 'config.php found', $cfgOK ? 'OK' : 'FAIL — upload config.php'];

// DB connection
$dbOK = false; $dbMsg = 'Not tested';
if ($cfgOK) {
    require_once __DIR__.'/config.php';
    try {
        $pdo = getDB();
        $pdo->query('SELECT 1');
        $dbOK = true; $dbMsg = 'Connected successfully!';
    } catch (Exception $e) {
        $dbMsg = 'FAIL — ' . $e->getMessage();
    }
}
$checks[] = [$dbOK, 'MySQL Database connection', $dbMsg];

// HTTPS
$httpsOK = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || ($_SERVER['SERVER_PORT'] ?? 80) == 443;
$checks[] = [$httpsOK, 'HTTPS / SSL', $httpsOK ? 'Active ✓' : 'Not detected — enable SSL in your hosting panel (usually free with Let\'s Encrypt)'];

$allOK = count(array_filter($checks, fn($c) => !$c[0])) === 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>ACNC Setup Check</title>
<style>
body{font-family:system-ui,sans-serif;max-width:640px;margin:2rem auto;padding:1rem;background:#f5f5f5}
h1{font-size:1.5rem;margin-bottom:1.2rem;color:#1A1A2E}
.row{display:flex;align-items:flex-start;gap:.8rem;background:#fff;border-radius:10px;padding:.9rem 1rem;margin-bottom:.6rem;border:1px solid #e8e8e8}
.ico{font-size:1.3rem;flex-shrink:0;margin-top:.05rem}
.label{font-weight:600;font-size:.9rem;color:#333;margin-bottom:.2rem}
.msg{font-size:.8rem;color:#666}
.ok .row{border-left:4px solid #1B7A4A}
.fail .row{border-left:4px solid #C1121F}
.summary{border-radius:12px;padding:1rem 1.2rem;margin-top:1.2rem;font-size:.9rem;line-height:1.6}
.summary-ok{background:#D6F0E3;color:#1B7A4A;border:1px solid rgba(27,122,74,.2)}
.summary-fail{background:#FFE4E6;color:#C1121F;border:1px solid rgba(193,18,31,.2)}
.delete-warning{background:#FFF3CD;border:1px solid #FFD700;border-radius:8px;padding:.8rem 1rem;font-size:.82rem;color:#856404;margin-top:1rem}
</style>
</head>
<body>
<h1>✛ ACNC Setup Checker</h1>
<?php foreach($checks as [$ok, $label, $msg]): ?>
<div class="<?= $ok?'ok':'fail' ?>">
  <div class="row">
    <div class="ico"><?= $ok ? '✅' : '❌' ?></div>
    <div><div class="label"><?= h($label) ?></div><div class="msg"><?= h($msg) ?></div></div>
  </div>
</div>
<?php endforeach; ?>

<div class="summary <?= $allOK?'summary-ok':'summary-fail' ?>">
  <?= $allOK
    ? '🎉 All checks passed! Your system is ready. You can now delete <strong>setup_check.php</strong> and <strong>setup.sql</strong> from your server.'
    : '⚠️ Some checks failed. Fix the issues above, then refresh this page.' ?>
</div>

<div class="delete-warning">
  ⚠️ <strong>Security reminder:</strong> Delete <code>setup_check.php</code> and <code>setup.sql</code> from your server after your site is working. These files reveal system information.
</div>
</body>
</html>
<?php function h($s){return htmlspecialchars((string)$s,ENT_QUOTES,'UTF-8');} ?>
