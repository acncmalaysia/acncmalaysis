<?php
session_start();
require_once '../config.php';
send_security_headers();
require_editor();
$db = getDB();

$flash = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify($_POST['csrf_token'] ?? '')) die('Security error.');
    $action = $_POST['action'] ?? '';

    if ($action === 'add_missionary' && has_role(ROLE_ADMIN)) {
        $name = trim($_POST['m_name'] ?? ''); $field = trim($_POST['m_field'] ?? '');
        if ($name && $field) {
            $db->prepare("INSERT INTO missionaries (name,field,org,email,notes) VALUES (?,?,?,?,?)")
               ->execute([$name,$field,trim($_POST['m_org']??''),trim($_POST['m_email']??''),trim($_POST['m_notes']??'')]);
            audit('MISSIONARY_ADDED', "Added: $name");
            $flash = 'success:Missionary partner added!';
        } else { $flash = 'error:Name and Field are required.'; }
    }
    elseif ($action === 'toggle_missionary' && has_role(ROLE_ADMIN)) {
        $db->prepare("UPDATE missionaries SET active=1-active WHERE id=?")->execute([(int)$_POST['m_id']]);
        $flash = 'success:Partner status updated.';
    }
    elseif ($action === 'delete_missionary' && has_role(ROLE_ADMIN)) {
        $db->prepare("DELETE FROM missionaries WHERE id=?")->execute([(int)$_POST['m_id']]);
        audit('MISSIONARY_DELETED', "Deleted missionary ID ".(int)$_POST['m_id']);
        $flash = 'success:Partner removed.';
    }
    elseif ($action === 'save_rates') {
        $codes = ['MYR','USD','SGD','AUD','GBP','EUR','HKD','TWD','JPY','KRW','IDR','PHP','THB','INR'];
        $stmt  = $db->prepare("INSERT INTO exchange_rates (currency,rate_to_myr) VALUES (?,?) ON DUPLICATE KEY UPDATE rate_to_myr=VALUES(rate_to_myr)");
        foreach ($codes as $c) { $r=(float)($_POST['rate'][$c]??0); if($r>0)$stmt->execute([$c,$r]); }
        audit('RATES_SAVED', 'Exchange rates updated');
        $flash = 'success:Exchange rates saved!';
    }
    elseif ($action === 'delete_donation' && has_role(ROLE_ADMIN)) {
        $ref = trim($_POST['ref'] ?? '');
        if ($ref) { $db->prepare("DELETE FROM donations WHERE ref=?")->execute([$ref]); audit('DONATION_DELETED',"Deleted: $ref"); }
        $flash = 'success:Record deleted.';
    }
}

// Filters & pagination
$tab       = $_GET['tab']       ?? 'donations';
$q         = trim($_GET['q']        ?? '');
$fund_f    = trim($_GET['fund']     ?? '');
$cur_f     = trim($_GET['cur']      ?? '');
$date_from = trim($_GET['date_from']?? '');
$date_to   = trim($_GET['date_to']  ?? '');
$miss_f    = trim($_GET['miss']     ?? '');
$type_f    = trim($_GET['type']     ?? '');
$page      = max(1,(int)($_GET['page']??1));
$per       = 20;

$where = ['1=1']; $params = [];
if ($q)         { $where[]='(d.first_name LIKE ? OR d.last_name LIKE ? OR d.email LIKE ? OR d.missionary LIKE ? OR d.ref LIKE ?)'; $s="%$q%"; $params=array_merge($params,[$s,$s,$s,$s,$s]); }
if ($fund_f)    { $where[]='d.fund=?';       $params[]=$fund_f; }
if ($cur_f)     { $where[]='d.currency=?';   $params[]=$cur_f; }
if ($miss_f)    { $where[]='d.missionary=?'; $params[]=$miss_f; }
if ($type_f==='monthly') { $where[]='d.monthly=1'; }
if ($type_f==='once')    { $where[]='d.monthly=0'; }
if ($date_from) { $where[]='DATE(d.created_at)>=?'; $params[]=$date_from; }
if ($date_to)   { $where[]='DATE(d.created_at)<=?'; $params[]=$date_to; }
$wsql = implode(' AND ',$where);

$s=$db->prepare("SELECT COUNT(*) FROM donations d WHERE $wsql"); $s->execute($params); $total=(int)$s->fetchColumn();
$pages=max(1,ceil($total/$per)); $offset=($page-1)*$per;
$ds=$db->prepare("SELECT d.* FROM donations d WHERE $wsql ORDER BY d.created_at DESC LIMIT $per OFFSET $offset");
$ds->execute($params); $donations=$ds->fetchAll();
$currencies  = $db->query("SELECT DISTINCT currency FROM donations ORDER BY currency")->fetchAll(PDO::FETCH_COLUMN);
$missionaries_list = $db->query("SELECT DISTINCT missionary FROM donations WHERE missionary IS NOT NULL AND missionary!='' ORDER BY missionary")->fetchAll(PDO::FETCH_COLUMN);

// Stats (with month-over-month delta)
$stats   = $db->query("SELECT COUNT(*) total,COALESCE(SUM(total_myr),0) sum_myr,COUNT(DISTINCT email) donors,SUM(monthly) monthly_count FROM donations")->fetch();
$prev_mo = $db->query("SELECT COUNT(*) cnt,COALESCE(SUM(total_myr),0) amt FROM donations WHERE created_at BETWEEN DATE_FORMAT(DATE_SUB(NOW(),INTERVAL 1 MONTH),'%Y-%m-01') AND DATE_FORMAT(NOW(),'%Y-%m-01') - INTERVAL 1 DAY")->fetch();
$this_mo = $db->query("SELECT COUNT(*) cnt,COALESCE(SUM(total_myr),0) amt FROM donations WHERE created_at >= DATE_FORMAT(NOW(),'%Y-%m-01')")->fetch();

// Analytics
$monthly_data   = $db->query("SELECT DATE_FORMAT(created_at,'%Y-%m') mon, COUNT(*) cnt, COALESCE(SUM(total_myr),0) amt FROM donations WHERE created_at >= DATE_SUB(NOW(),INTERVAL 12 MONTH) GROUP BY mon ORDER BY mon ASC")->fetchAll();
$top_miss       = $db->query("SELECT missionary, COUNT(*) cnt, COALESCE(SUM(total_myr),0) amt FROM donations WHERE missionary IS NOT NULL AND missionary!='' GROUP BY missionary ORDER BY amt DESC LIMIT 6")->fetchAll();
$cur_breakdown  = $db->query("SELECT currency, COUNT(*) cnt, COALESCE(SUM(total_myr),0) amt FROM donations GROUP BY currency ORDER BY amt DESC")->fetchAll();
$fund_breakdown = $db->query("SELECT fund, COUNT(*) cnt, COALESCE(SUM(total_myr),0) amt FROM donations GROUP BY fund ORDER BY amt DESC")->fetchAll();
$recent_5       = $db->query("SELECT * FROM donations ORDER BY created_at DESC LIMIT 5")->fetchAll();

// Missionaries, rates, currencies, countries
$missionaries = $db->query("SELECT * FROM missionaries ORDER BY active DESC,name ASC")->fetchAll();

// Handle currency_settings save
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action']??'')==='save_currencies' && has_role(ROLE_ADMIN)) {
    if (!csrf_verify($_POST['csrf_token']??'')) die('Security error.');
    // Toggle active flags
    $db->exec("UPDATE currency_settings SET active=0");
    if (!empty($_POST['cur_active']) && is_array($_POST['cur_active'])) {
        $st = $db->prepare("UPDATE currency_settings SET active=1 WHERE code=?");
        foreach ($_POST['cur_active'] as $code) { $st->execute([preg_replace('/[^A-Z]/','',$code)]); }
    }
    // Save sort order
    if (!empty($_POST['cur_order']) && is_array($_POST['cur_order'])) {
        $st2 = $db->prepare("UPDATE currency_settings SET sort_order=? WHERE code=?");
        foreach ($_POST['cur_order'] as $code => $ord) {
            $st2->execute([(int)$ord, preg_replace('/[^A-Z]/','',$code)]);
        }
    }
    // Add new currency
    if (!empty($_POST['new_cur_code']) && !empty($_POST['new_cur_name'])) {
        $nc = strtoupper(preg_replace('/[^A-Z]/','',trim($_POST['new_cur_code'])));
        if (strlen($nc)>=2 && strlen($nc)<=10) {
            $db->prepare("INSERT IGNORE INTO currency_settings (code,name,flag,symbol,active,sort_order) VALUES (?,?,?,?,1,99)")
               ->execute([$nc, trim($_POST['new_cur_name']), trim($_POST['new_cur_flag']??''), trim($_POST['new_cur_sym']??'')]);
            // Also add to exchange_rates
            $db->prepare("INSERT IGNORE INTO exchange_rates (currency,rate_to_myr) VALUES (?,1.000000)")->execute([$nc]);
        }
    }
    // Delete currency
    if (!empty($_POST['del_cur'])) {
        $dc = strtoupper(preg_replace('/[^A-Z]/','',trim($_POST['del_cur'])));
        if ($dc !== 'MYR') { // never delete base currency
            $db->prepare("DELETE FROM currency_settings WHERE code=?")->execute([$dc]);
        }
    }
    audit('CURRENCIES_SAVED','Currency settings updated');
    $flash = 'success:Currency settings saved!';
}

// Handle donation_countries save
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action']??'')==='save_countries' && has_role(ROLE_ADMIN)) {
    if (!csrf_verify($_POST['csrf_token']??'')) die('Security error.');
    // Toggle active
    $db->exec("UPDATE donation_countries SET active=0");
    if (!empty($_POST['cty_active']) && is_array($_POST['cty_active'])) {
        $st = $db->prepare("UPDATE donation_countries SET active=1 WHERE id=?");
        foreach ($_POST['cty_active'] as $id) { $st->execute([(int)$id]); }
    }
    // Sort order
    if (!empty($_POST['cty_order']) && is_array($_POST['cty_order'])) {
        $st2 = $db->prepare("UPDATE donation_countries SET sort_order=? WHERE id=?");
        foreach ($_POST['cty_order'] as $id => $ord) { $st2->execute([(int)$ord,(int)$id]); }
    }
    // Add new country
    if (!empty($_POST['new_cty_name'])) {
        $nm = mb_substr(trim($_POST['new_cty_name']),0,100);
        $db->prepare("INSERT IGNORE INTO donation_countries (name,code,flag,active,sort_order) VALUES (?,?,?,1,99)")
           ->execute([$nm, strtoupper(substr(trim($_POST['new_cty_code']??''),0,5)), trim($_POST['new_cty_flag']??'🌐')]);
    }
    // Delete country
    if (!empty($_POST['del_cty'])) {
        $db->prepare("DELETE FROM donation_countries WHERE id=?")->execute([(int)$_POST['del_cty']]);
    }
    audit('COUNTRIES_SAVED','Donation countries updated');
    $flash = 'success:Country list saved!';
}

$currencies_all  = $db->query("SELECT * FROM currency_settings ORDER BY sort_order ASC, code ASC")->fetchAll();
$countries_all   = $db->query("SELECT * FROM donation_countries ORDER BY sort_order ASC, name ASC")->fetchAll();
$rdb=[]; foreach($db->query("SELECT currency,rate_to_myr,updated_at FROM exchange_rates") as $r){ $rdb[$r['currency']]=$r; }
$cur_info=['MYR'=>['🇲🇾','Malaysian Ringgit'],'USD'=>['🇺🇸','US Dollar'],'SGD'=>['🇸🇬','Singapore Dollar'],'AUD'=>['🇦🇺','Australian Dollar'],'GBP'=>['🇬🇧','British Pound'],'EUR'=>['🇪🇺','Euro'],'HKD'=>['🇭🇰','Hong Kong Dollar'],'TWD'=>['🇹🇼','Taiwan Dollar'],'JPY'=>['🇯🇵','Japanese Yen'],'KRW'=>['🇰🇷','Korean Won'],'IDR'=>['🇮🇩','Indonesian Rupiah'],'PHP'=>['🇵🇭','Philippine Peso'],'THB'=>['🇹🇭','Thai Baht'],'INR'=>['🇮🇳','Indian Rupee']];

[$flash_type,$flash_msg] = $flash ? explode(':',$flash,2) : ['',''];

// Receipt lookup
$view_receipt = null;
if(!empty($_GET['receipt'])) {
    $rs = $db->prepare("SELECT * FROM donations WHERE ref=? LIMIT 1");
    $rs->execute([trim($_GET['receipt'])]);
    $view_receipt = $rs->fetch();
}

$CURRSYM = ['MYR'=>'RM','USD'=>'$','SGD'=>'S$','AUD'=>'A$','GBP'=>'£','EUR'=>'€','HKD'=>'HK$','TWD'=>'NT$','JPY'=>'¥','KRW'=>'₩','IDR'=>'Rp','PHP'=>'₱','THB'=>'฿','INR'=>'₹'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard — ACNC Admin</title>
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@400;600;700&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.0/chart.umd.min.js"></script>
<style>
:root{
  --gold:#C9A84C;--gold-light:#E8C97A;--gold-pale:#F5EDD3;--gold-pale2:#FDF6E3;
  --dark:#1A1A2E;--dark3:#0F3460;--cream:#FAF8F3;--white:#fff;
  --text:#1E1E2E;--muted:#7A7A8C;--light:#F0EEE8;
  --success:#1B7A4A;--success-bg:#D6F0E3;--danger:#C1121F;--danger-bg:#FFE4E6;
  --border:rgba(201,168,76,.22);--shadow:0 2px 16px rgba(0,0,0,.07);--shadow-md:0 4px 24px rgba(0,0,0,.10)
}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'DM Sans',sans-serif;background:var(--cream);color:var(--text);min-height:100vh}

/* ── NAV ── */
nav{background:var(--dark);display:flex;align-items:center;justify-content:space-between;padding:0 1.4rem;height:58px;border-bottom:2px solid var(--gold);position:sticky;top:0;z-index:100}
.nav-brand{font-family:'Cormorant Garamond',serif;color:var(--gold);font-size:1.15rem;font-weight:700;display:flex;align-items:center;gap:.7rem}
.role-tag{font-size:.62rem;font-weight:600;background:rgba(255,255,255,.08);color:rgba(255,255,255,.4);border:1px solid rgba(255,255,255,.1);border-radius:5px;padding:.1rem .5rem;font-family:'DM Sans',sans-serif;letter-spacing:.2px}
.nav-right{display:flex;align-items:center;gap:.25rem;flex-shrink:0}
.nav-right a{color:rgba(255,255,255,.45);font-size:.74rem;text-decoration:none;padding:.28rem .65rem;border-radius:6px;transition:all .2s;white-space:nowrap}
.nav-right a:hover{background:rgba(255,255,255,.07);color:var(--gold-light)}
.nav-right .ulink{color:rgba(255,200,100,.65);border:1px solid rgba(255,200,100,.2);border-radius:6px}
.nav-right .lo{color:rgba(255,90,90,.65)}.nav-right .lo:hover{background:var(--danger);color:#fff}

/* ── TABS ── */
.tab-bar{background:var(--white);border-bottom:1px solid var(--light);display:flex;padding:0 1.2rem;position:sticky;top:58px;z-index:99;overflow-x:auto;gap:.05rem}
.tab-btn{border:none;background:none;padding:.7rem .92rem;font-family:'DM Sans',sans-serif;font-size:.8rem;font-weight:600;color:var(--muted);cursor:pointer;border-bottom:3px solid transparent;white-space:nowrap;transition:all .2s;display:flex;align-items:center;gap:.3rem}
.tab-btn:hover{color:var(--dark)}
.tab-btn.active{color:var(--dark3);border-bottom-color:var(--gold)}
.tab-panel{display:none}.tab-panel.active{display:block}

/* ── LAYOUT ── */
.container{max-width:1180px;margin:0 auto;padding:1.4rem 1.1rem 4rem}
.ph{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:.6rem;margin-bottom:1.1rem;padding-top:.3rem}
.ph-title{font-family:'Cormorant Garamond',serif;font-size:1.4rem;font-weight:700;color:var(--dark);display:flex;align-items:center;gap:.5rem}

/* ── FLASH ── */
.flash{border-radius:10px;padding:.65rem 1rem;font-size:.83rem;margin-bottom:1.1rem;display:flex;align-items:center;gap:.5rem;animation:slideIn .3s ease}
@keyframes slideIn{from{opacity:0;transform:translateY(-8px)}to{opacity:1;transform:translateY(0)}}
.flash-success{background:var(--success-bg);border:1px solid rgba(27,122,74,.2);color:var(--success)}
.flash-error{background:var(--danger-bg);border:1px solid rgba(193,18,31,.2);color:var(--danger)}

/* ── STATS ── */
.stats-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:1rem;margin-bottom:1.3rem}
@media(max-width:700px){.stats-grid{grid-template-columns:repeat(2,1fr)}}
.stat{background:var(--white);border-radius:14px;padding:1.1rem 1.2rem;box-shadow:var(--shadow);display:flex;align-items:center;gap:.85rem;border:1px solid rgba(0,0,0,.04);position:relative;overflow:hidden;transition:box-shadow .2s}
.stat:hover{box-shadow:var(--shadow-md)}
.stat::after{content:'';position:absolute;top:0;left:0;right:0;height:3px;border-radius:14px 14px 0 0}
.stat:nth-child(1)::after{background:linear-gradient(90deg,var(--gold),var(--gold-light))}
.stat:nth-child(2)::after{background:linear-gradient(90deg,var(--success),#52b788)}
.stat:nth-child(3)::after{background:linear-gradient(90deg,var(--dark3),#1d4e89)}
.stat:nth-child(4)::after{background:linear-gradient(90deg,#e65c00,#f4a261)}
.stat-ico{width:44px;height:44px;border-radius:12px;background:var(--gold-pale);display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:1.2rem}
.stat-body{flex:1;min-width:0}
.stat-val{font-family:'Cormorant Garamond',serif;font-size:1.6rem;font-weight:700;color:var(--dark3);line-height:1.1}
.stat-lbl{font-size:.67rem;font-weight:600;color:var(--muted);text-transform:uppercase;letter-spacing:.3px;margin-top:.12rem}
.stat-delta{font-size:.68rem;font-weight:600;margin-top:.12rem;display:flex;align-items:center;gap:.2rem}
.delta-up{color:var(--success)}.delta-dn{color:var(--danger)}.delta-neu{color:var(--muted)}

/* ── CARDS ── */
.card{background:var(--white);border-radius:14px;padding:1.3rem 1.4rem;box-shadow:var(--shadow);margin-bottom:1.1rem;border:1px solid rgba(0,0,0,.04)}
.card-title{font-family:'Cormorant Garamond',serif;font-size:1.12rem;font-weight:700;color:var(--dark);margin-bottom:.95rem;padding-bottom:.6rem;border-bottom:1px solid var(--light);display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:.5rem}

/* ── DASHBOARD GRID ── */
.dash-grid{display:grid;grid-template-columns:1.8fr 1fr;gap:1.1rem;margin-bottom:1.1rem}
@media(max-width:860px){.dash-grid{grid-template-columns:1fr}}

/* ── CHART.JS cards ── */
.chart-card{background:var(--white);border-radius:14px;padding:1.2rem 1.3rem;box-shadow:var(--shadow);border:1px solid rgba(0,0,0,.04)}
.chart-card-title{font-family:'Cormorant Garamond',serif;font-size:1.05rem;font-weight:700;color:var(--dark);margin-bottom:.85rem;display:flex;align-items:center;justify-content:space-between}
.chart-card-title small{font-size:.68rem;font-weight:400;color:var(--muted);font-family:'DM Sans',sans-serif}
.chart-wrap{position:relative;height:180px}

/* ── MINI ANALYTICS ── */
.mini-grid{display:grid;grid-template-columns:1fr 1fr 1fr;gap:1rem;margin-bottom:1.1rem}
@media(max-width:760px){.mini-grid{grid-template-columns:1fr}}
.h-bar-row{display:flex;align-items:center;gap:.55rem;margin-bottom:.5rem}
.h-bar-lbl{font-size:.76rem;font-weight:500;color:var(--text);flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.h-bar-track{width:90px;height:6px;background:var(--light);border-radius:4px;overflow:hidden;flex-shrink:0}
.h-bar-fill{height:100%;background:linear-gradient(90deg,var(--gold),var(--gold-light));border-radius:4px}
.h-bar-val{font-size:.7rem;font-weight:600;color:var(--muted);width:60px;text-align:right;flex-shrink:0}
.cur-row{display:flex;align-items:center;gap:.5rem;margin-bottom:.42rem}
.cur-dot{width:8px;height:8px;border-radius:50%;flex-shrink:0}
.cur-name{font-size:.77rem;font-weight:600;color:var(--text);flex:1}
.cur-cnt{font-size:.7rem;color:var(--muted)}
.cur-amt{font-size:.74rem;font-weight:600;color:var(--dark3)}

/* ── TABLE ── */
.tbl-wrap{overflow-x:auto}
table{width:100%;border-collapse:collapse;font-size:.8rem}
thead tr{background:var(--dark);color:rgba(255,255,255,.85)}
thead th{padding:.65rem .85rem;text-align:left;font-weight:600;font-size:.71rem;letter-spacing:.3px;white-space:nowrap}
tbody tr{border-bottom:1px solid #f2f2f2;transition:background .12s}
tbody tr:hover{background:var(--gold-pale2)}
tbody td{padding:.6rem .85rem;vertical-align:middle}
.tr-monthly{background:rgba(27,122,74,.03)}

/* ── TOOLBAR ── */
.toolbar{display:flex;gap:.5rem;flex-wrap:wrap;margin-bottom:.9rem;align-items:center}
.toolbar input,.toolbar select{border:1.5px solid #e8e8e8;border-radius:8px;padding:.4rem .7rem;font-size:.79rem;outline:none;background:#fff;font-family:'DM Sans',sans-serif;transition:border .2s;color:var(--text)}
.toolbar input:focus,.toolbar select:focus{border-color:var(--gold)}
.toolbar .tsearch{flex:1;min-width:180px}
.toolbar input[type=date]{min-width:128px}
.filter-count{font-size:.73rem;color:var(--muted);padding:.3rem .5rem;background:var(--gold-pale);border-radius:6px;white-space:nowrap;font-weight:600}

/* ── BADGES ── */
.badge{display:inline-flex;align-items:center;border-radius:20px;padding:.13rem .58rem;font-size:.67rem;font-weight:700;text-transform:uppercase;letter-spacing:.3px;white-space:nowrap}
.badge-blue{background:#DBE9FF;color:var(--dark3)}
.badge-gold{background:var(--gold-pale);color:#8B6914;border:1px solid rgba(201,168,76,.3)}
.badge-green{background:var(--success-bg);color:var(--success)}
.badge-red{background:var(--danger-bg);color:var(--danger)}

/* ── BUTTONS ── */
.btn{display:inline-flex;align-items:center;gap:.32rem;border-radius:8px;padding:.42rem .9rem;font-size:.77rem;font-weight:600;cursor:pointer;border:1px solid transparent;transition:all .18s;font-family:'DM Sans',sans-serif;text-decoration:none;white-space:nowrap}
.btn-gold{background:var(--gold-pale);border-color:rgba(201,168,76,.4);color:#7a5500}.btn-gold:hover{background:var(--gold);color:#fff;border-color:var(--gold)}
.btn-green{background:var(--success-bg);border-color:rgba(27,122,74,.2);color:var(--success)}.btn-green:hover{background:var(--success);color:#fff}
.btn-danger{background:var(--danger-bg);border-color:rgba(193,18,31,.15);color:var(--danger)}.btn-danger:hover{background:var(--danger);color:#fff}
.btn-dark{background:var(--dark3);color:#fff;border-color:var(--dark3)}.btn-dark:hover{background:var(--gold);color:var(--dark);border-color:var(--gold)}
.btn-muted{background:var(--light);color:var(--muted);border-color:#e0e0e0}.btn-muted:hover{background:#e0e0e0;color:var(--text)}
.btn-sm{padding:.2rem .52rem;font-size:.7rem}
.btn-receipt{background:#DBE9FF;border:1px solid rgba(15,52,96,.2);color:var(--dark3)}.btn-receipt:hover{background:var(--dark3);color:#fff}

/* ── PAGINATION ── */
.pager{display:flex;gap:.3rem;align-items:center;justify-content:center;margin-top:.9rem;flex-wrap:wrap}
.pager a,.pager span{padding:.3rem .7rem;border-radius:7px;font-size:.78rem;text-decoration:none;border:1.5px solid #e4e4e4;color:var(--text);transition:all .15s}
.pager a:hover{border-color:var(--gold);background:var(--gold-pale)}
.pager .cur{background:var(--gold);border-color:var(--gold);color:var(--dark);font-weight:700}
.pager-info{font-size:.73rem;color:var(--muted);text-align:center;margin-top:.4rem}

/* ── FORMS ── */
.fg{margin-bottom:.78rem}
.fg label{display:block;font-size:.69rem;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:.4px;margin-bottom:.27rem}
.fg input,.fg select,.fg textarea{width:100%;border:1.5px solid #e4e4e4;border-radius:8px;padding:.58rem .8rem;font-family:'DM Sans',sans-serif;font-size:.87rem;outline:none;transition:border .2s;background:#fff}
.fg input:focus,.fg select:focus,.fg textarea:focus{border-color:var(--gold);box-shadow:0 0 0 3px rgba(201,168,76,.1)}
.fg2{display:grid;grid-template-columns:1fr 1fr;gap:.75rem}
.fg3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:.75rem}
@media(max-width:520px){.fg2,.fg3{grid-template-columns:1fr}}

/* ── RATES ── */
.rate-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(198px,1fr));gap:.75rem}
.rate-card{background:var(--cream);border:1px solid var(--border);border-radius:10px;padding:.85rem .95rem;display:flex;align-items:center;gap:.7rem;transition:border .2s}
.rate-card:hover{border-color:var(--gold)}
.rate-flag{font-size:1.55rem;flex-shrink:0}
.rate-code{font-weight:700;font-size:.85rem;color:var(--dark)}.rate-name{font-size:.67rem;color:var(--muted)}.rate-upd{font-size:.61rem;color:var(--muted);margin-top:.1rem}
.rate-right{display:flex;flex-direction:column;align-items:flex-end;gap:.14rem;margin-left:auto}
.rate-right input{width:84px;border:1.5px solid #e4e4e4;border-radius:7px;padding:.28rem .44rem;font-size:.81rem;text-align:right;outline:none;font-family:'DM Sans',sans-serif;transition:border .2s}
.rate-right input:focus{border-color:var(--gold)}
.rate-right span{font-size:.61rem;color:var(--muted)}

/* ── RECEIPT MODAL ── */
.overlay{display:none;position:fixed;inset:0;background:rgba(10,10,30,.65);z-index:999;align-items:center;justify-content:center;padding:1rem;backdrop-filter:blur(4px)}
.overlay.open{display:flex}
.receipt-modal{background:var(--white);border-radius:20px;width:100%;max-width:560px;max-height:90vh;overflow-y:auto;box-shadow:0 24px 64px rgba(0,0,0,.3)}
.receipt-header{background:linear-gradient(140deg,var(--dark),var(--dark3));padding:1.8rem 1.8rem 1.4rem;border-radius:20px 20px 0 0;position:relative}
.receipt-header::after{content:'✝';position:absolute;right:1.5rem;top:.5rem;font-size:5rem;opacity:.06;color:var(--gold-light);font-family:serif;pointer-events:none;line-height:1}
.receipt-org{font-family:'Cormorant Garamond',serif;font-size:1.55rem;font-weight:700;color:var(--gold-light);margin-bottom:.15rem}
.receipt-org-sub{font-size:.68rem;color:rgba(255,255,255,.45);text-transform:uppercase;letter-spacing:.8px}
.receipt-ref{display:inline-flex;align-items:center;gap:.4rem;background:rgba(201,168,76,.15);border:1px solid rgba(201,168,76,.3);border-radius:7px;padding:.28rem .8rem;font-size:.78rem;font-weight:700;color:var(--gold-light);margin-top:.75rem;font-family:'Cormorant Garamond',serif;font-size:.95rem;letter-spacing:.5px}
.receipt-body{padding:1.6rem 1.8rem}
.receipt-amount-block{background:linear-gradient(135deg,var(--gold-pale),var(--gold-pale2));border:1.5px solid var(--border);border-radius:12px;padding:1.1rem 1.3rem;text-align:center;margin-bottom:1.3rem}
.receipt-amount-label{font-size:.72rem;font-weight:700;color:#8B6914;text-transform:uppercase;letter-spacing:.5px;margin-bottom:.25rem}
.receipt-amount-main{font-family:'Cormorant Garamond',serif;font-size:2.2rem;font-weight:700;color:var(--dark);line-height:1.1}
.receipt-amount-myr{font-size:.82rem;color:#8B6914;font-weight:600;margin-top:.15rem}
.receipt-section{margin-bottom:1.1rem}
.receipt-section-title{font-size:.68rem;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:.5px;margin-bottom:.55rem;padding-bottom:.35rem;border-bottom:1px solid var(--light)}
.receipt-row{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:.38rem;font-size:.84rem;gap:1rem}
.receipt-row .lbl{color:var(--muted);font-weight:500;flex-shrink:0}
.receipt-row .val{font-weight:600;color:var(--text);text-align:right}
.receipt-badge{display:inline-flex;align-items:center;gap:.3rem;background:var(--success-bg);border:1px solid rgba(27,122,74,.2);border-radius:8px;padding:.28rem .75rem;font-size:.76rem;font-weight:600;color:var(--success);margin-top:.6rem}
.receipt-footer-note{background:var(--gold-pale2);border-left:3px solid var(--gold);border-radius:0 8px 8px 0;padding:.65rem .9rem;font-size:.76rem;color:#7a5500;line-height:1.55;margin-top:1.1rem}
.receipt-actions{display:flex;gap:.6rem;padding:1rem 1.8rem 1.5rem;border-top:1px solid var(--light);flex-wrap:wrap}

/* ── RECENT DONATIONS MINI TABLE ── */
.recent-item{display:flex;align-items:center;gap:.75rem;padding:.6rem 0;border-bottom:1px solid var(--light)}
.recent-item:last-child{border-bottom:none}
.recent-avatar{width:32px;height:32px;border-radius:50%;background:var(--dark3);color:#fff;display:flex;align-items:center;justify-content:center;font-size:.8rem;font-weight:700;flex-shrink:0}
.recent-name{font-weight:600;font-size:.82rem;color:var(--text);line-height:1.2}
.recent-meta{font-size:.7rem;color:var(--muted)}
.recent-amt{font-family:'Cormorant Garamond',serif;font-size:1rem;font-weight:700;color:var(--success);white-space:nowrap}

/* ── MISSIONARIES ── */
.miss-card{border:1.5px solid var(--light);border-radius:12px;padding:.9rem 1rem;display:flex;align-items:center;gap:.85rem;background:var(--white);margin-bottom:.6rem;transition:border .2s}
.miss-card:hover{border-color:var(--border)}
.miss-avatar{width:38px;height:38px;border-radius:50%;background:var(--dark3);color:#fff;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:.95rem;flex-shrink:0}
.miss-name{font-weight:700;font-size:.88rem;color:var(--dark)}
.miss-meta{font-size:.74rem;color:var(--muted);margin-top:.08rem}

/* ── BACKUP ── */
.backup-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:1rem}
.backup-card{background:var(--white);border-radius:14px;padding:1.4rem;box-shadow:var(--shadow);border:1px solid rgba(0,0,0,.04)}

/* ── PRINT RECEIPT ── */
@media print {
  /* Hide everything except the receipt */
  * { visibility: hidden !important; }
  .receipt-modal, .receipt-modal * { visibility: visible !important; }

  /* Reset page */
  html, body {
    margin: 0 !important;
    padding: 0 !important;
    background: #fff !important;
    font-family: 'DM Sans', Arial, sans-serif !important;
    font-size: 11pt !important;
    color: #1E1E2E !important;
    -webkit-print-color-adjust: exact;
    print-color-adjust: exact;
  }

  /* Receipt fills the whole page */
  .receipt-modal {
    position: fixed !important;
    inset: 0 !important;
    width: 100% !important;
    max-width: 100% !important;
    max-height: none !important;
    overflow: visible !important;
    box-shadow: none !important;
    border-radius: 0 !important;
    background: #fff !important;
    padding: 0 !important;
  }

  /* Header: keep dark background for print */
  .receipt-header {
    background: #1A1A2E !important;
    color: #fff !important;
    padding: 1.5cm 2cm 1.2cm !important;
    border-radius: 0 !important;
    page-break-inside: avoid;
  }
  .receipt-org { color: #E8C97A !important; font-size: 22pt !important; }
  .receipt-org-sub { color: rgba(255,255,255,0.65) !important; font-size: 8pt !important; }
  .receipt-ref-pill {
    background: rgba(201,168,76,0.2) !important;
    border: 1px solid rgba(201,168,76,0.4) !important;
    color: #E8C97A !important;
    font-size: 11pt !important;
    padding: 4px 12px !important;
    border-radius: 5px !important;
    display: inline-block !important;
    margin-top: 10px !important;
  }

  /* Body */
  .receipt-body {
    padding: 1cm 2cm !important;
  }

  /* Amount block */
  .receipt-amount-block {
    background: #FDF6E3 !important;
    border: 1.5px solid rgba(201,168,76,0.35) !important;
    border-radius: 8px !important;
    padding: 14px 18px !important;
    text-align: center !important;
    margin-bottom: 18px !important;
    page-break-inside: avoid;
  }
  .receipt-amount-label { font-size: 7pt !important; color: #8B6914 !important; letter-spacing: 1px !important; margin-bottom: 4px !important; }
  .receipt-amount-main { font-size: 26pt !important; font-weight: 700 !important; color: #1A1A2E !important; }
  .receipt-amount-myr { font-size: 9pt !important; color: #8B6914 !important; margin-top: 4px !important; }

  /* Sections */
  .receipt-section { margin-bottom: 14px !important; page-break-inside: avoid; }
  .receipt-section-title {
    font-size: 7pt !important;
    font-weight: 700 !important;
    color: #7A7A8C !important;
    text-transform: uppercase !important;
    letter-spacing: 1px !important;
    border-bottom: 1px solid #F0EEE8 !important;
    padding-bottom: 4px !important;
    margin-bottom: 8px !important;
  }
  .receipt-row {
    display: flex !important;
    justify-content: space-between !important;
    font-size: 10pt !important;
    margin-bottom: 5px !important;
    gap: 1cm !important;
  }
  .receipt-row .lbl { color: #7A7A8C !important; font-weight: 500 !important; }
  .receipt-row .val { font-weight: 600 !important; color: #1E1E2E !important; text-align: right !important; }

  /* Confirmed badge */
  .receipt-confirmed {
    display: inline-flex !important;
    align-items: center !important;
    background: #D6F0E3 !important;
    border: 1px solid rgba(27,122,74,0.3) !important;
    border-radius: 6px !important;
    padding: 4px 12px !important;
    font-size: 9pt !important;
    color: #1B7A4A !important;
    font-weight: 600 !important;
    margin-top: 8px !important;
  }

  /* Footer note */
  .receipt-footer-note {
    background: #FDF6E3 !important;
    border-left: 3px solid #C9A84C !important;
    border-radius: 0 6px 6px 0 !important;
    padding: 8px 12px !important;
    font-size: 8.5pt !important;
    color: #5a4a00 !important;
    line-height: 1.55 !important;
    margin-top: 14px !important;
  }

  /* Page footer watermark */
  .receipt-body::after {
    content: 'This receipt was generated by ACNC Mission Donation System · Printed ' attr(data-date);
    display: block !important;
    text-align: center !important;
    font-size: 7pt !important;
    color: #bbb !important;
    margin-top: 1.5cm !important;
    border-top: 1px solid #eee !important;
    padding-top: 8px !important;
  }

  /* Hide actions, overlay backdrop, nav */
  .receipt-actions,
  .receipt-overlay::before,
  nav, .tab-bar, .container, .cwide,
  .toast { display: none !important; }

  /* Page settings */
  @page {
    size: A4;
    margin: 0;
  }
}
</style>
</head>
<body>

<!-- NAV -->
<nav>
  <div class="nav-brand">
    ✛ ACNC Admin
    <span class="role-tag"><?= h(current_role()) ?> · <?= h(current_user()) ?></span>
  </div>
  <div class="nav-right">
    <?php if(has_role(ROLE_SUPER)): ?><a href="users.php" class="ulink">👥 Users</a><?php endif; ?>
    <a href="../index.php" target="_blank">🌐 Live Site</a>
    <a href="change_password.php" title="Change password">🔑</a>
    <a href="logout.php" class="lo">⇥ Logout</a>
  </div>
</nav>

<!-- TABS -->
<div class="tab-bar">
  <button class="tab-btn <?= $tab==='overview'?'active':'' ?>" onclick="switchTab('overview')">🏠 Overview</button>
  <button class="tab-btn <?= $tab==='donations'?'active':'' ?>" onclick="switchTab('donations')">📊 Donations</button>
  <button class="tab-btn <?= $tab==='analytics'?'active':'' ?>" onclick="switchTab('analytics')">📈 Analytics</button>
  <?php if(has_role(ROLE_ADMIN)): ?>
  <button class="tab-btn <?= $tab==='missionaries'?'active':'' ?>" onclick="switchTab('missionaries')">👥 Partners</button>
  <?php endif; ?>
  <button class="tab-btn <?= $tab==='rates'?'active':'' ?>" onclick="switchTab('rates')">💱 Rates</button>
  <?php if(has_role(ROLE_ADMIN)): ?>
  <button class="tab-btn <?= $tab==='currencies'?'active':'' ?>" onclick="switchTab('currencies')">🌐 Currencies &amp; Countries</button>
  <?php endif; ?>
  <button class="tab-btn <?= $tab==='backup'?'active':'' ?>" onclick="switchTab('backup')">💾 Backup</button>
</div>

<div class="container">

<?php if($flash_msg): ?>
<div class="flash flash-<?= $flash_type ?>"><?= $flash_type==='success'?'✓':'⚠️' ?> <?= h($flash_msg) ?></div>
<?php endif; ?>

<!-- ═══════════════ OVERVIEW ═══════════════ -->
<div id="tab-overview" class="tab-panel <?= ($tab==='overview'||$tab==='')?'active':'' ?>">

  <!-- Stats row -->
  <div class="stats-grid">
    <?php
    $mo_delta_cnt = $this_mo['cnt'] - $prev_mo['cnt'];
    $mo_delta_amt = $this_mo['amt'] - $prev_mo['amt'];
    ?>
    <div class="stat">
      <div class="stat-ico">❤️</div>
      <div class="stat-body">
        <div class="stat-val"><?= number_format($stats['total']) ?></div>
        <div class="stat-lbl">Total Donations</div>
        <div class="stat-delta <?= $this_mo['cnt']>0?'delta-up':'delta-neu' ?>">
          <?= $this_mo['cnt']>0?'↑':'·' ?> <?= number_format($this_mo['cnt']) ?> this month
        </div>
      </div>
    </div>
    <div class="stat">
      <div class="stat-ico">💰</div>
      <div class="stat-body">
        <div class="stat-val">RM <?= number_format($stats['sum_myr'],0) ?></div>
        <div class="stat-lbl">Total Raised (MYR)</div>
        <div class="stat-delta <?= $mo_delta_amt>=0?'delta-up':'delta-dn' ?>">
          <?= $mo_delta_amt>=0?'↑':'↓' ?> RM <?= number_format(abs($this_mo['amt']),0) ?> this month
        </div>
      </div>
    </div>
    <div class="stat">
      <div class="stat-ico">👥</div>
      <div class="stat-body">
        <div class="stat-val"><?= number_format($stats['donors']) ?></div>
        <div class="stat-lbl">Unique Donors</div>
        <div class="stat-delta delta-neu">All time</div>
      </div>
    </div>
    <div class="stat">
      <div class="stat-ico">📅</div>
      <div class="stat-body">
        <div class="stat-val"><?= number_format($stats['monthly_count']) ?></div>
        <div class="stat-lbl">Monthly Pledges</div>
        <div class="stat-delta delta-up">Recurring donors</div>
      </div>
    </div>
  </div>

  <!-- Chart + Recent -->
  <div class="dash-grid">
    <!-- Monthly chart -->
    <div class="chart-card">
      <div class="chart-card-title">Monthly Donations (MYR) <small>Last 12 months</small></div>
      <div class="chart-wrap"><canvas id="chartMonthly"></canvas></div>
    </div>
    <!-- Recent donations -->
    <div class="card" style="margin-bottom:0">
      <div class="card-title" style="font-size:.98rem">Recent Donations
        <a href="?tab=donations" class="btn btn-gold btn-sm">View all</a>
      </div>
      <?php foreach($recent_5 as $r):
        $init = strtoupper(substr($r['first_name'],0,1));
        $sym  = $CURRSYM[$r['currency']] ?? $r['currency'].' ';
      ?>
      <div class="recent-item">
        <div class="recent-avatar"><?= h($init) ?></div>
        <div style="flex:1;min-width:0">
          <div class="recent-name"><?= h($r['first_name'].' '.$r['last_name']) ?></div>
          <div class="recent-meta"><?= h($r['missionary']??'—') ?> · <?= date('d M',strtotime($r['created_at'])) ?></div>
        </div>
        <div>
          <div class="recent-amt"><?= h($sym) ?><?= number_format($r['amount'],0) ?></div>
          <div style="font-size:.68rem;color:var(--muted);text-align:right">RM <?= number_format($r['total_myr'],0) ?></div>
        </div>
      </div>
      <?php endforeach; if(empty($recent_5)): ?>
      <div style="color:var(--muted);font-size:.84rem;padding:.5rem 0">No donations yet.</div>
      <?php endif; ?>
    </div>
  </div>

  <!-- Mini analytics -->
  <div class="mini-grid">
    <!-- Top missionaries -->
    <div class="chart-card">
      <div class="chart-card-title">Top Missionaries <small>By amount</small></div>
      <?php $maxM=max(array_column($top_miss,'amt')+[1]); foreach($top_miss as $m): $pct=max(4,round($m['amt']/$maxM*100)); ?>
      <div class="h-bar-row">
        <div class="h-bar-lbl" title="<?= h($m['missionary']) ?>"><?= h($m['missionary']) ?></div>
        <div class="h-bar-track"><div class="h-bar-fill" style="width:<?= $pct ?>%"></div></div>
        <div class="h-bar-val">RM<?= number_format($m['amt'],0) ?></div>
      </div>
      <?php endforeach; if(empty($top_miss)): ?><div style="color:var(--muted);font-size:.82rem">No data</div><?php endif; ?>
    </div>
    <!-- Currency breakdown -->
    <div class="chart-card">
      <div class="chart-card-title">Currencies <small>By amount (MYR)</small></div>
      <?php $curColors=['#C9A84C','#0F3460','#1B7A4A','#C1121F','#e65c00','#7A7A8C','#9c27b0','#00838f'];
      foreach($cur_breakdown as $i=>$c): ?>
      <div class="cur-row">
        <div class="cur-dot" style="background:<?= $curColors[$i%count($curColors)] ?>"></div>
        <div class="cur-name"><?= h($c['currency']) ?></div>
        <div class="cur-cnt"><?= $c['cnt'] ?> gifts</div>
        <div class="cur-amt">RM<?= number_format($c['amt'],0) ?></div>
      </div>
      <?php endforeach; if(empty($cur_breakdown)): ?><div style="color:var(--muted);font-size:.82rem">No data</div><?php endif; ?>
    </div>
    <!-- Fund breakdown -->
    <div class="chart-card">
      <div class="chart-card-title">Funds <small>Breakdown</small></div>
      <div class="chart-wrap" style="height:140px"><canvas id="chartFunds"></canvas></div>
    </div>
  </div>

</div><!-- /overview -->


<!-- ═══════════════ DONATIONS ═══════════════ -->
<div id="tab-donations" class="tab-panel <?= $tab==='donations'?'active':'' ?>">
  <div class="ph">
    <div class="ph-title">📊 Donation Records</div>
    <?php if(has_role(ROLE_ADMIN)): ?>
    <div style="display:flex;gap:.5rem;flex-wrap:wrap">
      <a href="export.php?type=csv&<?= http_build_query(array_filter(['q'=>$q,'fund'=>$fund_f,'cur'=>$cur_f,'miss'=>$miss_f,'type'=>$type_f,'date_from'=>$date_from,'date_to'=>$date_to])) ?>" class="btn btn-gold">⬇ Export CSV</a>
      <a href="export.php?type=json" class="btn btn-green">⬇ JSON Backup</a>
    </div>
    <?php endif; ?>
  </div>

  <div class="card">
    <form method="GET" class="toolbar">
      <input type="hidden" name="tab" value="donations">
      <input type="text" name="q" value="<?= h($q) ?>" placeholder="🔍 Search name, email, ref, missionary…" class="tsearch">
      <select name="fund">
        <option value="">All Funds</option>
        <?php foreach(['General','Evangelism','Church Plant','Humanitarian','Education','Building'] as $f): ?>
        <option<?= $fund_f===$f?' selected':'' ?>><?= h($f) ?></option>
        <?php endforeach; ?>
      </select>
      <select name="cur">
        <option value="">All Currencies</option>
        <?php foreach($currencies as $c): ?><option<?= $cur_f===$c?' selected':'' ?>><?= h($c) ?></option><?php endforeach; ?>
      </select>
      <select name="miss">
        <option value="">All Missionaries</option>
        <?php foreach($missionaries_list as $m): ?><option<?= $miss_f===$m?' selected':'' ?>><?= h($m) ?></option><?php endforeach; ?>
      </select>
      <select name="type">
        <option value="">All Types</option>
        <option value="monthly"<?= $type_f==='monthly'?' selected':'' ?>>Monthly</option>
        <option value="once"<?= $type_f==='once'?' selected':'' ?>>One-time</option>
      </select>
      <input type="date" name="date_from" value="<?= h($date_from) ?>" title="From date">
      <input type="date" name="date_to"   value="<?= h($date_to) ?>"   title="To date">
      <button type="submit" class="btn btn-dark">Filter</button>
      <a href="?tab=donations" class="btn btn-muted">Reset</a>
      <?php if($total !== (int)$db->query("SELECT COUNT(*) FROM donations")->fetchColumn()): ?>
      <span class="filter-count"><?= number_format($total) ?> results</span>
      <?php endif; ?>
    </form>

    <div class="tbl-wrap">
    <table>
      <thead><tr>
        <th>Ref #</th><th>Date &amp; Time</th><th>Donor</th><th>Contact</th>
        <th>Amount</th><th>MYR Total</th><th>Missionary</th><th>Fund</th><th>Type</th><th>Receipt</th>
        <?php if(has_role(ROLE_ADMIN)): ?><th>Del</th><?php endif; ?>
      </tr></thead>
      <tbody>
      <?php if(empty($donations)): ?>
      <tr><td colspan="11" style="text-align:center;padding:2.5rem;color:var(--muted)">No donations found. Try adjusting your filters.</td></tr>
      <?php else: foreach($donations as $d):
        $sym = $CURRSYM[$d['currency']] ?? $d['currency'].' ';
      ?>
      <tr class="<?= $d['monthly']?'tr-monthly':'' ?>">
        <td><span class="badge badge-blue"><?= h($d['ref']) ?></span></td>
        <td style="white-space:nowrap;font-size:.74rem">
          <?= date('d M Y', strtotime($d['created_at'])) ?><br>
          <span style="color:var(--muted)"><?= date('H:i', strtotime($d['created_at'])) ?></span>
        </td>
        <td>
          <div style="font-weight:600;font-size:.84rem"><?= h($d['first_name'].' '.$d['last_name']) ?></div>
          <?php if($d['country']): ?><div style="font-size:.7rem;color:var(--muted)"><?= h($d['country']) ?></div><?php endif; ?>
        </td>
        <td style="font-size:.75rem;color:var(--muted)">
          <?= h($d['email']) ?><?php if($d['phone']): ?><br><?= h($d['phone']) ?><?php endif; ?>
        </td>
        <td>
          <div style="font-weight:700;font-size:.88rem"><?= h($sym) ?><?= number_format($d['amount'],2) ?></div>
          <div style="font-size:.7rem;color:var(--muted)"><?= h($d['currency']) ?></div>
        </td>
        <td style="color:var(--success);font-weight:700">RM <?= number_format($d['total_myr'],2) ?>
          <?php if($d['cover_fee']): ?><div style="font-size:.68rem;color:var(--muted)">+fee RM<?= number_format($d['fee_amount'],2) ?></div><?php endif; ?>
        </td>
        <td style="font-size:.78rem;max-width:130px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?= h($d['missionary']??'—') ?></td>
        <td><span class="badge badge-gold"><?= h($d['fund']) ?></span></td>
        <td><?= $d['monthly']?'<span class="badge badge-green">Monthly</span>':'<span style="color:var(--muted);font-size:.73rem">Once</span>' ?></td>
        <td><button class="btn btn-receipt btn-sm" onclick="openReceipt('<?= h($d['ref']) ?>')">🧾 View</button></td>
        <?php if(has_role(ROLE_ADMIN)): ?>
        <td>
          <form method="POST" onsubmit="return confirm('Delete <?= h($d['ref']) ?>?')" style="display:inline">
            <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
            <input type="hidden" name="action" value="delete_donation">
            <input type="hidden" name="ref" value="<?= h($d['ref']) ?>">
            <input type="hidden" name="tab" value="donations">
            <button type="submit" class="btn btn-danger btn-sm">✕</button>
          </form>
        </td>
        <?php endif; ?>
      </tr>
      <?php endforeach; endif; ?>
      </tbody>
    </table>
    </div>

    <?php if($pages>1): ?>
    <div class="pager">
      <?php $base='?tab=donations&'.http_build_query(array_filter(['q'=>$q,'fund'=>$fund_f,'cur'=>$cur_f,'miss'=>$miss_f,'type'=>$type_f,'date_from'=>$date_from,'date_to'=>$date_to]));
      if($page>1) echo '<a href="'.h($base.'&page='.($page-1)).'">‹ Prev</a>';
      for($p=max(1,$page-2);$p<=min($pages,$page+2);$p++):
        if($p===$page) echo '<span class="cur">'.$p.'</span>';
        else echo '<a href="'.h($base.'&page='.$p).'">'.$p.'</a>';
      endfor;
      if($page<$pages) echo '<a href="'.h($base.'&page='.($page+1)).'">Next ›</a>'; ?>
    </div>
    <div class="pager-info">Page <?= $page ?> of <?= $pages ?> · <?= number_format($total) ?> records total</div>
    <?php else: ?>
    <div class="pager-info"><?= number_format($total) ?> records</div>
    <?php endif; ?>
  </div>
</div>


<!-- ═══════════════ ANALYTICS ═══════════════ -->
<div id="tab-analytics" class="tab-panel <?= $tab==='analytics'?'active':'' ?>">
  <div class="ph"><div class="ph-title">📈 Analytics</div></div>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;margin-bottom:1.1rem">
    <div class="chart-card">
      <div class="chart-card-title">Monthly Donations — Amount (MYR) <small>12 months</small></div>
      <div class="chart-wrap" style="height:200px"><canvas id="chartMonthlyAmt"></canvas></div>
    </div>
    <div class="chart-card">
      <div class="chart-card-title">Monthly Donations — Count <small>12 months</small></div>
      <div class="chart-wrap" style="height:200px"><canvas id="chartMonthlyCnt"></canvas></div>
    </div>
  </div>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;margin-bottom:1.1rem">
    <div class="chart-card">
      <div class="chart-card-title">Top Missionaries <small>By MYR raised</small></div>
      <div class="chart-wrap" style="height:220px"><canvas id="chartMiss"></canvas></div>
    </div>
    <div class="chart-card">
      <div class="chart-card-title">Fund Breakdown <small>By MYR amount</small></div>
      <div class="chart-wrap" style="height:220px"><canvas id="chartFunds2"></canvas></div>
    </div>
  </div>
  <div class="card">
    <div class="card-title">Monthly Summary</div>
    <div class="tbl-wrap"><table>
      <thead><tr><th>Month</th><th>Donations</th><th>MYR Total</th><th>Monthly Recurring</th><th>Avg per Donation</th><th>Unique Donors</th></tr></thead>
      <tbody>
      <?php
      $monthly_detail = $db->query("SELECT DATE_FORMAT(created_at,'%Y-%m') mon, COUNT(*) cnt, COALESCE(SUM(total_myr),0) amt, SUM(monthly) mon_cnt, COUNT(DISTINCT email) uniq FROM donations WHERE created_at >= DATE_SUB(NOW(),INTERVAL 12 MONTH) GROUP BY mon ORDER BY mon DESC")->fetchAll();
      foreach($monthly_detail as $m): ?>
      <tr>
        <td style="font-weight:600"><?= h($m['mon']) ?></td>
        <td><?= (int)$m['cnt'] ?></td>
        <td style="color:var(--success);font-weight:600">RM <?= number_format($m['amt'],2) ?></td>
        <td><?= (int)$m['mon_cnt'] ?> <span style="color:var(--muted);font-size:.75rem">pledges</span></td>
        <td style="color:var(--muted)">RM <?= $m['cnt']>0?number_format($m['amt']/$m['cnt'],2):'0.00' ?></td>
        <td><?= (int)$m['uniq'] ?></td>
      </tr>
      <?php endforeach; if(empty($monthly_detail)): ?>
      <tr><td colspan="6" style="text-align:center;padding:1.5rem;color:var(--muted)">No data yet</td></tr>
      <?php endif; ?>
      </tbody>
    </table></div>
  </div>
</div>


<!-- ═══════════════ MISSIONARIES ═══════════════ -->
<?php if(has_role(ROLE_ADMIN)): ?>
<div id="tab-missionaries" class="tab-panel <?= $tab==='missionaries'?'active':'' ?>">
  <div class="ph"><div class="ph-title">👥 Missionary Partners</div></div>
  <div class="card">
    <div class="card-title">Add New Partner</div>
    <form method="POST">
      <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
      <input type="hidden" name="action" value="add_missionary">
      <input type="hidden" name="tab" value="missionaries">
      <div class="fg2"><div class="fg"><label>Name *</label><input type="text" name="m_name" placeholder="Rev. John Doe" required></div><div class="fg"><label>Field / Region *</label><input type="text" name="m_field" placeholder="Southeast Asia" required></div></div>
      <div class="fg2"><div class="fg"><label>Email</label><input type="email" name="m_email" placeholder="missionary@example.com"></div><div class="fg"><label>Organization</label><input type="text" name="m_org" placeholder="OMF International"></div></div>
      <div class="fg"><label>Notes</label><input type="text" name="m_notes" placeholder="Ministry focus…"></div>
      <button type="submit" class="btn btn-dark" style="margin-top:.2rem">+ Add Partner</button>
    </form>
  </div>
  <div class="card">
    <div class="card-title">All Partners (<?= count($missionaries) ?>)</div>
    <?php foreach($missionaries as $i=>$m):
      $init = strtoupper(substr($m['name'],0,1));
      $tot  = $db->prepare("SELECT COUNT(*) cnt,COALESCE(SUM(total_myr),0) amt FROM donations WHERE missionary=?");
      $tot->execute([$m['name']]); $mstats=$tot->fetch();
    ?>
    <div class="miss-card <?= $m['active']?'':'inactive' ?>">
      <div class="miss-avatar"><?= h($init) ?></div>
      <div style="flex:1;min-width:0">
        <div class="miss-name"><?= h($m['name']) ?> <?= !$m['active']?'<span style="font-size:.68rem;color:var(--muted);font-weight:400">(hidden)</span>':'' ?></div>
        <div class="miss-meta"><?= h($m['field']) ?><?= $m['org']?' · '.h($m['org']):'' ?></div>
        <?php if($m['email']): ?><div class="miss-meta"><?= h($m['email']) ?></div><?php endif; ?>
      </div>
      <div style="text-align:right;flex-shrink:0">
        <div style="font-family:'Cormorant Garamond',serif;font-size:1rem;font-weight:700;color:var(--success)">RM <?= number_format($mstats['amt'],0) ?></div>
        <div style="font-size:.7rem;color:var(--muted)"><?= $mstats['cnt'] ?> donations</div>
      </div>
      <div style="display:flex;flex-direction:column;gap:.3rem;flex-shrink:0">
        <form method="POST" style="display:inline"><input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>"><input type="hidden" name="action" value="toggle_missionary"><input type="hidden" name="m_id" value="<?= (int)$m['id'] ?>"><input type="hidden" name="tab" value="missionaries"><button class="btn btn-muted btn-sm"><?= $m['active']?'Hide':'Show' ?></button></form>
        <form method="POST" style="display:inline" onsubmit="return confirm('Remove <?= h($m['name']) ?>?')"><input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>"><input type="hidden" name="action" value="delete_missionary"><input type="hidden" name="m_id" value="<?= (int)$m['id'] ?>"><input type="hidden" name="tab" value="missionaries"><button class="btn btn-danger btn-sm">✕</button></form>
      </div>
    </div>
    <?php endforeach; if(empty($missionaries)): ?><div style="color:var(--muted);font-size:.84rem;padding:.5rem 0">No partners added yet.</div><?php endif; ?>
  </div>
</div>
<?php endif; ?>


<!-- ═══════════════ RATES ═══════════════ -->
<div id="tab-rates" class="tab-panel <?= $tab==='rates'?'active':'' ?>">
  <div class="ph"><div class="ph-title">💱 Exchange Rates</div></div>
  <div class="card" style="padding:.9rem 1.1rem;margin-bottom:1rem"><p style="font-size:.83rem;color:var(--muted);line-height:1.65">All donations convert to <strong style="color:var(--dark)">MYR (Malaysian Ringgit)</strong> as the base reporting currency. Set 1 unit of each currency = how many MYR below.</p></div>
  <form method="POST">
    <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
    <input type="hidden" name="action" value="save_rates">
    <input type="hidden" name="tab" value="rates">
    <div class="rate-grid">
    <?php foreach($cur_info as $code=>[$flag,$name]):
      $r=$rdb[$code]??null; ?>
    <div class="rate-card">
      <div class="rate-flag"><?= $flag ?></div>
      <div>
        <div class="rate-code"><?= $code ?></div>
        <div class="rate-name"><?= h($name) ?></div>
        <?php if($r): ?><div class="rate-upd">Updated <?= date('d M Y', strtotime($r['updated_at'])) ?></div><?php endif; ?>
      </div>
      <div class="rate-right">
        <input type="number" name="rate[<?= $code ?>]" value="<?= $r?number_format((float)$r['rate_to_myr'],6,'.',''):'' ?>" step="0.000001" min="0.000001" placeholder="0.000000">
        <span>MYR</span>
      </div>
    </div>
    <?php endforeach; ?>
    </div>
    <button type="submit" class="btn btn-dark" style="margin-top:1.1rem;padding:.7rem 2rem;font-size:.9rem">💾 Save All Rates</button>
  </form>
</div>


<!-- ═══════════════ CURRENCIES & COUNTRIES ═══════════════ -->
<?php if(has_role(ROLE_ADMIN)): ?>
<div id="tab-currencies" class="tab-panel <?= $tab==='currencies'?'active':'' ?>">
  <div class="ph"><div class="ph-title">🌐 Currencies &amp; Countries</div></div>

  <!-- ── CURRENCIES ── -->
  <div class="card" style="margin-bottom:1.1rem">
    <div class="card-title">
      💱 Donation Currencies
      <span style="font-size:.76rem;font-weight:400;color:var(--muted)">Check to show on donate page · drag to reorder</span>
    </div>
    <form method="POST">
      <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
      <input type="hidden" name="action" value="save_currencies">
      <input type="hidden" name="tab" value="currencies">
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:.6rem;margin-bottom:1rem">
        <?php foreach($currencies_all as $c):
          $isBase = $c['code']==='MYR'; ?>
        <label style="display:flex;align-items:center;gap:.65rem;background:<?= $c['active']?'var(--gold-pale2)':'#f9f9f9' ?>;border:1.5px solid <?= $c['active']?'var(--border)':'#eee' ?>;border-radius:10px;padding:.65rem .85rem;cursor:pointer;transition:all .2s;user-select:none">
          <input type="checkbox" name="cur_active[]" value="<?= h($c['code']) ?>"
            <?= $c['active']?'checked':'' ?> <?= $isBase?'disabled':'' ?>
            onchange="this.closest('label').style.background=this.checked?'var(--gold-pale2)':'#f9f9f9';this.closest('label').style.borderColor=this.checked?'var(--border)':'#eee'">
          <span style="font-size:1.4rem;flex-shrink:0"><?= h($c['flag']) ?></span>
          <div style="flex:1;min-width:0">
            <div style="font-weight:700;font-size:.84rem;color:var(--dark)"><?= h($c['code']) ?> <span style="font-size:.7rem;color:var(--muted);font-weight:400"><?= h($c['symbol']) ?></span></div>
            <div style="font-size:.7rem;color:var(--muted)"><?= h($c['name']) ?></div>
          </div>
          <input type="number" name="cur_order[<?= h($c['code']) ?>]" value="<?= (int)$c['sort_order'] ?>"
            style="width:40px;border:1.5px solid #e4e4e4;border-radius:6px;padding:.18rem .28rem;font-size:.75rem;text-align:center;outline:none;background:#fff;font-family:'DM Sans',sans-serif"
            title="Sort order" min="1" max="99">
          <?php if($isBase): ?><span style="font-size:.62rem;color:var(--gold);font-weight:700;background:var(--gold-pale);border-radius:4px;padding:.08rem .35rem">Base</span><?php endif; ?>
        </label>
        <?php endforeach; ?>
      </div>
      <div style="display:flex;gap:.6rem;flex-wrap:wrap;align-items:flex-end;border-top:1px solid var(--light);padding-top:.9rem">
        <div style="display:flex;gap:.5rem;flex-wrap:wrap;flex:1;align-items:flex-end">
          <div class="fg" style="margin-bottom:0;min-width:75px"><label>Code *</label><input type="text" name="new_cur_code" placeholder="e.g. CNY" style="text-transform:uppercase" maxlength="10"></div>
          <div class="fg" style="margin-bottom:0;flex:1;min-width:130px"><label>Name *</label><input type="text" name="new_cur_name" placeholder="e.g. Chinese Yuan"></div>
          <div class="fg" style="margin-bottom:0;width:70px"><label>Flag</label><input type="text" name="new_cur_flag" placeholder="🇨🇳"></div>
          <div class="fg" style="margin-bottom:0;width:70px"><label>Symbol</label><input type="text" name="new_cur_sym" placeholder="¥"></div>
          <button type="submit" class="btn btn-dark" style="margin-bottom:0;align-self:flex-end">+ Add Currency</button>
        </div>
      </div>
      <div style="display:flex;gap:.5rem;margin-top:.9rem">
        <button type="submit" class="btn btn-gold" style="padding:.6rem 1.5rem">💾 Save Currency Settings</button>
      </div>
    </form>
    <!-- Delete currency -->
    <div style="margin-top:.9rem;padding:.7rem .9rem;background:var(--danger-bg);border-radius:9px;border:1px solid rgba(193,18,31,.15);display:flex;align-items:center;gap:.6rem;flex-wrap:wrap">
      <span style="font-size:.78rem;color:var(--danger);font-weight:600">⚠ Remove currency:</span>
      <form method="POST" style="display:flex;gap:.4rem;align-items:center" onsubmit="return confirm('Remove this currency? This will not affect existing donation records.')">
        <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
        <input type="hidden" name="action" value="save_currencies">
        <input type="hidden" name="tab" value="currencies">
        <select name="del_cur" style="border:1.5px solid rgba(193,18,31,.3);border-radius:7px;padding:.3rem .5rem;font-size:.79rem;outline:none;background:#fff;font-family:'DM Sans',sans-serif">
          <option value="">Select to remove…</option>
          <?php foreach($currencies_all as $c): if($c['code']==='MYR')continue; ?>
          <option value="<?= h($c['code']) ?>"><?= h($c['flag']) ?> <?= h($c['code']) ?> — <?= h($c['name']) ?></option>
          <?php endforeach; ?>
        </select>
        <button type="submit" class="btn btn-danger btn-sm">✕ Remove</button>
      </form>
    </div>
    <p style="font-size:.73rem;color:var(--muted);margin-top:.6rem">💡 Exchange rates for active currencies must also be set in the 💱 Rates tab. MYR is always shown and cannot be removed.</p>
  </div>

  <!-- ── COUNTRIES ── -->
  <div class="card">
    <div class="card-title">
      🌍 Donation Countries
      <span style="font-size:.76rem;font-weight:400;color:var(--muted)">Country dropdown shown on donate form</span>
    </div>
    <form method="POST">
      <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
      <input type="hidden" name="action" value="save_countries">
      <input type="hidden" name="tab" value="currencies">
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:.5rem;margin-bottom:1rem">
        <?php foreach($countries_all as $c): ?>
        <label style="display:flex;align-items:center;gap:.6rem;background:<?= $c['active']?'var(--gold-pale2)':'#f9f9f9' ?>;border:1.5px solid <?= $c['active']?'var(--border)':'#eee' ?>;border-radius:9px;padding:.55rem .75rem;cursor:pointer;transition:all .2s;user-select:none">
          <input type="checkbox" name="cty_active[]" value="<?= (int)$c['id'] ?>"
            <?= $c['active']?'checked':'' ?>
            onchange="this.closest('label').style.background=this.checked?'var(--gold-pale2)':'#f9f9f9';this.closest('label').style.borderColor=this.checked?'var(--border)':'#eee'">
          <span style="font-size:1.2rem;flex-shrink:0"><?= h($c['flag']) ?></span>
          <span style="font-weight:600;font-size:.82rem;color:var(--dark);flex:1"><?= h($c['name']) ?></span>
          <input type="number" name="cty_order[<?= (int)$c['id'] ?>]" value="<?= (int)$c['sort_order'] ?>"
            style="width:38px;border:1.5px solid #e4e4e4;border-radius:6px;padding:.18rem .25rem;font-size:.72rem;text-align:center;outline:none;background:#fff;font-family:'DM Sans',sans-serif"
            title="Sort order" min="1" max="999">
        </label>
        <?php endforeach; ?>
      </div>
      <div style="display:flex;gap:.5rem;flex-wrap:wrap;align-items:flex-end;border-top:1px solid var(--light);padding-top:.9rem;margin-bottom:.9rem">
        <div class="fg" style="margin-bottom:0;flex:1;min-width:140px"><label>Country Name *</label><input type="text" name="new_cty_name" placeholder="e.g. Brunei"></div>
        <div class="fg" style="margin-bottom:0;width:75px"><label>Code</label><input type="text" name="new_cty_code" placeholder="BN" maxlength="5"></div>
        <div class="fg" style="margin-bottom:0;width:70px"><label>Flag</label><input type="text" name="new_cty_flag" placeholder="🇧🇳"></div>
        <button type="submit" class="btn btn-dark" style="align-self:flex-end">+ Add Country</button>
      </div>
      <div style="display:flex;gap:.5rem;flex-wrap:wrap;align-items:center">
        <button type="submit" class="btn btn-gold" style="padding:.6rem 1.5rem">💾 Save Country List</button>
        <!-- Delete -->
        <form method="POST" style="display:flex;gap:.4rem;align-items:center" onsubmit="return confirm('Remove this country?')">
          <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
          <input type="hidden" name="action" value="save_countries">
          <input type="hidden" name="tab" value="currencies">
          <select name="del_cty" style="border:1.5px solid #e4e4e4;border-radius:7px;padding:.3rem .5rem;font-size:.79rem;outline:none;background:#fff;font-family:'DM Sans',sans-serif">
            <option value="">Remove a country…</option>
            <?php foreach($countries_all as $c): ?>
            <option value="<?= (int)$c['id'] ?>"><?= h($c['flag']) ?> <?= h($c['name']) ?></option>
            <?php endforeach; ?>
          </select>
          <button type="submit" class="btn btn-danger btn-sm">✕</button>
        </form>
      </div>
    </form>
  </div>
</div>
<?php endif; ?>

<!-- ═══════════════ BACKUP ═══════════════ -->
<div id="tab-backup" class="tab-panel <?= $tab==='backup'?'active':'' ?>">
  <div class="ph"><div class="ph-title">💾 Backup &amp; Export</div></div>
  <div class="backup-grid">
    <div class="backup-card">
      <div style="font-size:2.2rem;margin-bottom:.7rem">📊</div>
      <div style="font-family:'Cormorant Garamond',serif;font-size:1.15rem;font-weight:700;color:var(--dark);margin-bottom:.4rem">Export CSV</div>
      <p style="font-size:.8rem;color:var(--muted);line-height:1.55;margin-bottom:1rem">Download all donation records as a spreadsheet. Opens in Excel, Numbers, Google Sheets — Mac, PC, tablet.</p>
      <a href="export.php?type=csv" class="btn btn-gold" style="width:100%;justify-content:center">⬇ Download CSV</a>
    </div>
    <div class="backup-card">
      <div style="font-size:2.2rem;margin-bottom:.7rem">🗄️</div>
      <div style="font-family:'Cormorant Garamond',serif;font-size:1.15rem;font-weight:700;color:var(--dark);margin-bottom:.4rem">Full JSON Backup</div>
      <p style="font-size:.8rem;color:var(--muted);line-height:1.55;margin-bottom:1rem">Complete backup including donations, missionaries and exchange rates. Save to Google Drive, iCloud, or OneDrive.</p>
      <a href="export.php?type=json" class="btn btn-green" style="width:100%;justify-content:center">⬇ Download JSON</a>
    </div>
    <div class="backup-card" style="background:var(--gold-pale);border:1px solid var(--border)">
      <div style="font-size:2.2rem;margin-bottom:.7rem">🔒</div>
      <div style="font-family:'Cormorant Garamond',serif;font-size:1.15rem;font-weight:700;color:var(--dark);margin-bottom:.5rem">Security Status</div>
      <ul style="font-size:.79rem;color:#5a4a00;line-height:1.8;padding-left:1rem">
        <li>Passwords bcrypt hashed — never plain text</li>
        <li>5-attempt lockout · 15 min duration</li>
        <li>Every action audit-logged with IP</li>
        <li>Session expires after 30 min idle</li>
        <li>CSRF protection on all forms</li>
        <li>Security headers enforced</li>
      </ul>
    </div>
  </div>
</div>

</div><!-- /container -->


<!-- ═══════════════ RECEIPT MODAL ═══════════════ -->
<div class="overlay" id="receiptOverlay">
  <div class="receipt-modal receipt-printable" id="receiptContent">
    <!-- Populated by JS -->
  </div>
</div>

<!-- Donation data for JS receipt rendering -->
<script>
const DONATIONS_DATA = <?= json_encode(array_map(function($d) use ($CURRSYM) {
  return [
    'ref'        => $d['ref'],
    'date'       => date('d F Y', strtotime($d['created_at'])),
    'time'       => date('H:i', strtotime($d['created_at'])),
    'name'       => $d['first_name'].' '.$d['last_name'],
    'email'      => $d['email'],
    'phone'      => $d['phone'] ?? '',
    'country'    => $d['country'] ?? '',
    'amount'     => number_format((float)$d['amount'], 2),
    'currency'   => $d['currency'],
    'sym'        => $CURRSYM[$d['currency']] ?? $d['currency'].' ',
    'myr'        => number_format((float)$d['myr_equivalent'], 2),
    'fee'        => number_format((float)$d['fee_amount'], 2),
    'cover_fee'  => (bool)$d['cover_fee'],
    'total_myr'  => number_format((float)$d['total_myr'], 2),
    'missionary' => $d['missionary'] ?? '',
    'fund'       => $d['fund'],
    'monthly'    => (bool)$d['monthly'],
    'remarks'    => $d['remarks'] ?? '',
  ];
}, $donations), JSON_HEX_TAG|JSON_HEX_APOS|JSON_UNESCAPED_UNICODE) ?>;

function openReceipt(ref) {
  const d = DONATIONS_DATA.find(x => x.ref === ref);
  if (!d) { alert('Receipt data not found. Try refreshing the page.'); return; }

  const isMYR = d.currency === 'MYR';
  const amtLine = isMYR
    ? `RM ${d.amount}`
    : `${d.sym}${d.amount} ${d.currency} <span style="font-size:1rem;color:#8B6914">(≈ RM ${d.myr})</span>`;

  const printDate = new Date().toLocaleDateString('en-GB', {day:'numeric',month:'long',year:'numeric',hour:'2-digit',minute:'2-digit'});

  document.getElementById('receiptContent').innerHTML = `
    <div class="receipt-header">
      <div class="receipt-org">✛ ACNC Mission</div>
      <div class="receipt-org-sub">All Christian Nations Connect · Donation Receipt</div>
      <div class="receipt-ref-pill">🧾 ${d.ref}</div>
    </div>
    <div class="receipt-body" data-date="${printDate}">

      <div class="receipt-amount-block">
        <div class="receipt-amount-label">Donation Amount</div>
        <div class="receipt-amount-main">${amtLine}</div>
        <div class="receipt-amount-myr">MYR Equivalent: RM ${d.total_myr}${d.cover_fee ? ' (incl. transaction fee RM '+d.fee+')' : ''}</div>
        ${d.monthly ? '<div style="margin-top:.5rem"><span style="background:var(--success-bg);border:1px solid rgba(27,122,74,.2);border-radius:8px;padding:.25rem .75rem;font-size:.76rem;font-weight:600;color:var(--success)">📅 Monthly Recurring Donation</span></div>' : ''}
      </div>

      <div class="receipt-section">
        <div class="receipt-section-title">Donor Information</div>
        <div class="receipt-row"><span class="lbl">Full Name</span><span class="val">${d.name}</span></div>
        <div class="receipt-row"><span class="lbl">Email</span><span class="val">${d.email}</span></div>
        ${d.phone ? `<div class="receipt-row"><span class="lbl">Phone</span><span class="val">${d.phone}</span></div>` : ''}
        ${d.country ? `<div class="receipt-row"><span class="lbl">Country</span><span class="val">${d.country}</span></div>` : ''}
      </div>

      <div class="receipt-section">
        <div class="receipt-section-title">Mission Details</div>
        <div class="receipt-row"><span class="lbl">Missionary Partner</span><span class="val">${d.missionary || '—'}</span></div>
        <div class="receipt-row"><span class="lbl">Fund / Purpose</span><span class="val">${d.fund}</span></div>
        <div class="receipt-row"><span class="lbl">Donation Type</span><span class="val">${d.monthly ? '📅 Monthly Recurring' : '🕊 One-time Gift'}</span></div>
        ${d.remarks ? `<div class="receipt-row"><span class="lbl">Remarks</span><span class="val" style="font-style:italic">${d.remarks}</span></div>` : ''}
      </div>

      <div class="receipt-section">
        <div class="receipt-section-title">Transaction Details</div>
        <div class="receipt-row"><span class="lbl">Reference No.</span><span class="val" style="font-family:'Cormorant Garamond',serif;font-size:.95rem;font-weight:700;color:var(--dark3)">${d.ref}</span></div>
        <div class="receipt-row"><span class="lbl">Date</span><span class="val">${d.date}</span></div>
        <div class="receipt-row"><span class="lbl">Time</span><span class="val">${d.time}</span></div>
      </div>

      <div class="receipt-confirmed">✓ Donation recorded and confirmed</div>

      <div class="receipt-footer-note">
        Thank you for your generous gift to God's mission. Your donation supports unreached people group (UUPG) ministry through ACNC — All Christian Nations Connect.<br>
        <strong>For tax receipts or queries:</strong> donations@bbcmhk.org
      </div>
    </div>
    <div class="receipt-actions">
      <button class="btn btn-dark" onclick="window.print()">🖨 Print Receipt</button>
      <button class="btn btn-gold" onclick="copyReceiptText('${d.ref}','${d.name}','${d.sym}${d.amount}','${d.date}')">📋 Copy Details</button>
      <button class="btn btn-muted" onclick="closeReceipt()" style="margin-left:auto">✕ Close</button>
    </div>`;

  document.getElementById('receiptOverlay').classList.add('open');
}

function closeReceipt() {
  document.getElementById('receiptOverlay').classList.remove('open');
}
document.getElementById('receiptOverlay').addEventListener('click', function(e) {
  if(e.target === this) closeReceipt();
});

function copyReceiptText(ref, name, amt, date) {
  const text = `ACNC Donation Receipt\nRef: ${ref}\nDonor: ${name}\nAmount: ${amt}\nDate: ${date}\nFor queries: donations@bbcmhk.org`;
  navigator.clipboard.writeText(text).then(() => {
    showToast('📋 Receipt details copied!');
  }).catch(() => {
    showToast('Could not copy — please do it manually.');
  });
}

/* ══ Tab switching ══ */
function switchTab(tab) {
  document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  const panel = document.getElementById('tab-' + tab);
  if (panel) panel.classList.add('active');
  const btn = Array.from(document.querySelectorAll('.tab-btn')).find(b => b.getAttribute('onclick')?.includes("'" + tab + "'"));
  if (btn) btn.classList.add('active');
  history.replaceState({}, '', '?tab=' + tab);
}

function showToast(msg) {
  const t = document.getElementById('toast');
  if (t) { t.textContent = msg; t.classList.add('show'); setTimeout(() => t.classList.remove('show'), 3000); }
}

/* ══ Charts ══ */
const monthLabels  = <?= json_encode(array_column($monthly_data,'mon')) ?>;
const monthAmts    = <?= json_encode(array_map(fn($m)=>round($m['amt'],2),$monthly_data)) ?>;
const monthCounts  = <?= json_encode(array_column($monthly_data,'cnt')) ?>;
const missLabels   = <?= json_encode(array_column($top_miss,'missionary')) ?>;
const missAmts     = <?= json_encode(array_map(fn($m)=>round($m['amt'],2),$top_miss)) ?>;
const fundLabels   = <?= json_encode(array_column($fund_breakdown,'fund')) ?>;
const fundAmts     = <?= json_encode(array_map(fn($f)=>round($f['amt'],2),$fund_breakdown)) ?>;

const chartDefaults = {
  font: { family: "'DM Sans', sans-serif" },
  color: '#7A7A8C',
  plugins: { legend: { display: false }, tooltip: { callbacks: { label: ctx => ' RM ' + ctx.parsed.y?.toLocaleString() || ctx.parsed } } }
};

function makeBarChart(id, labels, data, color='rgba(201,168,76,0.85)') {
  const el = document.getElementById(id);
  if (!el || !labels.length) return;
  new Chart(el, {
    type: 'bar',
    data: {
      labels,
      datasets: [{
        data,
        backgroundColor: color,
        borderRadius: 6,
        borderSkipped: false,
      }]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: { legend:{display:false}, tooltip:{ callbacks:{ label: ctx => ' RM '+ctx.parsed.y.toLocaleString() }}},
      scales: {
        x: { grid:{display:false}, ticks:{color:'#7A7A8C',font:{size:10}} },
        y: { grid:{color:'rgba(0,0,0,.06)'}, ticks:{color:'#7A7A8C',font:{size:10}, callback: v => 'RM'+v.toLocaleString()}}
      }
    }
  });
}

function makeLineChart(id, labels, data) {
  const el = document.getElementById(id);
  if (!el || !labels.length) return;
  new Chart(el, {
    type: 'line',
    data: {
      labels,
      datasets: [{
        data,
        borderColor: '#C9A84C',
        backgroundColor: 'rgba(201,168,76,.12)',
        borderWidth: 2.5,
        pointBackgroundColor: '#C9A84C',
        pointRadius: 4,
        fill: true,
        tension: 0.3,
      }]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: { legend:{display:false}, tooltip:{callbacks:{label: ctx => ' '+ctx.parsed.y+' donations'}}},
      scales: {
        x: { grid:{display:false}, ticks:{color:'#7A7A8C',font:{size:10}} },
        y: { grid:{color:'rgba(0,0,0,.06)'}, ticks:{color:'#7A7A8C',font:{size:10},stepSize:1}}
      }
    }
  });
}

function makeDoughnut(id, labels, data) {
  const el = document.getElementById(id);
  if (!el || !labels.length) return;
  const colors = ['#C9A84C','#0F3460','#1B7A4A','#C1121F','#e65c00','#7A7A8C','#9c27b0','#00838f'];
  new Chart(el, {
    type: 'doughnut',
    data: {
      labels,
      datasets: [{ data, backgroundColor: colors.slice(0,labels.length), borderWidth: 2, borderColor: '#fff' }]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: {
        legend: { position: 'right', labels: { boxWidth: 10, font: { size: 10 }, color: '#7A7A8C' }},
        tooltip: { callbacks: { label: ctx => ' RM '+ctx.parsed.toLocaleString() }}
      },
      cutout: '60%'
    }
  });
}

// Render all charts
makeBarChart('chartMonthly',    monthLabels, monthAmts);
makeBarChart('chartMonthlyAmt', monthLabels, monthAmts);
makeLineChart('chartMonthlyCnt', monthLabels, monthCounts);
makeBarChart('chartMiss',  missLabels, missAmts,  'rgba(15,52,96,0.8)');
makeDoughnut('chartFunds',  fundLabels, fundAmts);
makeDoughnut('chartFunds2', fundLabels, fundAmts);
</script>

<div class="toast" id="toast" style="position:fixed;bottom:1.4rem;right:1.4rem;background:var(--dark);color:#fff;padding:.7rem 1.1rem;border-radius:11px;font-size:.82rem;z-index:9999;transform:translateY(80px);opacity:0;transition:all .35s;border-left:4px solid var(--gold);box-shadow:0 8px 32px rgba(0,0,0,.12);max-width:300px"></div>
<style>.toast.show{transform:translateY(0)!important;opacity:1!important}</style>

</body>
</html>
