<?php
session_start();
require_once '../config.php';
// Log the logout before destroying session
if (is_logged_in()) {
    audit('LOGOUT', 'User logged out');
}
$_SESSION = [];
if (ini_get('session.use_cookies')) {
    $p = session_get_cookie_params();
    setcookie(session_name(),'',time()-42000,$p['path'],$p['domain'],$p['secure'],$p['httponly']);
}
session_destroy();
header('Location: ../login.php?logged_out=1');
exit;
