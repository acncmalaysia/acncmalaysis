<?php
session_start();
require_once '../config.php';
send_security_headers();
require_super();

$db = getDB();
$flash = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify($_POST['csrf_token'] ?? '')) die('Security error.');
    $action = $_POST['action'] ?? '';

    // ── ADD USER ────────────────────────────────────────────
    if ($action === 'add_user') {
        $uname = strtolower(trim($_POST['username'] ?? ''));
        $email = strtolower(trim($_POST['email'] ?? ''));
        $fname = trim($_POST['full_name'] ?? '');
        $role  = $_POST['role'] ?? 'viewer';
        $pw    = $_POST['password'] ?? '';
        if (!in_array($role, ['super_admin','admin','editor','viewer'])) $role = 'viewer';

        if (!$uname || !$email || !$pw) { $flash = 'error:Username, email and password are required.'; }
        elseif (!preg_match('/^[a-z0-9_]{3,30}$/', $uname)) { $flash = 'error:Username must be 3–30 characters, letters/numbers/underscores only.'; }
        elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) { $flash = 'error:Please enter a valid email address.'; }
        elseif ($errs = validate_password($pw)) { $flash = 'error:' . implode(' ', $errs); }
        else {
            try {
                $hash = password_hash($pw, PASSWORD_BCRYPT, ['cost' => 12]);
                $db->prepare("INSERT INTO admin_users (username,email,password_hash,role,full_name,created_by,force_pw_change) VALUES (?,?,?,?,?,?,1)")
                   ->execute([$uname, $email, $hash, $role, $fname, current_uid()]);
                audit('USER_CREATED', "Created user: $uname ($role)");
                // ── Send welcome email to new admin user ─────────────
                $siteName  = defined('SITE_NAME') ? SITE_NAME : 'ACNC Admin';
                $siteUrl   = defined('SITE_URL')  ? SITE_URL  : '';
                $siteHost  = parse_url($siteUrl, PHP_URL_HOST) ?: 'yourdomain.com';
                $loginUrl  = rtrim($siteUrl, '/') . '/login.php';
                $createdBy = current_user();
                $roleLabel = [
                    'super_admin' => 'Super Admin',
                    'admin'       => 'Admin',
                    'editor'      => 'Editor',
                    'viewer'      => 'Viewer',
                ][$role] ?? ucfirst($role);

                $displayName = $fname ?: $uname;

                $welcomeSubject = "Welcome to $siteName — Your Admin Account";

                $welcomeBody = <<<MAIL
Dear $displayName,

Your admin account for $siteName has been set up. You can now
log in and begin using the system.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  YOUR LOGIN DETAILS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  Login URL  : $loginUrl
  Username   : $uname
  Password   : $pw
  Role       : $roleLabel

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

⚠  IMPORTANT — FIRST LOGIN
You will be required to change your password immediately
after signing in for the first time. Please choose a strong
password that is at least 10 characters long and includes
uppercase, lowercase, a number, and a special character.

🔒 KEEP THIS EMAIL CONFIDENTIAL
Do not forward or share your login credentials. If you
did not expect this account, please contact the admin
immediately at $createdBy.

YOUR ACCESS LEVEL ($roleLabel)
MAIL;

                if ($role === 'super_admin') {
                    $welcomeBody .= "
  Full access: users, donations, partners, rates, content, backup.";
                } elseif ($role === 'admin') {
                    $welcomeBody .= "
  Access: donations, partners, exchange rates, content, backup.";
                } elseif ($role === 'editor') {
                    $welcomeBody .= "
  Access: view and edit donations + exchange rates only.";
                } else {
                    $welcomeBody .= "
  Access: read-only view of donation records.";
                }

                $welcomeBody .= <<<MAIL


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

If you have any questions, reply to this email or contact
the system administrator directly.

God bless your service,

✛ $siteName
$siteUrl

This is an automated message. Please do not reply.
MAIL;

                $welcomeHeaders  = "From: $siteName <noreply@$siteHost>\r\n";
                $welcomeHeaders .= "Reply-To: " . CONTACT_EMAIL . "\r\n";
                $welcomeHeaders .= "Content-Type: text/plain; charset=UTF-8\r\n";
                $welcomeHeaders .= "X-Mailer: ACNC-AdminSystem/3.0\r\n";

                @mail($email, $welcomeSubject, $welcomeBody, $welcomeHeaders);
                $flash = 'success:User ' . $uname . ' created. Welcome email sent to ' . $email . '.';
            } catch (PDOException $e) { $flash = 'error:Username or email already exists.'; }
        }
    }

    // ── EDIT USER (inline) ─────────────────────────────────
    elseif ($action === 'edit_user') {
        $uid   = (int)$_POST['uid'];
        $fname = trim($_POST['full_name'] ?? '');
        $email = strtolower(trim($_POST['email'] ?? ''));
        $role  = $_POST['role'] ?? 'viewer';
        if (!in_array($role, ['super_admin','admin','editor','viewer'])) $role = 'viewer';
        if ($uid === current_uid() && $role !== current_role()) {
            $flash = 'error:You cannot change your own role.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $flash = 'error:Please enter a valid email address.';
        } else {
            $db->prepare("UPDATE admin_users SET full_name=?, email=?, role=? WHERE id=?")
               ->execute([$fname, $email, $role, $uid]);
            audit('USER_EDITED', "Edited user ID $uid — name, email, role → $role");
            $flash = 'success:User details updated successfully.';
        }
    }

    // ── RESET PASSWORD ─────────────────────────────────────
    elseif ($action === 'reset_password') {
        $uid = (int)$_POST['uid'];
        $pw  = $_POST['new_password'] ?? '';
        if ($errs = validate_password($pw)) { $flash = 'error:' . implode(' ', $errs); }
        else {
            $hash = password_hash($pw, PASSWORD_BCRYPT, ['cost' => 12]);
            $db->prepare("UPDATE admin_users SET password_hash=?, force_pw_change=1 WHERE id=?")->execute([$hash, $uid]);
            audit('PASSWORD_RESET', "Reset password for user ID $uid");
            $flash = 'success:Password reset. User must change it on next login.';
        }
    }

    // ── TOGGLE ACTIVE ──────────────────────────────────────
    elseif ($action === 'toggle_user') {
        $uid = (int)$_POST['uid'];
        if ($uid === current_uid()) { $flash = 'error:You cannot deactivate your own account.'; }
        else {
            $db->prepare("UPDATE admin_users SET active=1-active WHERE id=?")->execute([$uid]);
            audit('USER_TOGGLE', "Toggled active status for user ID $uid");
            $flash = 'success:User status updated.';
        }
    }

    // ── DELETE USER ────────────────────────────────────────
    elseif ($action === 'delete_user') {
        $uid = (int)$_POST['uid'];
        if ($uid === current_uid()) { $flash = 'error:You cannot delete your own account.'; }
        else {
            $stmt = $db->prepare("SELECT username FROM admin_users WHERE id=?");
            $stmt->execute([$uid]);
            $uname = $stmt->fetchColumn();
            $db->prepare("DELETE FROM admin_users WHERE id=?")->execute([$uid]);
            audit('USER_DELETED', "Deleted user: $uname (ID $uid)");
            $flash = 'success:User deleted permanently.';
        }
    }
}

$users  = $db->query("SELECT u.*, (SELECT COUNT(*) FROM audit_log WHERE user_id=u.id) action_count FROM admin_users u ORDER BY FIELD(u.role,'super_admin','admin','editor','viewer'), u.username")->fetchAll();
$audits = $db->query("SELECT * FROM audit_log ORDER BY created_at DESC LIMIT 60")->fetchAll();
$logins = $db->query("SELECT * FROM login_attempts ORDER BY attempted_at DESC LIMIT 40")->fetchAll();
[$ft,$fm] = $flash ? explode(':', $flash, 2) : ['',''];

$ROLES = [
    'super_admin' => ['icon'=>'🔴','label'=>'Super Admin','color'=>'#C1121F','bg'=>'rgba(193,18,31,.1)','border'=>'rgba(193,18,31,.25)','desc'=>'Full access including user management'],
    'admin'       => ['icon'=>'🟠','label'=>'Admin',      'color'=>'#e65c00','bg'=>'rgba(230,92,0,.1)', 'border'=>'rgba(230,92,0,.25)', 'desc'=>'Donations, partners, rates, content, backup'],
    'editor'      => ['icon'=>'🟢','label'=>'Editor',     'color'=>'#1B7A4A','bg'=>'rgba(27,122,74,.1)','border'=>'rgba(27,122,74,.25)','desc'=>'View & write donations + exchange rates only'],
    'viewer'      => ['icon'=>'🔵','label'=>'Viewer',     'color'=>'#0F3460','bg'=>'rgba(15,52,96,.1)', 'border'=>'rgba(15,52,96,.25)', 'desc'=>'Read-only: view donations only'],
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>User Management — ACNC Admin</title>
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@600;700&family=DM+Sans:wght@400;500;600&display=swap" rel="stylesheet">
<style>
:root{--gold:#C9A84C;--gold-pale:#F5EDD3;--gold-pale2:#FDF6E3;--dark:#1A1A2E;--dark3:#0F3460;--cream:#FAF8F3;--white:#fff;--text:#1E1E2E;--muted:#7A7A8C;--light:#F0EEE8;--success:#1B7A4A;--success-bg:#D6F0E3;--danger:#C1121F;--danger-bg:#FFE4E6;--shadow:0 2px 16px rgba(0,0,0,.07)}
*{box-sizing:border-box;margin:0;padding:0}body{font-family:'DM Sans',sans-serif;background:var(--cream);color:var(--text)}
nav{background:var(--dark);display:flex;align-items:center;justify-content:space-between;padding:0 1.4rem;height:56px;border-bottom:2px solid var(--gold);position:sticky;top:0;z-index:100}
.nav-brand{font-family:'Cormorant Garamond',serif;color:var(--gold);font-size:1.18rem;font-weight:700}
.nav-right{display:flex;align-items:center;gap:.4rem}
.nav-right a{color:rgba(255,255,255,.5);font-size:.76rem;text-decoration:none;padding:.3rem .65rem;border-radius:6px;transition:all .2s}
.nav-right a:hover{background:rgba(255,255,255,.07);color:#E8C97A}
.nav-right .lo{color:rgba(255,100,100,.65)}.nav-right .lo:hover{background:#c1121f;color:#fff}

.tab-bar{background:var(--white);border-bottom:1px solid var(--light);display:flex;padding:0 1rem;overflow-x:auto}
.tab-btn{border:none;background:none;padding:.7rem .9rem;font-family:'DM Sans',sans-serif;font-size:.8rem;font-weight:600;color:var(--muted);cursor:pointer;border-bottom:3px solid transparent;white-space:nowrap;transition:all .2s}
.tab-btn:hover{color:var(--dark)}.tab-btn.active{color:var(--dark3);border-bottom-color:var(--gold)}
.tab-panel{display:none}.tab-panel.active{display:block}

.container{max-width:1050px;margin:0 auto;padding:1.4rem 1rem 3rem}
.ph{display:flex;align-items:center;justify-content:space-between;margin-bottom:1rem;flex-wrap:wrap;gap:.5rem;padding-top:.3rem}
.ph-title{font-family:'Cormorant Garamond',serif;font-size:1.35rem;font-weight:700;color:var(--dark)}

/* Role legend */
.role-legend{display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:.6rem;margin-bottom:1.2rem}
.role-legend-card{background:var(--white);border-radius:11px;padding:.8rem 1rem;box-shadow:var(--shadow);border:1px solid rgba(0,0,0,.04);display:flex;align-items:flex-start;gap:.7rem}
.role-legend-icon{font-size:1.2rem;flex-shrink:0;margin-top:.05rem}
.role-legend-label{font-weight:700;font-size:.84rem;margin-bottom:.1rem}
.role-legend-desc{font-size:.72rem;color:var(--muted);line-height:1.4}
.role-legend-perms{display:flex;flex-wrap:wrap;gap:.25rem;margin-top:.4rem}
.perm-tag{display:inline-block;border-radius:4px;padding:.08rem .45rem;font-size:.62rem;font-weight:700;text-transform:uppercase;letter-spacing:.3px}

/* Flash */
.flash{border-radius:9px;padding:.65rem .95rem;font-size:.83rem;margin-bottom:1rem;display:flex;align-items:center;gap:.5rem}
.flash-ok{background:var(--success-bg);border:1px solid rgba(27,122,74,.2);color:var(--success)}
.flash-err{background:var(--danger-bg);border:1px solid rgba(193,18,31,.2);color:var(--danger)}

/* User cards */
.user-card{background:var(--white);border:1.5px solid var(--light);border-radius:14px;margin-bottom:.8rem;box-shadow:var(--shadow);overflow:hidden;transition:border .2s}
.user-card.editing{border-color:var(--gold);box-shadow:0 0 0 3px rgba(201,168,76,.12)}
.user-card-head{display:flex;align-items:center;justify-content:space-between;padding:1rem 1.2rem;flex-wrap:wrap;gap:.6rem}
.user-card-left{display:flex;align-items:center;gap:.85rem}
.avatar{width:40px;height:40px;border-radius:50%;color:#fff;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:1.05rem;flex-shrink:0;letter-spacing:0}
.user-info-name{font-weight:700;font-size:.95rem;color:var(--dark);display:flex;align-items:center;gap:.45rem;flex-wrap:wrap}
.you-badge{font-size:.65rem;background:#DBE9FF;color:var(--dark3);border-radius:8px;padding:.1rem .5rem;font-weight:600}
.forced-badge{font-size:.65rem;background:#FFF3CD;color:#856404;border-radius:8px;padding:.1rem .5rem;font-weight:600}
.user-info-meta{font-size:.74rem;color:var(--muted);margin-top:.08rem;display:flex;align-items:center;gap:.5rem;flex-wrap:wrap}
.role-pill{display:inline-flex;align-items:center;gap:.25rem;border-radius:20px;padding:.16rem .62rem;font-size:.68rem;font-weight:700}
.status-dot{font-size:.72rem;font-weight:600}
.user-card-actions{display:flex;gap:.35rem;flex-wrap:wrap;align-items:center}

/* Edit form (collapsible) */
.edit-form{display:none;padding:0 1.2rem 1.2rem;border-top:1px solid var(--light);background:var(--gold-pale2)}
.edit-form.open{display:block}
.edit-form-grid{display:grid;grid-template-columns:1fr 1fr 1fr;gap:.7rem;margin-top:1rem;margin-bottom:.9rem}
@media(max-width:600px){.edit-form-grid{grid-template-columns:1fr}}
.fg{} .fg label{display:block;font-size:.68rem;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:.4px;margin-bottom:.24rem}
.fg input,.fg select{width:100%;border:1.5px solid #e4e4e4;border-radius:8px;padding:.56rem .78rem;font-family:'DM Sans',sans-serif;font-size:.88rem;outline:none;transition:border .2s;background:#fff}
.fg input:focus,.fg select:focus{border-color:var(--gold);box-shadow:0 0 0 3px rgba(201,168,76,.1)}
.edit-form-actions{display:flex;align-items:center;gap:.5rem;flex-wrap:wrap;padding-top:.3rem;border-top:1px solid var(--border)}

/* Password reset sub-form */
.pw-reset-form{background:var(--white);border:1.5px solid var(--border);border-radius:10px;padding:.9rem 1rem;margin-top:.8rem}
.pw-reset-form h4{font-size:.8rem;font-weight:700;color:var(--dark);margin-bottom:.6rem;display:flex;align-items:center;gap:.35rem}
.pw-wrap{position:relative}
.pw-wrap input{padding-right:2.5rem}
.pw-eye{position:absolute;right:.7rem;top:50%;transform:translateY(-50%);background:none;border:none;cursor:pointer;color:var(--muted);font-size:.82rem;padding:.2rem}
.pw-reqs{font-size:.7rem;color:var(--muted);line-height:1.55;margin-bottom:.5rem}
.strength-bar{height:3px;border-radius:2px;background:#eee;margin-top:.28rem;overflow:hidden}
.strength-fill{height:100%;width:0;transition:all .3s;border-radius:2px}

/* Buttons */
.btn{display:inline-flex;align-items:center;gap:.32rem;border-radius:8px;padding:.4rem .85rem;font-size:.77rem;font-weight:600;cursor:pointer;border:1px solid transparent;transition:all .18s;font-family:'DM Sans',sans-serif;text-decoration:none;white-space:nowrap}
.btn-gold{background:var(--gold-pale);border-color:rgba(201,168,76,.4);color:#7a5500}.btn-gold:hover{background:var(--gold);color:#fff}
.btn-dark{background:var(--dark3);color:#fff}.btn-dark:hover{background:var(--gold);color:var(--dark)}
.btn-success{background:var(--success-bg);border-color:rgba(27,122,74,.2);color:var(--success)}.btn-success:hover{background:var(--success);color:#fff}
.btn-danger{background:var(--danger-bg);border-color:rgba(193,18,31,.15);color:var(--danger)}.btn-danger:hover{background:var(--danger);color:#fff}
.btn-muted{background:var(--light);color:var(--muted);border-color:#ddd}.btn-muted:hover{background:#ddd;color:var(--text)}
.btn-sm{padding:.2rem .52rem;font-size:.7rem}

/* Add user card */
.add-card{background:var(--white);border-radius:14px;padding:1.3rem;box-shadow:var(--shadow);margin-bottom:1.1rem;border:1px solid rgba(0,0,0,.04)}
.add-card-title{font-family:'Cormorant Garamond',serif;font-size:1.1rem;font-weight:700;color:var(--dark);margin-bottom:.9rem;padding-bottom:.55rem;border-bottom:1px solid var(--light)}
.add-grid{display:grid;grid-template-columns:1fr 1fr 1fr;gap:.7rem;margin-bottom:.7rem}
@media(max-width:640px){.add-grid{grid-template-columns:1fr}}
.pw-reqs-box{background:var(--gold-pale);border-radius:8px;padding:.55rem .8rem;font-size:.71rem;color:#7a5500;margin-bottom:.7rem;line-height:1.6}
.pw-reqs-box ul{padding-left:1rem;margin-top:.2rem}

/* Table (audit / login) */
.tbl-wrap{overflow-x:auto}
table{width:100%;border-collapse:collapse;font-size:.79rem}
thead tr{background:var(--dark);color:rgba(255,255,255,.85)}
thead th{padding:.6rem .8rem;text-align:left;font-weight:600;font-size:.71rem;white-space:nowrap}
tbody tr{border-bottom:1px solid #f2f2f2;transition:background .12s}
tbody tr:hover{background:var(--gold-pale2)}
tbody td{padding:.56rem .8rem;vertical-align:middle}
.tag{display:inline-block;border-radius:4px;padding:.1rem .45rem;font-size:.67rem;font-weight:700;background:var(--gold-pale);color:#8B6914}
.acard{background:var(--white);border-radius:14px;padding:1.2rem 1.3rem;box-shadow:var(--shadow);border:1px solid rgba(0,0,0,.04)}
.inactive{opacity:.42}
.meta-footer{display:flex;gap:1.2rem;font-size:.7rem;color:var(--muted);flex-wrap:wrap;padding-top:.4rem;border-top:1px solid var(--light);margin-top:.2rem}
</style>
</head>
<body>

<nav>
  <div class="nav-brand">✛ ACNC Admin — User Management</div>
  <div class="nav-right">
    <a href="dashboard.php">← Dashboard</a>
    <a href="../index.php" target="_blank">🌐 Live Site</a>
    <a href="logout.php" class="lo">⇥ Logout</a>
  </div>
</nav>

<div class="tab-bar">
  <button class="tab-btn active" onclick="switchTab('users',this)">👥 Users (<?= count($users) ?>)</button>
  <button class="tab-btn" onclick="switchTab('add',this)">➕ Add User</button>
  <button class="tab-btn" onclick="switchTab('audit',this)">📋 Audit Log</button>
  <button class="tab-btn" onclick="switchTab('logins',this)">🔐 Login History</button>
</div>

<div class="container">

<?php if ($fm): ?>
<div class="flash flash-<?= $ft==='success'?'ok':'err' ?>"><?= $ft==='success'?'✓':'⚠️' ?> <?= h($fm) ?></div>
<?php endif; ?>

<!-- ══════ USERS TAB ══════ -->
<div id="tab-users" class="tab-panel active">
  <div class="ph"><div class="ph-title">Admin Users</div></div>

  <!-- Role legend -->
  <div class="role-legend">
    <?php foreach($ROLES as $key => $r): ?>
    <div class="role-legend-card">
      <div class="role-legend-icon"><?= $r['icon'] ?></div>
      <div>
        <div class="role-legend-label" style="color:<?= $r['color'] ?>"><?= $r['label'] ?></div>
        <div class="role-legend-desc"><?= $r['desc'] ?></div>
        <div class="role-legend-perms">
          <?php
          $perms = [
            'super_admin' => ['Users','Donations','Partners','Rates','Content','Backup'],
            'admin'       => ['Donations','Partners','Rates','Content','Backup'],
            'editor'      => ['Donations ✎','Rates ✎'],
            'viewer'      => ['Donations 👁'],
          ];
          foreach(($perms[$key]??[]) as $p):
          ?>
          <span class="perm-tag" style="background:<?= $r['bg'] ?>;color:<?= $r['color'] ?>;border:1px solid <?= $r['border'] ?>"><?= $p ?></span>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>

  <!-- User cards -->
  <?php foreach($users as $u):
    $r    = $ROLES[$u['role']] ?? $ROLES['viewer'];
    $isMe = ($u['id'] == current_uid());
    $init = strtoupper(substr($u['username'],0,1));
  ?>
  <div class="user-card <?= $u['active']?'':'inactive' ?>" id="ucard-<?= $u['id'] ?>">
    <div class="user-card-head">
      <div class="user-card-left">
        <div class="avatar" style="background:<?= $r['color'] ?>"><?= h($init) ?></div>
        <div>
          <div class="user-info-name">
            <?= h($u['full_name'] ?: $u['username']) ?>
            <?= $isMe ? '<span class="you-badge">You</span>' : '' ?>
            <?= $u['force_pw_change'] ? '<span class="forced-badge">⚠ Must change PW</span>' : '' ?>
          </div>
          <div class="user-info-meta">
            <span>@<?= h($u['username']) ?></span>
            <span>·</span>
            <span><?= h($u['email']) ?></span>
          </div>
          <div class="user-info-meta" style="margin-top:.25rem">
            <span class="role-pill" style="background:<?= $r['bg'] ?>;color:<?= $r['color'] ?>;border:1px solid <?= $r['border'] ?>"><?= $r['icon'] ?> <?= $r['label'] ?></span>
            <?= $u['active']
              ? '<span class="status-dot" style="color:var(--success)">● Active</span>'
              : '<span class="status-dot" style="color:var(--muted)">○ Inactive</span>' ?>
          </div>
        </div>
      </div>
      <div class="user-card-actions">
        <button class="btn btn-gold btn-sm" onclick="toggleEdit(<?= $u['id'] ?>)">✏️ Edit</button>
        <?php if (!$isMe): ?>
        <form method="POST" style="display:inline">
          <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
          <input type="hidden" name="action" value="toggle_user">
          <input type="hidden" name="uid" value="<?= (int)$u['id'] ?>">
          <button class="btn btn-muted btn-sm"><?= $u['active']?'Deactivate':'Activate' ?></button>
        </form>
        <form method="POST" style="display:inline" onsubmit="return confirm('Permanently delete <?= h($u['username']) ?>? This cannot be undone.')">
          <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
          <input type="hidden" name="action" value="delete_user">
          <input type="hidden" name="uid" value="<?= (int)$u['id'] ?>">
          <button class="btn btn-danger btn-sm">✕ Delete</button>
        </form>
        <?php endif; ?>
      </div>
    </div>

    <!-- Inline edit form -->
    <div class="edit-form" id="edit-<?= $u['id'] ?>">
      <form method="POST">
        <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
        <input type="hidden" name="action" value="edit_user">
        <input type="hidden" name="uid" value="<?= (int)$u['id'] ?>">
        <div class="edit-form-grid">
          <div class="fg"><label>Full Name</label><input type="text" name="full_name" value="<?= h($u['full_name']) ?>" placeholder="Full name"></div>
          <div class="fg"><label>Email Address</label><input type="email" name="email" value="<?= h($u['email']) ?>" required></div>
          <div class="fg"><label>Role</label>
            <select name="role" <?= $isMe?'disabled':'' ?>>
              <?php foreach($ROLES as $rk=>$rv): ?>
              <option value="<?= $rk ?>"<?= $u['role']===$rk?' selected':'' ?>><?= $rv['icon'] ?> <?= $rv['label'] ?> — <?= $rv['desc'] ?></option>
              <?php endforeach; ?>
            </select>
            <?php if($isMe): ?><input type="hidden" name="role" value="<?= h($u['role']) ?>"><?php endif; ?>
          </div>
        </div>

        <!-- Password reset sub-section -->
        <div class="pw-reset-form">
          <h4>🔑 Reset Password <span style="font-size:.7rem;font-weight:400;color:var(--muted)">(leave blank to keep current password)</span></h4>
          <div class="pw-reqs">Requires: 10+ chars · uppercase · lowercase · number · special character</div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:.7rem">
            <div class="fg">
              <label>New Password</label>
              <div class="pw-wrap">
                <input type="password" name="new_password" id="np<?= $u['id'] ?>" placeholder="Leave blank to skip" oninput="checkStr('np<?= $u['id'] ?>','sb<?= $u['id'] ?>')">
                <button type="button" class="pw-eye" onclick="togglePw('np<?= $u['id'] ?>')">👁</button>
              </div>
              <div class="strength-bar"><div class="strength-fill" id="sb<?= $u['id'] ?>"></div></div>
            </div>
            <div class="fg">
              <label>Confirm Password</label>
              <div class="pw-wrap">
                <input type="password" name="confirm_password" id="cp<?= $u['id'] ?>" placeholder="Repeat new password">
                <button type="button" class="pw-eye" onclick="togglePw('cp<?= $u['id'] ?>')">👁</button>
              </div>
            </div>
          </div>
          <p style="font-size:.7rem;color:var(--muted);margin-top:.35rem">⚠ If you set a new password, the user will be required to change it on their next login.</p>
        </div>

        <div class="edit-form-actions" style="margin-top:.9rem">
          <button type="submit" class="btn btn-dark">💾 Save Changes</button>
          <button type="button" class="btn btn-muted" onclick="toggleEdit(<?= $u['id'] ?>)">Cancel</button>
          <span style="flex:1"></span>
          <span style="font-size:.7rem;color:var(--muted)">User ID: <strong><?= $u['id'] ?></strong></span>
        </div>
      </form>
    </div>

    <div class="meta-footer" style="padding:.4rem 1.2rem .55rem">
      <span>ID: <strong>#<?= $u['id'] ?></strong></span>
      <span>Created: <?= $u['created_at'] ? date('d M Y', strtotime($u['created_at'])) : '—' ?></span>
      <span>Last login: <?= $u['last_login'] ? date('d M Y H:i', strtotime($u['last_login'])) : 'Never' ?></span>
      <span>Last IP: <?= h($u['last_login_ip'] ?: '—') ?></span>
      <span>Actions logged: <?= (int)$u['action_count'] ?></span>
    </div>
  </div>
  <?php endforeach; ?>
</div>

<!-- ══════ ADD USER TAB ══════ -->
<div id="tab-add" class="tab-panel">
  <div class="ph"><div class="ph-title">Add New User</div></div>
  <div class="add-card">
    <div class="add-card-title">New User Details</div>
    <form method="POST">
      <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
      <input type="hidden" name="action" value="add_user">
      <div class="add-grid">
        <div class="fg"><label>Username * (3–30 chars, a–z 0–9 _)</label><input type="text" name="username" placeholder="e.g. johndoe" pattern="[a-z0-9_]{3,30}" required autocomplete="off"></div>
        <div class="fg"><label>Full Name</label><input type="text" name="full_name" placeholder="John Doe"></div>
        <div class="fg"><label>Email Address *</label><input type="email" name="email" placeholder="john@example.com" required></div>
      </div>
      <div class="fg" style="margin-bottom:.9rem"><label>Role *</label>
        <select name="role" style="width:100%;border:1.5px solid #e4e4e4;border-radius:8px;padding:.56rem .78rem;font-family:'DM Sans',sans-serif;font-size:.88rem;outline:none">
          <?php foreach($ROLES as $rk=>$rv): ?>
          <option value="<?= $rk ?>"><?= $rv['icon'] ?> <?= $rv['label'] ?> — <?= $rv['desc'] ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="pw-reqs-box">New password requirements: <ul><li>At least <?= MIN_PASSWORD_LEN ?> characters</li><li>Uppercase + lowercase + number + special character</li><li>User will be forced to change on first login</li></ul></div>
      <div class="add-grid">
        <div class="fg"><label>Initial Password *</label>
          <div class="pw-wrap">
            <input type="password" name="password" id="addpw" placeholder="Set initial password" oninput="checkStr('addpw','addbar')" required autocomplete="new-password">
            <button type="button" class="pw-eye" onclick="togglePw('addpw')">👁</button>
          </div>
          <div class="strength-bar"><div class="strength-fill" id="addbar"></div></div>
        </div>
        <div class="fg"><label>Confirm Password *</label>
          <div class="pw-wrap">
            <input type="password" name="confirm_password" id="addconf" placeholder="Repeat password" required autocomplete="new-password">
            <button type="button" class="pw-eye" onclick="togglePw('addconf')">👁</button>
          </div>
        </div>
        <div class="fg" style="display:flex;align-items:flex-end">
          <button type="submit" class="btn btn-dark" style="width:100%;padding:.65rem;justify-content:center;font-size:.88rem">➕ Create User</button>
        </div>
      </div>
    </form>
  </div>
</div>

<!-- ══════ AUDIT LOG TAB ══════ -->
<div id="tab-audit" class="tab-panel">
  <div class="ph"><div class="ph-title">📋 Audit Log <span style="font-size:.8rem;font-family:'DM Sans',sans-serif;font-weight:400;color:var(--muted)">(last 60 actions)</span></div></div>
  <div class="acard">
    <div class="tbl-wrap"><table>
      <thead><tr><th>Time</th><th>User</th><th>Action</th><th>Detail</th><th>IP Address</th></tr></thead>
      <tbody>
        <?php foreach($audits as $a): ?>
        <tr>
          <td style="white-space:nowrap;font-size:.74rem"><?= date('d M Y H:i', strtotime($a['created_at'])) ?></td>
          <td><strong><?= h($a['username']??'—') ?></strong></td>
          <td><span class="tag"><?= h($a['action']) ?></span></td>
          <td style="font-size:.76rem;color:var(--muted);max-width:280px"><?= h($a['detail']??'—') ?></td>
          <td style="font-family:monospace;font-size:.74rem;color:var(--muted)"><?= h($a['ip_address']??'—') ?></td>
        </tr>
        <?php endforeach; if(empty($audits)): ?>
        <tr><td colspan="5" style="text-align:center;padding:2rem;color:var(--muted)">No audit records yet.</td></tr>
        <?php endif; ?>
      </tbody>
    </table></div>
  </div>
</div>

<!-- ══════ LOGIN HISTORY TAB ══════ -->
<div id="tab-logins" class="tab-panel">
  <div class="ph"><div class="ph-title">🔐 Login History <span style="font-size:.8rem;font-family:'DM Sans',sans-serif;font-weight:400;color:var(--muted)">(last 40 attempts)</span></div></div>
  <div class="acard">
    <div class="tbl-wrap"><table>
      <thead><tr><th>Time</th><th>Username</th><th>Result</th><th>IP Address</th></tr></thead>
      <tbody>
        <?php foreach($logins as $l): ?>
        <tr style="background:<?= $l['success']?'rgba(27,122,74,.04)':'rgba(193,18,31,.03)' ?>">
          <td style="white-space:nowrap;font-size:.74rem"><?= date('d M Y H:i:s', strtotime($l['attempted_at'])) ?></td>
          <td><?= h($l['username']) ?></td>
          <td><?= $l['success']
            ? '<span style="color:var(--success);font-weight:700;font-size:.76rem">✓ Success</span>'
            : '<span style="color:var(--danger);font-weight:700;font-size:.76rem">✗ Failed</span>' ?></td>
          <td style="font-family:monospace;font-size:.74rem;color:var(--muted)"><?= h($l['ip_address']??'—') ?></td>
        </tr>
        <?php endforeach; if(empty($logins)): ?>
        <tr><td colspan="4" style="text-align:center;padding:2rem;color:var(--muted)">No login records.</td></tr>
        <?php endif; ?>
      </tbody>
    </table></div>
  </div>
</div>

</div><!-- /container -->

<script>
function switchTab(tab,btn){
  document.querySelectorAll('.tab-panel').forEach(p=>p.classList.remove('active'));
  document.querySelectorAll('.tab-btn').forEach(b=>b.classList.remove('active'));
  document.getElementById('tab-'+tab).classList.add('active');
  if(btn)btn.classList.add('active');
}
function toggleEdit(uid){
  const form=document.getElementById('edit-'+uid);
  const card=document.getElementById('ucard-'+uid);
  const open=form.classList.contains('open');
  // Close all
  document.querySelectorAll('.edit-form').forEach(f=>f.classList.remove('open'));
  document.querySelectorAll('.user-card').forEach(c=>c.classList.remove('editing'));
  if(!open){
    form.classList.add('open');
    card.classList.add('editing');
    form.scrollIntoView({behavior:'smooth',block:'nearest'});
  }
}
function togglePw(id){const i=document.getElementById(id);if(i)i.type=i.type==='password'?'text':'password';}
function checkStr(id,barId){
  const pw=document.getElementById(id)?.value||'';let score=0;
  if(pw.length>=10)score++;if(/[A-Z]/.test(pw))score++;if(/[a-z]/.test(pw))score++;
  if(/[0-9]/.test(pw))score++;if(/[^A-Za-z0-9]/.test(pw))score++;
  const cols=['#eee','#C1121F','#e65c00','#f4a261','#C9A84C','#1B7A4A'];
  const fill=document.getElementById(barId);if(fill){fill.style.width=(score*20)+'%';fill.style.background=cols[score];}
}
// Restore tab after POST flash
<?php if($fm): ?>
document.addEventListener('DOMContentLoaded',()=>{
  <?php if(str_contains($fm,'created')||str_contains($fm,'Created')): ?>
  const b=document.querySelector('.tab-btn[onclick*="users"]');if(b)b.click();
  <?php else: ?>
  const b=document.querySelector('.tab-btn[onclick*="users"]');if(b)b.click();
  <?php endif; ?>
});
<?php endif; ?>
</script>
</body>
</html>
