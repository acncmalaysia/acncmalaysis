<?php
session_start();
require_once '../config.php';
send_security_headers();
require_editor();

$db   = getDB();
$type = strtolower($_GET['type'] ?? 'csv');

// Match all dashboard filters
$q         = trim($_GET['q']         ?? '');
$fund_f    = trim($_GET['fund']      ?? '');
$cur_f     = trim($_GET['cur']       ?? '');
$miss_f    = trim($_GET['miss']      ?? '');
$type_f    = trim($_GET['type_f']    ?? '');
$date_from = trim($_GET['date_from'] ?? '');
$date_to   = trim($_GET['date_to']   ?? '');

$where  = ['1=1']; $params = [];
if ($q)         { $where[]='(first_name LIKE ? OR last_name LIKE ? OR email LIKE ? OR missionary LIKE ? OR ref LIKE ?)'; $s="%$q%"; $params=array_merge($params,[$s,$s,$s,$s,$s]); }
if ($fund_f)    { $where[]='fund=?';       $params[]=$fund_f; }
if ($cur_f)     { $where[]='currency=?';   $params[]=$cur_f; }
if ($miss_f)    { $where[]='missionary=?'; $params[]=$miss_f; }
if ($type_f==='monthly') { $where[]='monthly=1'; }
if ($type_f==='once')    { $where[]='monthly=0'; }
if ($date_from) { $where[]='DATE(created_at)>=?'; $params[]=$date_from; }
if ($date_to)   { $where[]='DATE(created_at)<=?'; $params[]=$date_to; }

$wsql = implode(' AND ', $where);
$stmt = $db->prepare("SELECT * FROM donations WHERE $wsql ORDER BY created_at DESC");
$stmt->execute($params);
$rows = $stmt->fetchAll();

$date = date('Y-m-d');
// Build descriptive filename based on active filters
$fname_parts = ['ACNC_Donations', $date];
if ($fund_f)    $fname_parts[] = 'fund-'  . preg_replace('/[^A-Za-z0-9]/','-',$fund_f);
if ($cur_f)     $fname_parts[] = 'cur-'   . $cur_f;
if ($miss_f)    $fname_parts[] = 'miss-'  . preg_replace('/[^A-Za-z0-9]/','-',substr($miss_f,0,20));
if ($type_f)    $fname_parts[] = $type_f;
if ($date_from) $fname_parts[] = 'from-'  . $date_from;
if ($date_to)   $fname_parts[] = 'to-'    . $date_to;
$export_filename = implode('_', $fname_parts);

if ($type === 'json') {
    $missionaries = $db->query("SELECT * FROM missionaries")->fetchAll();
    $rates        = $db->query("SELECT * FROM exchange_rates")->fetchAll();
    $backup = [
        'exported_at'  => date('c'),
        'exported_by'  => current_user(),
        'total_records'=> count($rows),
        'filters_applied' => array_filter(['q'=>$q,'fund'=>$fund_f,'currency'=>$cur_f,'missionary'=>$miss_f,'date_from'=>$date_from,'date_to'=>$date_to]),
        'donations'    => $rows,
        'missionaries' => $missionaries,
        'rates'        => $rates,
    ];
    audit('EXPORT_JSON', 'Exported JSON backup — '.count($rows).' records');
    header('Content-Type: application/json');
    header('Content-Disposition: attachment; filename="ACNC_Backup_'.$date.'.json"'); // JSON always full backup
    echo json_encode($backup, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit;
}

// CSV with UTF-8 BOM (for Excel)
audit('EXPORT_CSV', 'Exported CSV — '.count($rows).' records');
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="'.$export_filename.'.csv"');
header('Cache-Control: no-store');

$out = fopen('php://output', 'w');
fwrite($out, "\xEF\xBB\xBF"); // UTF-8 BOM

fputcsv($out, [
    'Ref No.','Date','Time','First Name','Last Name','Email','Phone','Country',
    'Amount','Currency','MYR Equivalent','Cover Fee?','Fee Amount (MYR)','Total MYR',
    'Missionary Partner','Fund / Purpose','Donation Type','Remarks'
]);

foreach ($rows as $r) {
    fputcsv($out, [
        $r['ref'],
        date('d/m/Y', strtotime($r['created_at'])),
        date('H:i',   strtotime($r['created_at'])),
        $r['first_name'],
        $r['last_name'],
        $r['email'],
        $r['phone']       ?? '',
        $r['country']     ?? '',
        number_format((float)$r['amount'], 2, '.', ''),
        $r['currency'],
        number_format((float)$r['myr_equivalent'], 2, '.', ''),
        $r['cover_fee']   ? 'Yes' : 'No',
        number_format((float)$r['fee_amount'], 2, '.', ''),
        number_format((float)$r['total_myr'], 2, '.', ''),
        $r['missionary']  ?? '',
        $r['fund'],
        $r['monthly']     ? 'Monthly Recurring' : 'One-time',
        $r['remarks']     ?? '',
    ]);
}
fclose($out);
