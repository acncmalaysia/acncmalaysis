<?php
session_start();
require_once '../config.php';
send_security_headers();
require_login();

$forced = !empty($_GET['forced']) || !empty($_SESSION['force_pw_change']);
$error = ''; $success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify($_POST['csrf_token'] ?? '')) { $error = 'Security error.'; }
    else {
        $current = $_POST['current_password'] ?? '';
        $new     = $_POST['new_password'] ?? '';
        $confirm = $_POST['confirm_password'] ?? '';
        $db = getDB();
        $user = $db->prepare("SELECT * FROM admin_users WHERE id=?")->execute([current_uid()]) ?
                $db->prepare("SELECT * FROM admin_users WHERE id=?") : null;
        $stmt = $db->prepare("SELECT password_hash FROM admin_users WHERE id=?");
        $stmt->execute([current_uid()]);
        $row = $stmt->fetch();
        if (!$row || !password_verify($current, $row['password_hash'])) {
            $error = 'Current password is incorrect.';
        } elseif ($new !== $confirm) {
            $error = 'New passwords do not match.';
        } elseif ($errs = validate_password($new)) {
            $error = 'Password must meet all requirements: ' . implode(' ', $errs);
        } else {
            $hash = password_hash($new, PASSWORD_BCRYPT, ['cost' => 12]);
            $db->prepare("UPDATE admin_users SET password_hash=?, force_pw_change=0 WHERE id=?")
               ->execute([$hash, current_uid()]);
            audit('PASSWORD_CHANGE', 'User changed their password');
            $success = 'Password updated successfully!';
            unset($_SESSION['force_pw_change']);
            if (!$forced) { header('Location: dashboard.php?msg=pw_changed'); exit; }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Change Password — ACNC Admin</title>
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@600;700&family=DM+Sans:wght@400;500;600&display=swap" rel="stylesheet">
<style>
*{box-sizing:border-box;margin:0;padding:0}body{font-family:'DM Sans',sans-serif;background:linear-gradient(140deg,#0d1b3e,#0F3460,#1a3a6e);min-height:100vh;display:flex;align-items:center;justify-content:center;padding:1rem}
.card{background:#fff;border-radius:20px;padding:2.3rem 2rem;width:100%;max-width:420px;box-shadow:0 24px 64px rgba(0,0,0,.35)}
.brand{text-align:center;margin-bottom:1.6rem}.brand .cross{font-size:2rem;color:#C9A84C}.brand h1{font-family:'Cormorant Garamond',serif;font-size:1.5rem;font-weight:700;color:#1A1A2E;margin-top:.3rem}.brand p{font-size:.75rem;color:#7A7A8C;margin-top:.15rem}
.forced-banner{background:#FFF8E1;border:1px solid rgba(255,193,7,.4);border-radius:10px;padding:.8rem 1rem;font-size:.82rem;color:#856404;margin-bottom:1.2rem;line-height:1.5}
.fg{margin-bottom:.9rem}.fg label{display:block;font-size:.7rem;font-weight:700;color:#7A7A8C;text-transform:uppercase;letter-spacing:.4px;margin-bottom:.28rem}
.fg input{width:100%;border:1.5px solid #e4e4e4;border-radius:9px;padding:.65rem .85rem;font-family:'DM Sans',sans-serif;font-size:.9rem;outline:none;transition:border .2s}
.fg input:focus{border-color:#C9A84C;box-shadow:0 0 0 3px rgba(201,168,76,.12)}
.pw-reqs{background:#F5EDD3;border-radius:8px;padding:.6rem .9rem;font-size:.75rem;color:#7a5500;margin-bottom:1rem;line-height:1.6}
.pw-reqs ul{padding-left:1rem;margin-top:.2rem}
.btn-save{width:100%;background:linear-gradient(135deg,#0F3460,#1A1A2E);color:#fff;border:none;border-radius:10px;padding:.85rem;font-family:'Cormorant Garamond',serif;font-size:1.15rem;font-weight:600;cursor:pointer;transition:all .3s;margin-top:.3rem}
.btn-save:hover{background:linear-gradient(135deg,#C9A84C,#E8C97A);color:#1A1A2E}
.alert-err{background:#FFE4E6;border:1px solid rgba(193,18,31,.2);border-radius:8px;padding:.65rem .9rem;font-size:.83rem;color:#C1121F;margin-bottom:1rem}
.alert-ok{background:#D6F0E3;border:1px solid rgba(27,122,74,.2);border-radius:8px;padding:.65rem .9rem;font-size:.83rem;color:#1B7A4A;margin-bottom:1rem}
.back-link{display:block;text-align:center;margin-top:1rem;font-size:.76rem;color:#7A7A8C;text-decoration:none}.back-link:hover{color:#C9A84C}
</style>
</head>
<body>
<div class="card">
  <div class="brand"><div class="cross">🔑</div><h1>Change Password</h1><p>Logged in as <?= h(current_user()) ?></p></div>
  <?php if ($forced && !$success): ?>
  <div class="forced-banner">⚠️ <strong>Action required:</strong> You must set a new password before continuing. Your temporary password must be changed now.</div>
  <?php endif; ?>
  <?php if ($error): ?><div class="alert-err">⚠️ <?= h($error) ?></div><?php endif; ?>
  <?php if ($success): ?><div class="alert-ok">✓ <?= h($success) ?> <?= $forced ? '<a href="dashboard.php">Go to dashboard →</a>' : '' ?></div><?php endif; ?>
  <div class="pw-reqs">
    Password requirements:
    <ul>
      <li>At least <?= MIN_PASSWORD_LEN ?> characters</li>
      <li>At least one uppercase letter (A–Z)</li>
      <li>At least one lowercase letter (a–z)</li>
      <li>At least one number (0–9)</li>
      <li>At least one special character (!@#$%^&*…)</li>
    </ul>
  </div>
  <form method="POST">
    <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
    <div class="fg"><label>Current Password</label><input type="password" name="current_password" required autofocus></div>
    <div class="fg"><label>New Password</label><input type="password" name="new_password" id="newpw" oninput="checkStrength()" required></div>
    <div class="fg"><label>Confirm New Password</label><input type="password" name="confirm_password" required></div>
    <div id="strengthBar" style="height:4px;border-radius:2px;background:#eee;margin-bottom:.8rem;overflow:hidden"><div id="strengthFill" style="height:100%;width:0;transition:all .3s;border-radius:2px"></div></div>
    <button type="submit" class="btn-save">🔑 Update Password</button>
  </form>
  <?php if (!$forced): ?><a href="dashboard.php" class="back-link">← Back to dashboard</a><?php endif; ?>
</div>
<script>
function checkStrength(){
  const pw=document.getElementById('newpw').value;
  let score=0;
  if(pw.length>=10)score++;if(/[A-Z]/.test(pw))score++;if(/[a-z]/.test(pw))score++;
  if(/[0-9]/.test(pw))score++;if(/[^A-Za-z0-9]/.test(pw))score++;
  const colors=['#eee','#C1121F','#e65c00','#f4a261','#C9A84C','#1B7A4A'];
  const fill=document.getElementById('strengthFill');
  fill.style.width=(score*20)+'%';fill.style.background=colors[score];
}
</script>
</body>
</html>
